/* jshint node:true */
module.exports = function(grunt) {
	// var path = require('path'),
		// SOURCE_DIR = 'src/',
		// BUILD_DIR = 'build/',
	var	CSS_DIR = 'css/',
			SASS_DIR = 'css/sass/',
			CSS_BUILD_DIR = 'css/build/',
			AUTOPREFIXER_DIR = 'css/prefixed/',
			CSS_MIN_DIR = 'css/minified/',
		JS_DIR = 'js/',
		IMG_DIR = 'images/';

	// Load tasks.
	// require('matchdep').filterDev('grunt-*').forEach( grunt.loadNpmTasks );

	// Project configuration.
	grunt.initConfig({
		pkg: grunt.file.readJSON('package.json'),
		sass: {
			bcore: {
				options: {
					style: 'expanded'
				},
				files: {
					'css/build/style.css': 'css/scss/style.scss'
				}
			}
		},
		autoprefixer: {
			options: {
				// browsers: ['last 2 version']
				browsers: ['Android >= 2.1', 'Chrome >= 21', 'Explorer >= 7', 'Firefox >= 17', 'Opera >= 12.1', 'Safari >= 6.0']
			},
			bcore: {
				expand: true,
				src: 'css/build/*.css',
				dest: 'css/prefixed/'
			}
		},
		// clean: {
		// 	all: [BUILD_DIR],
		// 	dynamic: {
		// 		dot: true,
		// 		expand: true,
		// 		cwd: BUILD_DIR,
		// 		src: []
		// 	},
		// 	tinymce: ['<%= concat.tinymce.dest %>'],
		// 	qunit: ['tests/qunit/compiled.html']
		// },
		// copy: {
		// 	files: {
		// 		files: [
		// 			{
		// 				dot: true,
		// 				expand: true,
		// 				cwd: SOURCE_DIR,
		// 				src: [
		// 					'**',
		// 					'!**/.{svn,git}/**', // Ignore version control directories.
		// 					// Ignore unminified versions of external libs we don't ship:
		// 					'!wp-includes/js/backbone.js',
		// 					'!wp-includes/js/underscore.js',
		// 					'!wp-includes/js/jquery/jquery.masonry.js',
		// 					'!wp-includes/js/tinymce/tinymce.js',
		// 					'!wp-includes/version.php' // Exclude version.php
		// 				],
		// 				dest: BUILD_DIR
		// 			},
		// 			{
		// 				src: 'wp-config-sample.php',
		// 				dest: BUILD_DIR
		// 			}
		// 		]
		// 	},
		// 	'wp-admin-rtl': {
		// 		options: {
		// 			processContent: function( src ) {
		// 				return src.replace( /\.css/g, '-rtl.css' );
		// 			}
		// 		},
		// 		src: SOURCE_DIR + 'wp-admin/css/wp-admin.css',
		// 		dest: BUILD_DIR + 'wp-admin/css/wp-admin-rtl.css'
		// 	},
		// 	version: {
		// 		options: {
		// 			processContent: function( src ) {
		// 				return src.replace( /^\$wp_version = '(.+?)';/m, function( str, version ) {
		// 					version = version.replace( /-src$/, '' );

		// 					// If the version includes an SVN commit (-12345), it's not a released alpha/beta. Append a date.
		// 					version = version.replace( /-[\d]{5}$/, '-' + grunt.template.today( 'yyyymmdd' ) );

		// 					/* jshint quotmark: true */
		// 					return "$wp_version = '" + version + "';";
		// 				});
		// 			}
		// 		},
		// 		src: SOURCE_DIR + 'wp-includes/version.php',
		// 		dest: BUILD_DIR + 'wp-includes/version.php'
		// 	},
		// 	dynamic: {
		// 		dot: true,
		// 		expand: true,
		// 		cwd: SOURCE_DIR,
		// 		dest: BUILD_DIR,
		// 		src: []
		// 	},
		// 	qunit: {
		// 		src: 'tests/qunit/index.html',
		// 		dest: 'tests/qunit/compiled.html',
		// 		options: {
		// 			processContent: function( src ) {
		// 				return src.replace( /([^\.])*\.\.\/src/ig , '/../build' );
		// 			}
		// 		}
		// 	}
		// },
		cssmin: {
			options: {
				// 'wp-admin': ['wp-admin', 'color-picker', 'customize-controls', 'customize-widgets', 'ie', 'install', 'login', 'deprecated-*'],
				banner: '/* Theme Name: BCore | Theme URI: http://www.brandco.com | Description: This theme was made by BrandCo | Version: 0.1 | Author: BrandCo | Author URI: http://www.brandco.com | Tags: BrandCo */'
			},
			bcore: {
				expand: true,
				// ext: '.min.css'
				// cwd: BUILD_DIR,
				src: 'css/prefixed/style.css',
				dest: 'css/minified/'
			}
		},
		// cssjanus: {
		// 	core: {
		// 		options: {
		// 			swapLtrRtlInUrl: false
		// 		},
		// 		expand: true,
		// 		cwd: SOURCE_DIR,
		// 		dest: BUILD_DIR,
		// 		ext: '-rtl.css',
		// 		src: [
		// 			'wp-admin/css/*.css',
		// 			'wp-includes/css/*.css'
		// 		]
		// 	},
		// 	colors: {
		// 		options: {
		// 			processContent: function( src ) {
		// 				return src.replace( /([^/]+)\.css/gi, '$1-rtl.css' );
		// 			}
		// 		},
		// 		expand: true,
		// 		cwd: BUILD_DIR,
		// 		dest: BUILD_DIR,
		// 		ext: '-rtl.css',
		// 		src: [
		// 			'wp-admin/css/colors/*/colors.css'
		// 		]
		// 	},
		// 	dynamic: {
		// 		expand: true,
		// 		cwd: SOURCE_DIR,
		// 		dest: BUILD_DIR,
		// 		ext: '-rtl.css',
		// 		src: []
		// 	}
		// },
		jshint: {
			// options: grunt.file.readJSON('.jshintrc'),
			// grunt: {
			// 	src: ['Gruntfile.js']
			// },
			bcore: ['js/scripts.js']
		},
		// qunit: {
		// 	files: [
		// 		'tests/qunit/**/*.html',
		// 		'!tests/qunit/editor/**'
		// 	]
		// },
		// phpunit: {
		// 	'default': {
		// 		cmd: 'phpunit',
		// 		args: ['-c', 'phpunit.xml.dist']
		// 	},
		// 	ajax: {
		// 		cmd: 'phpunit',
		// 		args: ['-c', 'phpunit.xml.dist', '--group', 'ajax']
		// 	},
		// 	multisite: {
		// 		cmd: 'phpunit',
		// 		args: ['-c', 'tests/phpunit/multisite.xml']
		// 	}
		// },
		uglify: {
			core: {
				expand: true,
				// cwd: SOURCE_DIR,
				dest: JS_DIR,
				ext: '.min.js',
				src: [
					// 'js/*.js',
					'js/scripts.js',

					// Exceptions
					'!js/admin.js'
				]
			}
		},
		// concat: {
		// 	tinymce: {
		// 		options: {
		// 			separator: '\n',
		// 			process: function( src, filepath ) {
		// 				return '// Source: ' + filepath.replace( BUILD_DIR, '' ) + '\n' + src;
		// 			}
		// 		},
		// 		src: [
		// 			BUILD_DIR + 'wp-includes/js/tinymce/tinymce.min.js',
		// 			BUILD_DIR + 'wp-includes/js/tinymce/themes/modern/theme.min.js',
		// 			BUILD_DIR + 'wp-includes/js/tinymce/plugins/*/plugin.min.js'
		// 		],
		// 		dest: BUILD_DIR + 'wp-includes/js/tinymce/wp-tinymce.js'
		// 	}
		// },
		// compress: {
		// 	tinymce: {
		// 		options: {
		// 			mode: 'gzip',
		// 			level: 9
		// 		},
		// 		src: '<%= concat.tinymce.dest %>',
		// 		dest: BUILD_DIR + 'wp-includes/js/tinymce/wp-tinymce.js.gz'
		// 	}
		// },
		jsvalidate:{
			options: {
				globals: {},
				esprimaOptions:{},
				verbose: false
			},
			build: {
				files: {
					src: [
						'js/scripts.js'
						// 'js/*.js',
						// '!test.js'
					]
				}
			}
		},
		imagemin: {
			bcore: {
				expand: true,
				// cwd: SOURCE_DIR,
				src: [
					'images/*.{png,jpg,gif,jpeg}'
				],
				dest: IMG_DIR
			}
		},
		watch: {
			// all: {
			// 	files: [
			// 		'**',
			// 		// Ignore version control directories.
			// 		'!**/.{svn,git}/**'
			// 	],
			// 	tasks: ['clean:dynamic', 'copy:dynamic'],
			// 	options: {
			// 		dot: true,
			// 		spawn: false,
			// 		interval: 2000
			// 	}
			// },
			// colors: {
			// 	files: [SOURCE_DIR + 'wp-admin/css/colors/**'],
			// 	tasks: ['sass:colors']
			// },
			// rtl: {
			// 	files: [
			// 		SOURCE_DIR + 'wp-admin/css/*.css',
			// 		SOURCE_DIR + 'wp-includes/css/*.css'
			// 	],
			// 	tasks: ['cssjanus:dynamic'],
			// 	options: {
			// 		spawn: false,
			// 		interval: 2000
			// 	}
			// },
			// test: {
			// 	files: [
			// 		'tests/qunit/**',
			// 		'!tests/qunit/editor/**'
			// 	],
			// 	tasks: ['qunit']
			// },
			css: {
				files: ['css/*.scss'],
				tasks: ['sass', 'autoprefixer', 'cssmin'],
				options: {
					livereload: true
				}
			},
			js: {
				// files: [
				// 	'tests/qunit/**',
				// 	'!tests/qunit/editor/**'
				// ],
				files: ['js/scripts.js'],
				tasks: ['jshint','uglify', 'jsvalidate'],
				options: {
					livereload: true
				}
			},
			images: {
				files: ['images/**/*.{png,jpg,gif,jpeg}', 'images/*.{png,jpg,gif,jpeg}'],
				tasks: ['imagemin']
			}
		}
	});

	// load tasks
	require('load-grunt-tasks')(grunt);

	// Register tasks.

	// Pre-commit task.
	// grunt.registerTask('precommit', 'Runs front-end dev/test tasks in preparation for a commit.',
	// 	['autoprefixer:core', 'imagemin:core', 'jshint', 'qunit:compiled']);

	// Copy task.
	// grunt.registerTask('copy:all', ['copy:files', 'copy:wp-admin-rtl', 'copy:version']);

	// Build task.
	// grunt.registerTask('build', ['clean:all', 'copy:all', 'cssmin:core', 'colors', 'rtl', 'cssmin:rtl', 'cssmin:colors',
	// 	'uglify:core', 'concat:tinymce', 'compress:tinymce', 'clean:tinymce', 'jsvalidate:build']);
	grunt.registerTask('build', ['sass', 'autoprefixer', 'cssmin', 'jshint','uglify', 'jsvalidate']);

	// Final Build
	grunt.registerTask('fbuild', ['sass', 'autoprefixer', 'cssmin', 'jshint','uglify', 'jsvalidate', 'imagemin']);

	// Testing tasks.
	// grunt.registerMultiTask('phpunit', 'Runs PHPUnit tests, including the ajax and multisite tests.', function() {
	// 	grunt.util.spawn({
	// 		cmd: this.data.cmd,
	// 		args: this.data.args,
	// 		opts: {stdio: 'inherit'}
	// 	}, this.async());
	// });

	// grunt.registerTask('qunit:compiled', 'Runs QUnit tests on compiled as well as uncompiled scripts.',
	// 	['build', 'copy:qunit', 'qunit']);

	// grunt.registerTask('test', 'Runs all QUnit and PHPUnit tasks.', ['qunit:compiled', 'phpunit']);
	// grunt.registerTask('travis', ['jshint', 'test']);

	// css, js, img
	grunt.registerTask('css', ['sass', 'autoprefixer', 'cssmin']);
		grunt.registerTask('sass', ['sass']);
	grunt.registerTask('js', ['jshint', 'concat', 'uglify']);
	grunt.registerTask('img', ['imagemin']);

	// Default task.
	grunt.registerTask('default', ['build']);

	// Add a listener to the watch task.
	//
	// On `watch:all`, automatically updates the `copy:dynamic` and `clean:dynamic`
	// configurations so that only the changed files are updated.
	// On `watch:rtl`, automatically updates the `cssjanus:dynamic` configuration.
	// grunt.event.on('watch', function( action, filepath, target ) {
	// 	if ( target !== 'all' && target !== 'rtl' ) {
	// 		return;
	// 	}

	// 	var relativePath = path.relative( SOURCE_DIR, filepath ),
	// 		cleanSrc = ( action === 'deleted' ) ? [relativePath] : [],
	// 		copySrc = ( action === 'deleted' ) ? [] : [relativePath];

	// 	grunt.config(['clean', 'dynamic', 'src'], cleanSrc);
	// 	grunt.config(['copy', 'dynamic', 'src'], copySrc);
	// 	grunt.config(['cssjanus', 'dynamic', 'src'], copySrc);
	// });
};
