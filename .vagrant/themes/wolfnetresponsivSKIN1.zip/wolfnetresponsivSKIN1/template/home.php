<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package bcore
 *
 * Template Name: Homepage
 *
 */

$communities = new WP_Query( 'post_type=city&orderby=title&order=ASC&posts_per_page=12&meta_key=meta-checkbox&meta_value=yes' );
$communities_2 = new WP_Query( 'post_type=city&orderby=title&order=ASC&posts_per_page=3' );
$blogfeedargs = array(
	'post_type' => array( 'post', 'city_post' ),
	'posts_per_page' => 4
);
$blogpostsfour = new WP_Query( $blogfeedargs );

	$header_image = get_theme_mod('imageheader');
	$header_image2 = get_theme_mod('imageheader2');
	$header_image3 = get_theme_mod('imageheader3');

	$image_array = array($header_image, $header_image2, $header_image3);

get_header(); ?>

	<div id="searchbyarea">
		<div class="container">
			<?php $communitiestitle = get_theme_mod( 'communitiestitle' ); if( !empty( $communitiestitle ) ): ?>
				<h1><?php echo $communitiestitle; ?></h1>
			<?php else: ?>
				<h1>Search By Area</h1>
			<?php endif; ?>
			<hr>
			<p class="home_description">Select an area for your custom home search.</p>
			<?php
			// count total before reall loop (aready a max of 12)
			$communities_total_count = 0;
			if ( $communities->have_posts() ) {
				while ( $communities->have_posts() ) {
					$communities->the_post();
					$communities_total_count++;
				}
			}
			// 10, 11, 12
			$communities_to_display = 12;
			if ( $communities_total_count == 12){
				$communities_to_display = 12;
			// 7, 8, 9
			if ( $communities_total_count < 12 || $communities_total_count == 9) {
				$communities_to_display = 9;
				// 4, 5, 6
				if ( $communities_total_count < 9 || $communities_total_count == 6 ) {
					$communities_to_display = 6;
					// 1, 2, 3
					if ( $communities_total_count < 6 || $communities_total_count == 3) {
						$communities_to_display = 3;
					}
				}
			}
			}
			wp_reset_postdata();
			?>
			<?php
			// the real loop
			$communities_count = 0;
			if ( $communities->have_posts() ) {
				echo '<ul>';
				while ( $communities->have_posts() && $communities_to_display > 0 ) {
					$communities->the_post();
					$communities_count++;
					$communities_display_on_phone = get_post_meta(get_the_ID(), 'meta-checkbox-two', true);
					if ($communities_display_on_phone == 'yes') {
						echo '<li class="communities_li communities_count_' . $communities_count . ' communities_display_on_phone"><div class="aspect-ratio-inner"><a href="';
					}
					else {
						echo '<li class="communities_li communities_count_' . $communities_count . '"><div class="aspect-ratio-inner"><a href="';
					}
					echo the_permalink();
					echo '">';
					if ( has_post_thumbnail() ) { // check if the post has a Post Thumbnail assigned to it.
						$the_community_background = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
						echo '<div class="single_area"><div class="single_area_background" style="background:url(' . $the_community_background . ') no-repeat center center;"><div class="single_area_background_cover"><div class="single_area_text">';
					}
					else {
						echo '<div class="single_area"><div class="single_area_background" style="background:url(' . $image_array[array_rand($image_array)] . ') no-repeat center center;"><div class="single_area_background_cover"><div class="single_area_text">';
					}
					echo get_the_title();
					echo '</div></div></div></div></div>';
					echo '</a></li>';
					// calculate how many more you can display
					$communities_to_display--;
				}
				echo '</ul>';
			} elseif($communities_2->have_posts()) {
				// no featured found
					echo '<ul>';
					while ( $communities_2->have_posts() ) {
						$communities_2->the_post();
					$communities_count++;
					$communities_display_on_phone = get_post_meta(get_the_ID(), 'meta-checkbox-homepage-two', true);
					if ($communities_display_on_phone == 'yes') {
						echo '<li class="communities_li communities_count_' . $communities_count . ' communities_display_on_phone"><div class="aspect-ratio-inner"><a href="';
					}
					else {
						echo '<li class="communities_li communities_count_' . $communities_count . '"><div class="aspect-ratio-inner"><a href="';
					}
					echo the_permalink();
					echo '">';
					if ( has_post_thumbnail() ) { // check if the post has a Post Thumbnail assigned to it.
						$the_community_background = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
						echo '<div class="single_area"><div class="single_area_background" style="background:url(' . $the_community_background . ') no-repeat center center;"><div class="single_area_background_cover"><div class="single_area_text">';
					}
					else {
						echo '<div class="single_area"><div class="single_area_background" style="background:url(' . $image_array[array_rand($image_array)] . ') no-repeat center center;"><div class="single_area_background_cover"><div class="single_area_text">';
					}
					echo get_the_title();
					echo '</div></div></div></div></div>';
					echo '</a></li>';
					// calculate how many more you can display
					$communities_to_display--;
					}
					echo '</ul>';
			 }
			else {
				// no posts found
			}
			wp_reset_postdata();
			?>
			<div class="clear"></div>
		</div>		
	</div>


	<div id="featuredproperties">
		<div class="container">
			<?php $homefeaturedtitle = get_theme_mod( 'homefeaturedtitle' ); if( !empty( $homefeaturedtitle ) ): ?>
				<h1><?php echo $homefeaturedtitle; ?></h1>
			<?php else: ?>
				<h1>Featured Listings</h1>
			<?php endif; ?>
			<hr>
			<p class="home_description">Select a featured listing from the properties below.</p>
			<div class="container_home1">
				<?php $homefeatured = get_theme_mod( 'homefeatured' ); if( !empty( $homefeatured ) ): ?>
					<?php echo do_shortcode($homefeatured); ?>
				<?php endif; ?>
			</div>
			<div class="clear"></div>
		</div>
	</div>

	<!--<?php $homefeatured2 = get_theme_mod( 'homefeatured2' ); if( !empty( $homefeatured2 ) ): ?>
	<div id="featuredproperties2">
		<div class="container">
			<?php $homefeatured2_title = get_theme_mod( 'homefeatured2_title' ); if( !empty( $homefeatured2_title ) ) { ?>
			<h1><?php echo $homefeatured2_title; ?></h1>
			<?php } else { ?>
			<h1>Featured Properties</h1>
			<?php } ?>
			<hr>
			<div class="container_home1">
				<?php echo do_shortcode($homefeatured2); ?>
			</div>
			<div class="clear"></div>
		</div>
	</div>
	<?php endif; ?>-->

	</div>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			<!-- <div class="container"> -->
				<h1>Latest Blog Posts</h1>
				<hr>
				<p class="home_description">We've got something to say.</p>
				<?php $count = 0; ?>
				<?php while ( $blogpostsfour->have_posts() ) : $blogpostsfour->the_post(); ?>

					<?php $count++; ?>

					<a href="<?php the_permalink(); ?>">
					<div class="singlepost singlepost-<?php echo $count; ?>">

						<?php
							// $blog_post_title = get_the_title();
							// if(strlen($blog_post_title) > 10) {
							// 	$blog_post_title = substr($blog_post_title, 0, 20) . '...';
							// }
						?>
						
						<?php bcore_posted_on(); ?>
						<!-- <h3><a href="<?php the_permalink(); ?>"><?php echo $blog_post_title; ?></a></h3> -->
						<?php //the_excerpt(); ?>

					</div>
					</a>

				<?php endwhile; // end of the loop. ?>

				<div class="view-all"><a href="<?php echo get_permalink( get_option('page_for_posts') );?>"><button>View All Posts</button></a></div>

				<div class="clear"></div>

				<div class="footerwidgets">
					<div class="container">
						<div class="first">
							<?php dynamic_sidebar('footer1'); ?>
						</div>
						<div class="second">
							<?php dynamic_sidebar('footer2'); ?>
						</div>
					</div>
				</div>
				<div class="clear"></div>
			<!-- </div> -->
		</main><!-- #main -->
	</div><!-- #primary -->

	<div class="site-content">

	<?php $secondary_image = get_theme_mod('secondaryimage'); ?>
	<?php if ($secondary_image != null): ?>
	<?php 
	// images edit
	$secondary_image_part2 = parse_url($secondary_image);
	// image result
	$this_sites_home_url_footer = esc_url( home_url() );
	$secondary_image_part3 = $this_sites_home_url . $secondary_image_part2['path'] . $secondary_image_part2['query'] . $secondary_image_part2['fragment'];
	?>
	<div id="homecontactform" style="background-image:url(<?php echo $secondary_image; ?>);">
	<?php else: ?>
	<div id="homecontactform">
	<?php endif; ?>
		<div class="container">
		<h3>Contact Us</h3>
		<hr>
			<?php // Get gravity forms shortcode from theme customizer
				$homegravityform = get_theme_mod('homegravityform'); 
				if ( $homegravityform ) { 
					echo do_shortcode( $homegravityform );
				}
				else{
						echo do_shortcode('[gravityform id="1" title="false" description="false"]');
					};
				?>
		</div>
	</div>

<?php get_footer(); ?>
