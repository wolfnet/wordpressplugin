/**
 * scripts.js
 */

jQuery(function($) {

	// Menu Height Fix (70 + 35)
	/*$(document).ready(function() {
		$( '.menu-toggle' ).click(function() {
			var document_height_for_menu = $(document).height() - 70;
			$('.main-navigation.toggled .menu').css('height',document_height_for_menu);
			if ($('#wpadminbar').length > 0) {
				$('.main-navigation.toggled .menu').css('height',document_height_for_menu-35);
			}
		});
	});*/

	// Homepage Wolfnet Quick Search Dropdown Fix
	// part 1
	$('.wolfnet_widgetBeds select option:first-child').text('Beds'); // Replace default "Any" with "Beds"
	// $('#bcore-header .wolfnet_widgetBeds select option:nth-child(2)').append(' Bed'); // Add "Bed" after "1"
	// $('.wolfnet_widgetBeds select option:gt(1)').append(' Beds'); // Add "Beds" after "2, 3, ..."
	$('.wolfnet_widgetBeds label').hide();
	// // part 2
	$('.wolfnet_widgetBaths select option:first-child').text('Baths'); // Replace default "Any" with "Baths"
	// $('.wolfnet_widgetBaths select option:nth-child(2)').append(' Bath'); // Add "Bath" after "1"
	// $('.wolfnet_widgetBaths select option:gt(1)').append(' Baths'); // Add "Baths" after "2, 3, ..."
	$('.wolfnet_widgetBaths label').hide();

	$('.wolfnet_widgetPrice div:first-of-type select option:first-child').text('Min. Price'); 
	$('.wolfnet_widgetPrice div:nth-of-type(2) select option:first-child').text('Max. Price'); 

	// hide search text
	$('body.home #bcore-header button.wolfnet_quickSearchForm_submitButton').html('');

	// sidebar
	$('#secondary button.wolfnet_quickSearchForm_submitButton').html('SEARCH');
	$('#secondary .wolfnet_quickSearchFormButton').wrap('<div class="clear"></div>');
	$('#secondary .wolfnet_widgetTitle').append('<hr />');

	$( document ).ready(function() {
		$('body.home .wolfnet_quickSearchForm_submitButton').addClass('icon-search');
	});

	// Homepage Widgets
	if ( $('.footerwidgets .first .widget-title').is(':empty') ) {
	}
	else {
		$('.footerwidgets .first .widget-title').append('<hr>');
	}
	if ( $('.footerwidgets .second .widget-title').is(':empty') ) {
	}
	else {
		$('.footerwidgets .second .widget-title').append('<hr>');
	}

	// window height
	var windowwidth = $(window).width();
	// var windowheight = $(window).height();

	// scroll top
	// var scrollTop = $(window).scrollTop();

	// img width
	var imagewidth = 1920;
	// var imageheight = 624;

	/*if (windowwidth > imagewidth) {
		$( "header#bcore-header" ).css( "backgrond-size", function( index ) {
			return 100%;
		});
	}
	$(window).resize(function() {
		windowwidth = $(window).width();
		if (windowwidth > imagewidth) {
			$( "header#bcore-header" ).css( "backgrond-size", function( index ) {
				return 100%;
			});
		}
		$( "#content h1" ).text( "windowwidth:" + windowwidth + ", imagewidth: " + imagewidth);
	}*/

	$.fn.bcoreMobileMenu = function() {
		var menuCopy = this.clone(),
			siteTitle = $("head title").html();
		$('body').addClass('bcore-mobile-menu-enabled');
		this.addClass('bcore-menu-selected');
		this.before('<div class="bcore-mobile-toggle icon-menu2"></div>');
	
		$('body').append( '<nav id="bcore-mobile-menu"></nav>' );
		$('nav#bcore-mobile-menu').append( menuCopy ).prepend('<h4 class="bcore-mob-title">Site Navigation</h4>');
		$('nav#bcore-mobile-menu .menu-item-has-children > a').after('<div class="open-children">></div>');
		$('.open-children').each(function(){
			$(this).click(function(){
				$(this).next().slideToggle(300);
			});
		});
		// $('#bcore-mobile-menu').hide();
		$('.bcore-mobile-toggle').click(function(){
			// $('#bcore-mobile-menu').show();
			$('body').toggleClass('bcore-open-menu');
			// $('#page').addClass('page-2');
			// $('.wolfnet_marketDisclaimer').addClass('wolfnet_marketDisclaimer-2');
			$('.bcore-mobile-toggle').toggleClass('icon-menu2');
			$('.bcore-mobile-toggle').toggleClass('icon-close');
		});
		// $('nav#bcore-mobile-menu ul.menu > li:last-of-type').after('<li class="bcore-close-menu"><a href="#">Close menu &times;</a></li>');
		$(document.body).on('click', '#bcorr-body-cover' ,function(){
			// $('#bcore-mobile-menu').hide();
			$('body').removeClass('bcore-open-menu');
			$('.bcore-mobile-toggle').removeClass('icon-close');
			$('.bcore-mobile-toggle').addClass('icon-menu2');
		});
	};
	$('#site-navigation > div').bcoreMobileMenu();

	/*
	$( document ).ready(function() {
		// gravity forms custom placeholders
		$('.gform_wrapper li.gfield .gfield_label').click(function(){
			$(this).next('.ginput_container').find('input[type="text"], textarea').focus();
		});

		$('.gform_wrapper .ginput_container input[type="text"], .gform_wrapper .ginput_container textarea')
		.focus(function(){
			$(this).closest('.ginput_container').prev('.gfield_label').hide();
		})
		.blur(function(){
			if( $(this).val() === "" ){
				$(this).closest('.ginput_container').prev('.gfield_label').show();
			}
		});

		$('.gform_wrapper .ginput_container input[type="text"], .gform_wrapper .ginput_container textarea').each(function(){
			if( $(this).val() !== "" ){
				$(this).closest('.ginput_container').prev('.gfield_label').hide();
			}
		});
	});
	*/

});
