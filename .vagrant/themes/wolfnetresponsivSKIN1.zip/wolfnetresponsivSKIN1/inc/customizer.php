<?php
/**
 * bcore Theme Customizer
 *
 * @package bcore
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function bcore_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	// Images
	$wp_customize->add_section( 'images' , array(
		'title' => __( 'Custom Images', '_s' ),
		'priority' => 29,
		'description' => __( 'Brand your site with custom images.', '_s' )
	));

	// $wp_customize->add_setting( 'headerimage' , array( 'default' => '' ));
	// $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'headerimage', array(
	// 	'label' => __( 'Add header image to the website.', '_s' ),
	// 	'section' => 'images',
	// 	'settings' => 'headerimage',
	// )));

	$wp_customize->add_setting( 'logofavicon' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'logofavicon', array(
		'label' => __( 'Website Favicon (Must be .png or .ico format. Suggested dimentions: 32x32.)', '_s' ),
		'section' => 'images',
		'settings' => 'logofavicon',
		'extensions' => array( 'png', 'ico' )
	)));
	$wp_customize->add_setting( 'logom' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'logom', array(
		'label' => __( 'Main Logo (Suggested dimentions: 354x180)', '_s' ),
		'section' => 'images',
		'settings' => 'logom',
	)));
	$wp_customize->add_setting( 'logob' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'logob', array(
		'label' => __( 'Brokerage Logo (Suggested dimentions: 143x40)', '_s' ),
		'section' => 'images',
		'settings' => 'logob',
	)));
	$wp_customize->add_setting( 'imageheader' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'imageheader', array(
		'label' => __( 'Header Image (Required width of 1920px and height of 624px, otherwise your image will stretch)', '_s' ),
		'section' => 'images',
		'settings' => 'imageheader',
	)));
	$wp_customize->add_setting( 'imageheader2' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'imageheader2', array(
		'label' => __( 'Header Image 2 {optional} (Required width of 1920px and height of 624px, otherwise your image will stretch)', '_s' ),
		'section' => 'images',
		'settings' => 'imageheader2',
	)));
	$wp_customize->add_setting( 'imageheader3' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'imageheader3', array(
		'label' => __( 'Header Image 3 {optional} (Required width of 1920px and height of 624px, otherwise your image will stretch)', '_s' ),
		'section' => 'images',
		'settings' => 'imageheader3',
	)));
	$wp_customize->add_setting( 'secondaryimage' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'secondaryimage', array(
		'label' => __( 'Secondary Image', '_s' ),
		'section' => 'images',
		'settings' => 'secondaryimage',
	)));

	// Social
	$wp_customize->add_section( 'social' , array(
		'title' => __( 'Social Media', '_s' ),
		'priority' => 30,
		'description' => __( 'Please enter the full urls of all your social networks with http:// in the front of each them.', '_s' )
	));

	$wp_customize->add_setting( 'tw' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'tw', array(
		'label' => __( 'Twitter', '_s' ),
		'section' => 'social',
		'settings' => 'tw',
	)));

	$wp_customize->add_setting( 'pin' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'pin', array(
		'label' => __( 'Pinterest', '_s' ),
		'section' => 'social',
		'settings' => 'pin',
	)));

	$wp_customize->add_setting( 'in' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'in', array(
		'label' => __( 'LinkedIn', '_s' ),
		'section' => 'social',
		'settings' => 'in',
	)));

	$wp_customize->add_setting( 'insta' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'insta', array(
		'label' => __( 'Instagram', '_s' ),
		'section' => 'social',
		'settings' => 'insta',
	)));

	$wp_customize->add_setting( 'gp' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gp', array(
		'label' => __( 'Google+', '_s' ),
		'section' => 'social',
		'settings' => 'gp',
	)));

	$wp_customize->add_setting( 'fb' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'fb', array(
		'label' => __( 'Facebook', '_s' ),
		'section' => 'social',
		'settings' => 'fb',
	)));

	$wp_customize->add_setting( 'yt' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'yt', array(
		'label' => __( 'YouTube', '_s' ),
		'section' => 'social',
		'settings' => 'yt',
	)));

	// $wp_customize->add_setting( 'headerimage' , array( 'default' => '' ));
	// $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'headerimage', array(
	// 	'label' => __( 'Main Header Image (We suggest that you use the biggest photo you can find)', '_s' ),
	// 	'section' => 'logo',
	// 	'settings' => 'headerimage',
	// )));

	// Homepage
	$wp_customize->add_section( 'homepage' , array(
		'title' => __( 'Homepage Settings', '_s' ),
		'priority' => 32,
		'description' => __( 'These are the settings for the websites homepage.', '_s' )
	));

	$wp_customize->add_setting( 'smartsearch' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'smartsearch', array(
		'label' => __( 'Use Regular Quick Search?', '_s' ),
		'section' => 'homepage',
		'settings' => 'smartsearch',
		'type' => 'checkbox',
	)));

	$wp_customize->add_setting( 'homequicksearchdisplay' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homequicksearchdisplay', array(
		'label' => __( 'Hide Quick Search', '_s' ),
		'section' => 'homepage',
		'settings' => 'homequicksearchdisplay',
		'type' => 'checkbox',
	)));

	$wp_customize->add_setting( 'homeqsshortcode' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homeqsshortcode', array(
		'label' => __( 'Quick Search Shortcode Override', '_s' ),
		'description' => __('You may place a manual shortcode here if you have more than one MLS area key. Please note that placing a shortcode here will invalidate the checkboxes above.'),
		'section' => 'homepage',
		'settings' => 'homeqsshortcode',
	)));

	$wp_customize->add_setting( 'homequicksearchtitle' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homequicksearchtitle', array(
		'label' => __( 'Quick Search Title {optional}', '_s' ),
		'section' => 'homepage',
		'settings' => 'homequicksearchtitle',
	)));

	$wp_customize->add_setting( 'advancedsearchlink' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'advancedsearchlink', array(
		'label' => __( 'Search By Map Link {optional}', '_s' ),
		'section' => 'homepage',
		'settings' => 'advancedsearchlink',
	)));

	$wp_customize->add_setting( 'searchbygallerylink' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'searchbygallerylink', array(
		'label' => __( 'Search By Gallery Link {optional}', '_s' ),
		'section' => 'homepage',
		'settings' => 'searchbygallerylink',
	)));

	$wp_customize->add_setting( 'searchbylistlinks' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'searchbylistlinks', array(
		'label' => __( 'Search By List Link {optional}', '_s' ),
		'section' => 'homepage',
		'settings' => 'searchbylistlinks',
	)));

	$wp_customize->add_setting( 'homefeatured' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homefeatured', array(
		'label' => __( 'Featured Properties (Please enter your custom WolfNet Featured Listings shortcode)', '_s' ),
		'section' => 'homepage',
		'settings' => 'homefeatured',
	)));
	// $wp_customize->add_setting( 'homefeatured2' , array( 'default' => '' ));
	// $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homefeatured2', array(
	// 	'label' => __( 'Featured Properties Section 2 {optional} (Please enter your custom WolfNet Featured Listings shortcode)', '_s' ),
	// 	'section' => 'homepage',
	// 	'settings' => 'homefeatured2',
	// )));
	// $wp_customize->add_setting( 'homefeatured2_title' , array( 'default' => '' ));
	// $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homefeatured2_title', array(
	// 	'label' => __( 'Featured Properties Section 2 Title {optional}', '_s' ),
	// 	'section' => 'homepage',
	// 	'settings' => 'homefeatured2_title',
	// )));

	$wp_customize->add_setting( 'homefeaturedtitle' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homefeaturedtitle', array(
		'label' => __( 'Featured Properties Title', '_s' ),
		'section' => 'homepage',
		'settings' => 'homefeaturedtitle',
	)));

	$wp_customize->add_setting( 'homegravityform' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homegravityform', array(
		'label' => __( 'Paste Gravity Forms Shortcode', '_s' ),
		'section' => 'homepage',
		'settings' => 'homegravityform',
	)));

	$wp_customize->add_setting( 'front_page_home_value_form' , array( 'type' => 'option' ));
	$wp_customize->add_control(
	    new WP_Customize_Gravity_Forms(
	        $wp_customize,
	        'front_page_home_value_form',
	        array(
				'label' => __( 'Select A Home Value Form', 'mytheme' ),
				'section' => 'homepage',
				'settings' => 'front_page_home_value_form'
	        )
	    )
	);

	// Communities
	$wp_customize->add_section( 'communities' , array(
		'title' => __( 'Communities Settings', '_s' ),
		'priority' => 33,
		'description' => __( 'These are the settings for the communities pages.', '_s' )
	));

	$wp_customize->add_setting( 'communitiesfull' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'communitiesfull', array(
		'label' => __( 'Full width property view (off or on).', '_s' ),
		'section' => 'communities',
		'settings' => 'communitiesfull',
		'type' => 'checkbox',
	)));
	$wp_customize->add_setting( 'communitiestitle' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'communitiestitle', array(
		'label' => __( 'Communities Title', '_s' ),
		'section' => 'communities',
		'settings' => 'communitiestitle',
	)));

	// footer
	$wp_customize->add_section( 'footer' , array(
		'title' => __( 'Footer Text', '_s' ),
		'priority' => 34,
		'description' => __( 'This information will show up in the footer of this site.', '_s' )
	));

	$wp_customize->add_setting( 'fname' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'fname', array(
		'label' => __( 'Your Name', '_s' ),
		'section' => 'footer',
		'settings' => 'fname',
	)));

	// $wp_customize->add_setting( 'frname' , array( 'default' => '' ));
	// $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'frname', array(
	// 	'label' => __( 'Realty Name', '_s' ),
	// 	'section' => 'footer',
	// 	'settings' => 'frname',
	// )));

	$wp_customize->add_setting( 'fphoned' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'fphoned', array(
		'label' => __( 'Phone Number', '_s' ),
		'section' => 'footer',
		'settings' => 'fphoned',
	)));

	$wp_customize->add_setting( 'femail' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'femail', array(
		'label' => __( 'Website Title', '_s' ),
		'section' => 'footer',
		'settings' => 'femail',
	)));

	// Color Scheme
	// $wp_customize->add_section( 'color' , array(
	// 	'title' => __( 'Color Scheme', '_s' ),
	// 	'priority' => 34,
	// 	'description' => __( 'Choose a primary and secondary color for your site to give it a custom feel.', '_s' )
	// ));

	$wp_customize->add_setting( 'cprimary' , array( 'default' => 'CC7300' ));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cprimary', array(
		'label' => __( 'Primary Color (header, containers, strikes)', '_s' ),
		'section' => 'colors',
		'settings' => 'cprimary',
	)));

	$wp_customize->add_setting( 'button_color' , array( 'default' => 'CC7300' ));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'button_color', array(
		'label' => __( 'Button Color (text links, buttons)', '_s' ),
		'section' => 'colors',
		'settings' => 'button_color',
	)));

	$wp_customize->add_setting( 'cprimary_text' , array( 'default' => 'FFFFFF' ));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cprimary_text', array(
		'label' => __( 'Header Text Color', '_s' ),
		'section' => 'colors',
		'settings' => 'cprimary_text',
	)));

	$wp_customize->add_setting( 'csecondary_text' , array( 'default' => 'FFFFFF' ));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'csecondary_text', array(
		'label' => __( 'Footer Text Color', '_s' ),
		'section' => 'colors',
		'settings' => 'csecondary_text',
	)));

	$wp_customize->add_setting( 'csecondary' , array( 'default' => '858585' ));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'csecondary', array(
		'label' => __( 'Footer Background Color', '_s' ),
		'section' => 'colors',
		'settings' => 'csecondary',
	)));

}
add_action( 'customize_register', 'bcore_customize_register' );

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function bcore_customize_preview_js() {
	wp_enqueue_script( 'bcore_customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20130508', true );
}
add_action( 'customize_preview_init', 'bcore_customize_preview_js' );


if ( class_exists('WP_Customize_Control') && class_exists('GFAPI') ) :
	class WP_Customize_Gravity_Forms extends WP_Customize_Control {
		public function render_content() {

			$forms = GFAPI::get_forms();

			?>
				<label>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
					<select <?php $this->link(); ?>>
						<option value="0"> -- Pick one</option>
						<?php
							foreach ( $forms as $form ) {
								echo "<option " . selected( $this->value(), $form['id'] ) . " value='" . $form['id'] . "'>" . $form['title'] . "</option>";
							}
						?>
					</select>
				</label>
			<?php

		}
	}
endif;
