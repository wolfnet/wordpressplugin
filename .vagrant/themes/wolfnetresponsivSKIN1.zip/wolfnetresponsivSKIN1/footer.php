<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package bcore
 */
?>

		<!-- </div> --><!-- #container-->
	</div><!-- .content -->

	<footer id="bcore-footer" class="site-footer" role="contentinfo">
		<div class="container">
			<!-- Footer Section 1 -->
			<div class="footertop">
				<?php $fname = get_theme_mod( 'fname' ); if( !empty( $fname ) ): ?>
					<span><?php echo $fname; ?></span>
				<?php endif; ?>
				<?php $phone_display = get_theme_mod( 'fphoned' ); if( !empty( $phone_display ) ): ?>
					| <span><a href="tel:<?php echo $phone_display; ?>" target="_blank"><?php echo $phone_display; ?></a></span>
				<?php endif; ?>
				<?php //$footer_home_url = esc_url( home_url() ); ?>
				<?php //$footer_home_url = preg_replace('#^http?://#', '', $footer_home_url); ?>
				<?php $footer_home_url = get_theme_mod( 'femail' ); if( !empty( $footer_home_url ) ): ?>
					| <span><a href="<?php echo $footer_home_url; ?>"><?php echo $footer_home_url; ?></a></span>
				<?php endif; ?>
			</div>
			<div class="clear"></div>
			<!-- Footer Section 2 -->
			<div class="footerbottom">
				<div class="clear">
					<span class="footerbottom-1">&copy; <?php echo date("Y") ?> All Rights Reserved</span>
					<img src="<?php bloginfo('template_url') ?>/img/realty.png" alt="realty logos">
				<div class="clear">
					<span class="footerbottom-2">Website Service by <a href="http://wolfnet.com/" target="_blank">WolfNet Technologies</a> and <a href="https://www.brandco.com/" target="_blank">BrandCo</a></span>
				</div>
			</div>
		</div>
	</footer>
</div><!-- #page -->

<?php if ( is_front_page() && get_option('front_page_home_value_form') ) : ?>
	<script>
		function initAutocomplete() {
			jQuery(function($) {
				if ("google" in window && typeof google.maps !== 'undefined') {
					var addressField = $('#homepage-search-box--value input[type="text"]');
					var addressFieldId = addressField.attr('id');
					var addressFieldElement = document.getElementById(addressFieldId);
					var autocomplete = new google.maps.places.Autocomplete(addressFieldElement);
					if ( $('.validation_error').length > 0 ) {
						$('#homepage-search-box').attr('data-search-box', 'value');
						$('.gfield').removeClass('gfield_error');
					}
					$('#homepage-search-box--toggle-search').click(function() {
						$('.homepage-search-box .validation_error, .homepage-search-box .gfield_description.validation_message').remove();
					});
				}
			});
		}
		var loadScript = true;
		if ("google" in window && typeof google.maps !== 'undefined') loadScript = false;
		jQuery(function($) {
			$.cachedScript = function( url, options ) {
					options = $.extend( options || {}, {
					dataType: "script",
					cache: true,
					url: url
				});
				return $.ajax( options );
			};
			if (!loadScript) {
				// inlined
				google.maps.__gjsload__('places', function(_){'use strict';var Hw=function(a,b){try{_.Kb(window.HTMLInputElement,"HTMLInputElement")(a)}catch(c){if(_.Hb(c),!a)return}_.F("places_impl",(0,_.p)(function(c){b=b||{};this.setValues(b);c.b(this,a);_.Oe(a)},this))},Iw=function(){this.b=null;_.F("places_impl",(0,_.p)(function(a){this.b=a.l()},this))},Jw=function(a){this.b=null;_.F("places_impl",(0,_.p)(function(b){this.b=b.f(a)},this))},Kw=function(a,b){_.F("places_impl",(0,_.p)(function(c){c.j(this,a);b=b||{};this.setValues(b)},this))};_.t(Hw,_.C);Hw.prototype.setTypes=_.vc("types",_.Mb(_.Wg));Hw.prototype.setComponentRestrictions=_.vc("componentRestrictions");_.wc(Hw.prototype,{place:null,bounds:_.Qb(_.ae)});Iw.prototype.getPlacePredictions=function(a,b){_.F("places_impl",(0,_.p)(function(){this.b.getPlacePredictions(a,b)},this))};Iw.prototype.getPredictions=Iw.prototype.getPlacePredictions;Iw.prototype.getQueryPredictions=function(a,b){_.F("places_impl",(0,_.p)(function(){this.b.getQueryPredictions(a,b)},this))};_.k=Jw.prototype;_.k.getDetails=function(a,b){_.F("places_impl",(0,_.p)(function(){this.b.getDetails(a,b)},this))};_.k.nearbySearch=function(a,b){_.F("places_impl",(0,_.p)(function(){this.b.nearbySearch(a,b)},this))};_.k.search=Jw.prototype.nearbySearch;_.k.textSearch=function(a,b){_.F("places_impl",(0,_.p)(function(){this.b.textSearch(a,b)},this))};_.k.radarSearch=function(a,b){_.F("places_impl",(0,_.p)(function(){this.b.radarSearch(a,b)},this))};_.t(Kw,_.C);_.wc(Kw.prototype,{places:null,bounds:_.Qb(_.ae)});_.Nc.google.maps.places={PlacesService:Jw,PlacesServiceStatus:{OK:_.ha,UNKNOWN_ERROR:_.ka,OVER_QUERY_LIMIT:_.ia,REQUEST_DENIED:_.ja,INVALID_REQUEST:_.ca,ZERO_RESULTS:_.la,NOT_FOUND:_.ga},AutocompleteService:Iw,Autocomplete:Hw,SearchBox:Kw,RankBy:{PROMINENCE:0,DISTANCE:1},RatingLevel:{GOOD:0,VERY_GOOD:1,EXCELLENT:2,EXTRAORDINARY:3}};_.lc("places",{});});
			} else {
				$.cachedScript( "https://maps.googleapis.com/maps/api/js?key=AIzaSyBfEzWjcytuQ3VsBCE-9qi4zHptECX6sig&libraries=geometry,places&callback=initAutocomplete" ).done(function( script, textStatus ) {});
			}
			$(document).ready(function() {
				initAutocomplete();
			});
		});
	</script>
<?php endif; ?>
<script>
	jQuery(function($) {
		$('#homepage-search-box--toggle-value').click(function() {
			$('#homepage-search-box').attr('data-search-box', 'value');
		});
		$('#homepage-search-box--toggle-search').click(function() {
			$('#homepage-search-box').attr('data-search-box', 'search');
		});
	}); 
</script>

<?php wp_footer(); ?>

</body>
</html>
