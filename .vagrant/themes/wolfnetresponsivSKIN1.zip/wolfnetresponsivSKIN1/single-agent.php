<?php
/**
 * The Template for displaying all single posts.
 *
 * @package bcore
 */

get_header(); ?>

	<div class="container">
		<div id="primary" class="content-area">
			<main id="main" class="site-main" role="main">

			<?php while ( have_posts() ) : the_post(); ?>

				<?php get_template_part( 'content', 'single' ); ?>

				<h3>Agent Details</h3>
				<?php $agent_title = get_post_meta( $post->ID, '_my_meta_value_key1', true ); if( !empty( $agent_title ) ): ?>
					<p>Title: <?php echo $agent_title; ?></p>
				<?php endif; ?>
				<?php $agent_phone = get_post_meta( $post->ID, '_my_meta_value_key2', true ); if( !empty( $agent_phone ) ): ?>
					<p>Phone: <?php echo $agent_phone; ?></p>
				<?php endif; ?>
				<?php $agent_email = get_post_meta( $post->ID, '_my_meta_value_key3', true ); if( !empty( $agent_email ) ): ?>
					<p>Email: <?php echo $agent_email; ?></p>
				<?php endif; ?>
				<?php $agent_listings = get_post_meta( $post->ID, '_my_meta_value_key4', true ); if( !empty( $agent_listings ) ): ?>
					<p>Listings: <?php echo $agent_listings; ?></p>
				<?php endif; ?>
				<?php $agent_website = get_post_meta( $post->ID, '_my_meta_value_key5', true ); if( !empty( $agent_website ) ): ?>
					<p>Website: <?php echo $agent_website; ?></p>
				<?php endif; ?>
				<?php $agent_facebook = get_post_meta( $post->ID, '_my_meta_value_key6', true ); if( !empty( $agent_facebook ) ): ?>
					<p>Facebook: <?php echo $agent_facebook; ?></p>
				<?php endif; ?>
				<?php $agent_twitter = get_post_meta( $post->ID, '_my_meta_value_key7', true ); if( !empty( $agent_twitter ) ): ?>
					<p>Twitter: <?php echo $agent_twitter; ?></p>
				<?php endif; ?>
				<?php $agent_linkedin = get_post_meta( $post->ID, '_my_meta_value_key8', true ); if( !empty( $agent_linkedin ) ): ?>
					<p>LinkedIn: <?php echo $agent_linkedin; ?></p>
				<?php endif; ?>
				<?php $agent_featured = get_post_meta( $post->ID, '_my_meta_value_key9', true ); if( !empty( $agent_featured ) ): ?>
					<p>Featured Listings: <?php echo $agent_featured; ?></p>
				<?php endif; ?>

				<?php // bcore_post_nav(); ?>

				<?php
					// If comments are open or we have at least one comment, load up the comment template
					if ( comments_open() || '0' != get_comments_number() ) :
						comments_template();
					endif;
				?>

			<?php endwhile; // end of the loop. ?>

			</main><!-- #main -->
		</div><!-- #primary -->

		<?php get_sidebar(); ?>
	</div>

<?php get_footer(); ?>