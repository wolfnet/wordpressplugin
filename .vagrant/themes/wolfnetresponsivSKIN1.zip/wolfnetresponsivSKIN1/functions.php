<?php
/**
 * bcore functions and definitions
 *
 * @package bcore
 */

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 640; /* pixels */
}

if ( ! function_exists( 'bcore_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function bcore_setup() {

	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on bcore, use a find and replace
	 * to change 'bcore' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'bcore', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );
	// add_image_size( 'homepage-thumb', 433, 231, false );
	// add_image_size( 'header-logob', 143, 40, false );
	// add_image_size( 'header-imageheader', 433, 231, true );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'bcore' ),
	) );
	
	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
	) );

	/*
	 * Enable support for Post Formats.
	 * See http://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array(
		'aside', 'image', 'video', 'quote', 'link'
	) );

	// Setup the WordPress core custom background feature.
	// add_theme_support( 'custom-background', apply_filters( 'bcore_custom_background_args', array(
	// 	'default-color' => 'ffffff',
	// 	'default-image' => '',
	// ) ) );
}
endif; // bcore_setup
add_action( 'after_setup_theme', 'bcore_setup' );

/**
 * Register widget area.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_sidebar
 */
function bcore_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Default Sidebar', 'bcore' ),
		'id'            => 'sidebar-1',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );
}
add_action( 'widgets_init', 'bcore_widgets_init' );
function bcore_widgets_init_2() {
	register_sidebar( array(
		'name'          => __( 'Homepage Footer Widget Left', 'bcore' ),
		'id'            => 'footer1',
		'description'   => 'This goes on the left side of the footer.',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );
}
add_action( 'widgets_init', 'bcore_widgets_init_2' );
function bcore_widgets_init_3() {
	register_sidebar( array(
		'name'          => __( 'Homepage Footer Widget Right', 'bcore' ),
		'id'            => 'footer2',
		'description'   => 'This goes on the right side of the footer.',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );
}
add_action( 'widgets_init', 'bcore_widgets_init_3' );
function bcore_widgets_init_4() {
	register_sidebar( array(
		'name'          => __( 'Blog Sidebar', 'bcore' ),
		'id'            => 'blog',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );
}
add_action( 'widgets_init', 'bcore_widgets_init_4' );
function bcore_widgets_init_5() {
	register_sidebar( array(
		'name'          => __( 'Sellers Sidebar', 'bcore' ),
		'id'            => 'sellers',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );
}
add_action( 'widgets_init', 'bcore_widgets_init_5' );
function bcore_widgets_init_6() {
	register_sidebar( array(
		'name'          => __( 'Buyers Sidebar', 'bcore' ),
		'id'            => 'buyers',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );
}
add_action( 'widgets_init', 'bcore_widgets_init_6' );

/**
 * Enqueue scripts and styles.
 */
function bcore_scripts() {
	wp_enqueue_style( 'bcore-style', get_stylesheet_uri(), array(), '1.39' );
	// wp_enqueue_style( 'bcore-fontawesome-style', 'http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css', array(), '1', true );
	wp_enqueue_style( 'bcore-fa-css', get_template_directory_uri() . '/icomoon/style.css', '1.39'  );

	wp_enqueue_script( 'jquery' );

	wp_enqueue_script( 'theteamrealty-scripts', get_template_directory_uri() . '/js/scripts.js', array(), '1.39', false );
	// wp_enqueue_script( 'bcore-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20120206', false );
	wp_enqueue_script( 'bcore-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20130115', false );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'bcore_scripts' );

function load_custom_wp_admin_style() {
	wp_register_style( 'custom_wp_admin_css', get_template_directory_uri() . '/css/admin.css', true, '1' );
	wp_enqueue_style( 'custom_wp_admin_css' );
}
add_action( 'admin_enqueue_scripts', 'load_custom_wp_admin_style' );

// function load_custom_wp_admin_style() {
//         wp_register_style( 'custom_wp_admin_css', get_template_directory_uri() . '/admin-style.css', false, '1.0.0' );
//         wp_enqueue_style( 'custom_wp_admin_css' );
// }
// add_action( 'admin_enqueue_scripts', 'load_custom_wp_admin_style' );

/**
 * Implement the Custom Header feature.
 */
//require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

// excerpt length
function custom_excerpt_length( $length ) {
	return 50;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );
// old excerpt text
// function new_excerpt_more($more) {
// 	global $post;
// 	return '... <a class="readmore" href="'. get_permalink($post->ID) . '">Read More &raquo;</a>';
// }
// add_filter('excerpt_more', 'new_excerpt_more');
// Replaces the excerpt "more" text by a link
function new_excerpt_more($more) {
	global $post;
	return ' <a class="moretag" href="'. get_permalink($post->ID) . '">Read More</a>';
}
add_filter('excerpt_more', 'new_excerpt_more');

// [hr]
function hr_short_func( $atts ){
	return "<hr>";
}
add_shortcode( 'hr', 'hr_short_func' );

add_action( 'init', 'codex_community_init' );
/**
 * Register a community/area/city post type.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_post_type
 */
function codex_community_init() {
	$labels = array(
		'name'               => _x( 'Communities', 'post type general name', 'your-plugin-textdomain' ),
		'singular_name'      => _x( 'Community', 'post type singular name', 'your-plugin-textdomain' ),
		'menu_name'          => _x( 'Communities', 'admin menu', 'your-plugin-textdomain' ),
		'name_admin_bar'     => _x( 'Community', 'add new on admin bar', 'your-plugin-textdomain' ),
		'add_new'            => _x( 'Add New', 'book', 'your-plugin-textdomain' ),
		'add_new_item'       => __( 'Add New Community', 'your-plugin-textdomain' ),
		'new_item'           => __( 'New Community', 'your-plugin-textdomain' ),
		'edit_item'          => __( 'Edit Community', 'your-plugin-textdomain' ),
		'view_item'          => __( 'View Community', 'your-plugin-textdomain' ),
		'all_items'          => __( 'All Communities', 'your-plugin-textdomain' ),
		'search_items'       => __( 'Search Communities', 'your-plugin-textdomain' ),
		'parent_item_colon'  => __( 'Parent Communities:', 'your-plugin-textdomain' ),
		'not_found'          => __( 'No community found.', 'your-plugin-textdomain' ),
		'not_found_in_trash' => __( 'No community found in Trash.', 'your-plugin-textdomain' )
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'community' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'menu_icon'          => 'dashicons-location-alt',
		'supports'           => array( 'title', 'editor', 'author', 'thumbnail' ),
		'cptp_permalink_structure'     => '/%postname%/'
	);

	register_post_type( 'city', $args );
}

add_action( 'init', 'codex_agent_init' );
/**
 * Register a agent post type.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_post_type
 */
function codex_agent_init() {
	$labels = array(
		'name'               => _x( 'Agents', 'post type general name', 'your-plugin-textdomain' ),
		'singular_name'      => _x( 'Agent', 'post type singular name', 'your-plugin-textdomain' ),
		'menu_name'          => _x( 'Agents', 'admin menu', 'your-plugin-textdomain' ),
		'name_admin_bar'     => _x( 'Agent', 'add new on admin bar', 'your-plugin-textdomain' ),
		'add_new'            => _x( 'Add New', 'book', 'your-plugin-textdomain' ),
		'add_new_item'       => __( 'Add New Agent', 'your-plugin-textdomain' ),
		'new_item'           => __( 'New Agent', 'your-plugin-textdomain' ),
		'edit_item'          => __( 'Edit Agent', 'your-plugin-textdomain' ),
		'view_item'          => __( 'View Agent', 'your-plugin-textdomain' ),
		'all_items'          => __( 'All Agents', 'your-plugin-textdomain' ),
		'search_items'       => __( 'Search Agents', 'your-plugin-textdomain' ),
		'parent_item_colon'  => __( 'Parent Agents:', 'your-plugin-textdomain' ),
		'not_found'          => __( 'No agent found.', 'your-plugin-textdomain' ),
		'not_found_in_trash' => __( 'No agent found in Trash.', 'your-plugin-textdomain' )
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'agent' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'menu_icon'          => 'dashicons-groups',
		'supports'           => array( 'title', 'editor', 'author', 'thumbnail' ),
		'cptp_permalink_structure'     => '/%postname%/'
	);

	register_post_type( 'agent', $args );
}

/**
 * Adds a box to the main column on the Post and Page edit screens.
 */
// function myplugin_add_meta_box_fullwidth() {

// 	$screens = array( 'post', 'page', 'city', 'agent' );

// 	foreach ( $screens as $screen ) {

// 		add_meta_box(
// 			'myplugin_sectionid_fullwidth',
// 			__( 'Full Width', 'myplugin_textdomain_fullwidth' ),
// 			'myplugin_meta_box_callback_fullwidth',
// 			$screen,
// 			'side'
// 		);
// 	}
// }
// add_action( 'add_meta_boxes', 'myplugin_add_meta_box_fullwidth' );

/**
 * Prints the box content.
 * 
 * @param WP_Post $post The object for the current post/page.
 */
// function myplugin_meta_box_callback_fullwidth( $post ) {

// 	wp_nonce_field( 'myplugin_meta_box', 'myplugin_meta_box_nonce' );

// 	post_meta( $post->ID, '_my_meta_value_key_fw', true );
	
// 	$prfx_stored_meta_fullwidth = get_post_meta( $post->ID );

// 	echo '<label for="meta-checkbox">';
// 	    echo '<input type="checkbox" name="meta-checkbox" id="meta-checkbox" value="yes"';
// 	    if ( isset ( $prfx_stored_meta_fullwidth['meta-checkbox'] ) ) checked( $prfx_stored_meta_fullwidth['meta-checkbox'][0], 'yes' );
// 	    echo '/>';
// 	    _e( 'Checking this hides the sidebar and makes the content full width', 'prfx-textdomain' );
// 	echo '</label>';
// }

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
// function myplugin_save_meta_box_data_fullwidth( $post_id ) {

// 	if ( ! isset( $_POST['myplugin_meta_box_nonce'] ) ) {
// 		return;
// 	}

// 	if ( ! wp_verify_nonce( $_POST['myplugin_meta_box_nonce'], 'myplugin_meta_box' ) ) {
// 		return;
// 	}

// 	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
// 		return;
// 	}

// 	if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {

// 		if ( ! current_user_can( 'edit_page', $post_id ) ) {
// 			return;
// 		}

// 	} else {

// 		if ( ! current_user_can( 'edit_post', $post_id ) ) {
// 			return;
// 		}
// 	}

// 	if ( ! isset( $_POST['meta-checkbox'] ) ) {
// 		return;
// 	}

// 	$my_data = sanitize_text_field( $_POST['meta-checkbox'] );

// 	if( isset( $_POST[ 'meta-checkbox' ] ) ) {
// 		update_post_meta( $post_id, 'meta-checkbox', 'yes' );
// 	} else {
// 		update_post_meta( $post_id, 'meta-checkbox', '' );
// 	}
// }
// add_action( 'save_post', 'myplugin_save_meta_box_data_fullwidth' );

/**
 * Meta box for agent cpt
 */
function myplugin_add_meta_box_agent() {

	$screens = array( 'agent' );

	foreach ( $screens as $screen ) {

		add_meta_box(
			'myplugin_sectionid_agent',
			__( 'Information', 'myplugin_textdomain_agent' ),
			'myplugin_meta_box_callback_agent',
			$screen
		);
	}
}
add_action( 'add_meta_boxes', 'myplugin_add_meta_box_agent' );

/**
 * Prints the box content.
 * 
 * @param WP_Post $post The object for the current agent.
 */
function myplugin_meta_box_callback_agent( $post ) {

	// Add an nonce field so we can check for it later.
	wp_nonce_field( 'myplugin_meta_box', 'myplugin_meta_box_nonce' );

	/*
	 * Use get_post_meta() to retrieve an existing value
	 * from the database and use the value for the form.
	 */
	// global $post;
	// $info = get_post_meta( $post->ID, '_info', true );
	// $info_array = wp_parse_args($info,array('agenttitle' =>'','agentphone' =>'','agentemail' =>'','agentlistings' =>'','agentwebsite' =>'','facebook' => '','twitter' => '','linkedin' => '','featuredlistings' => ''));
	// extract($info_array);
	
	$value_agenttitle = get_post_meta( $post->ID, '_my_meta_value_key1', true );
	$value_agentphone = get_post_meta( $post->ID, '_my_meta_value_key2', true );
	$value_agentemail = get_post_meta( $post->ID, '_my_meta_value_key3', true );
	$value_agentlistings = get_post_meta( $post->ID, '_my_meta_value_key4', true );
	$value_agentwebsite = get_post_meta( $post->ID, '_my_meta_value_key5', true );
	$value_facebook = get_post_meta( $post->ID, '_my_meta_value_key6', true );
	$value_twitter = get_post_meta( $post->ID, '_my_meta_value_key7', true );
	$value_linkedin = get_post_meta( $post->ID, '_my_meta_value_key8', true );
	$value_featuredlistings = get_post_meta( $post->ID, '_my_meta_value_key9', true );

	echo '<label for="myplugin_new_field1">';
	_e( 'Agent Title', 'myplugin_textdomain1' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field1" name="myplugin_new_field1" value="' . esc_attr( $value_agenttitle ) . '" size="25" />';

	echo '<br />';
	echo '<br />';

	echo '<label for="myplugin_new_field2">';
	_e( 'Agent Phone Number', 'myplugin_textdomain2' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field2" name="myplugin_new_field2" value="' . esc_attr( $value_agentphone ) . '" size="25" />';

	echo '<br />';
	echo '<br />';

	echo '<label for="myplugin_new_field3">';
	_e( 'Agent Email Address', 'myplugin_textdomain3' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field3" name="myplugin_new_field3" value="' . esc_attr( $value_agentemail ) . '" size="25" />';

	echo '<br />';
	echo '<br />';

	echo '<label for="myplugin_new_field4">';
	_e( 'Agent Listings (URL)', 'myplugin_textdomain4' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field4" name="myplugin_new_field4" value="' . esc_attr( $value_agentlistings ) . '" size="25" />';

	echo '<br />';
	echo '<br />';

	echo '<label for="myplugin_new_field5">';
	_e( 'Agent Website (URL)', 'myplugin_textdomain5' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field5" name="myplugin_new_field5" value="' . esc_attr( $value_agentwebsite ) . '" size="25" />';

	echo '<br />';
	echo '<br />';

	echo '<label for="myplugin_new_field6">';
	_e( 'Facebook (URL)', 'myplugin_textdomain6' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field6" name="myplugin_new_field6" value="' . esc_attr( $value_facebook ) . '" size="25" />';

	echo '<br />';
	echo '<br />';

	echo '<label for="myplugin_new_field7">';
	_e( 'Twitter (URL)', 'myplugin_textdomain7' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field7" name="myplugin_new_field7" value="' . esc_attr( $value_twitter ) . '" size="25" />';

	echo '<br />';
	echo '<br />';

	echo '<label for="myplugin_new_field8">';
	_e( 'LinkeIn (URL)', 'myplugin_textdomain8' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field8" name="myplugin_new_field8" value="' . esc_attr( $value_linkedin ) . '" size="25" />';

	echo '<br />';
	echo '<br />';

	echo '<label for="myplugin_new_field9">';
	_e( 'Agent Featured Listings Code', 'myplugin_textdomain9' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field9" name="myplugin_new_field9" value="' . esc_attr( $value_featuredlistings ) . '" size="25" />';
	
	// global $post;
	// $info = wp_parse_args(get_post_meta($post->ID,'_info',true),array('agenttitle' =>'','agentphone' =>'','agentemail' =>'','agentlistings' =>'','agentwebsite' =>'','facebook' => '','twitter' => '','linkedin' => '','featuredlistings' => ''));
	// extract($info);

	// echo '<input type="hidden" name="' . $this->nonce . '_noncename" id="' . $this->nonce . '_noncename" value="' . wp_create_nonce( __FILE__ ) . '" />';

	// echo '<p><strong>Agent Title</strong><br />';
	// echo '<input type="text" name="info[agenttitle]" value="' . $agenttitle . '" style="width: 100%;" /></p>';

	// echo '<p><strong>Agent Phone Number</strong><br />';
	// echo '<input type="text" name="info[agentphone]" value="' . $agentphone . '" style="width: 100%;" /></p>';

	// echo '<p><strong>Agent Email Address</strong><br />';
	// echo '<input type="text" name="info[agentemail]" value="' . $agentemail . '" style="width: 100%;" /></p>';

	// echo '<p><strong>Agent Listings (URL)</strong><br />';
	// echo '<input type="text" name="info[agentlistings]" value="' . $agentlistings . '" style="width: 100%;" /></p>';

	// echo '<p><strong>Agent Website (URL)</strong><br />';
	// echo '<input type="text" name="info[agentwebsite]" value="' . $agentwebsite . '" style="width: 100%;" /></p>';

	// echo '<p><strong>Facebook (URL)</strong><br />';
	// echo '<input type="text" class="code" name="info[facebook]" value="' . $facebook . '" style="width: 100%;" /></p>';

	// echo '<p><strong>Twitter (URL)</strong><br />';
	// echo '<input type="text" class="code" name="info[twitter]" value="' . $twitter . '" style="width: 100%;" /></p>';

	// echo '<p><strong>LinkedIn (URL)</strong><br />';
	// echo '<input type="text" class="code" name="info[linkedin]" value="' . $linkedin . '" style="width: 100%;" /></p>';

	// echo '<p><strong>Agent Featured Listings Code</strong><br />';
	// echo '<textarea class="code" name="info[featuredlistings]" style="width: 100%;" />' . $featuredlistings . '</textarea><br /><span style="font-size: 10px; font-style: italic;">Get this from ther WNT WP Plugin</span></p>';
}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function myplugin_save_meta_box_data_agent( $post_id ) {

	/*
	 * We need to verify this came from our screen and with proper authorization,
	 * because the save_post action can be triggered at other times.
	 */

	// Check if our nonce is set.
	if ( ! isset( $_POST['myplugin_meta_box_nonce'] ) ) {
		return;
	}

	// Verify that the nonce is valid.
	if ( ! wp_verify_nonce( $_POST['myplugin_meta_box_nonce'], 'myplugin_meta_box' ) ) {
		return;
	}

	// If this is an autosave, our form has not been submitted, so we don't want to do anything.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	// Check the user's permissions.
	if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {

		if ( ! current_user_can( 'edit_page', $post_id ) ) {
			return;
		}

	} else {

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
	}

	/* OK, it's safe for us to save the data now. */
	
	// Make sure that it is set.
	if ( ! isset( $_POST['myplugin_new_field1'] ) ) {
		return;
	}
	if ( ! isset( $_POST['myplugin_new_field2'] ) ) {
		return;
	}
	if ( ! isset( $_POST['myplugin_new_field3'] ) ) {
		return;
	}
	if ( ! isset( $_POST['myplugin_new_field4'] ) ) {
		return;
	}
	if ( ! isset( $_POST['myplugin_new_field5'] ) ) {
		return;
	}
	if ( ! isset( $_POST['myplugin_new_field6'] ) ) {
		return;
	}
	if ( ! isset( $_POST['myplugin_new_field7'] ) ) {
		return;
	}
	if ( ! isset( $_POST['myplugin_new_field8'] ) ) {
		return;
	}
	if ( ! isset( $_POST['myplugin_new_field9'] ) ) {
		return;
	}

	// Sanitize user input.
	$my_data1 = sanitize_text_field( $_POST['myplugin_new_field1'] );
	$my_data2 = sanitize_text_field( $_POST['myplugin_new_field2'] );
	$my_data3 = sanitize_text_field( $_POST['myplugin_new_field3'] );
	$my_data4 = sanitize_text_field( $_POST['myplugin_new_field4'] );
	$my_data5 = sanitize_text_field( $_POST['myplugin_new_field5'] );
	$my_data6 = sanitize_text_field( $_POST['myplugin_new_field6'] );
	$my_data7 = sanitize_text_field( $_POST['myplugin_new_field7'] );
	$my_data8 = sanitize_text_field( $_POST['myplugin_new_field8'] );
	$my_data9 = sanitize_text_field( $_POST['myplugin_new_field9'] );

	// Update the meta field in the database.
	update_post_meta( $post_id, '_my_meta_value_key1', $my_data1 );
	update_post_meta( $post_id, '_my_meta_value_key2', $my_data2 );
	update_post_meta( $post_id, '_my_meta_value_key3', $my_data3 );
	update_post_meta( $post_id, '_my_meta_value_key4', $my_data4 );
	update_post_meta( $post_id, '_my_meta_value_key5', $my_data5 );
	update_post_meta( $post_id, '_my_meta_value_key6', $my_data6 );
	update_post_meta( $post_id, '_my_meta_value_key7', $my_data7 );
	update_post_meta( $post_id, '_my_meta_value_key8', $my_data8 );
	update_post_meta( $post_id, '_my_meta_value_key9', $my_data9 );
	
	// update_post_meta($post_id,'_info',$_POST['info']);
}
add_action( 'save_post', 'myplugin_save_meta_box_data_agent' );

/**
 * Adds a box to the main column on the Post and Page edit screens.
 */
function myplugin_add_meta_box_community() {

	$screens = array( 'city' );

	foreach ( $screens as $screen ) {

		add_meta_box(
			'myplugin_sectionid_community',
			__( 'Featured Community Option (For Homepage)', 'myplugin_textdomain_community' ),
			'myplugin_meta_box_callback_community',
			$screen,
			'normal',
			'high'
		);
	}
}
add_action( 'add_meta_boxes', 'myplugin_add_meta_box_community' );

/**
 * Prints the box content.
 * 
 * @param WP_Post $post The object for the current post/page.
 */
function myplugin_meta_box_callback_community( $post ) {

	// Add an nonce field so we can check for it later.
	wp_nonce_field( 'myplugin_meta_box', 'myplugin_meta_box_nonce' );

	/*
	 * Use get_post_meta() to retrieve an existing value
	 * from the database and use the value for the form.
	 */
	$prfx_stored_meta = get_post_meta( $post->ID );

	?>
	<p>
	    <span class="prfx-row-title"><?php _e( 'Note: Only select 3, 6, 9, 12 featured communites for the homepage. Any additional communities will be hidden.', 'prfx-textdomain' )?></span>
	    <div class="prfx-row-content">
	        <label for="meta-checkbox">
	            <input type="checkbox" name="meta-checkbox" id="meta-checkbox" value="yes" <?php if ( isset ( $prfx_stored_meta['meta-checkbox'] ) ) checked( $prfx_stored_meta['meta-checkbox'][0], 'yes' ); ?> />
	            <?php _e( 'Featured Community (Displays this community on the homepage)', 'prfx-textdomain' )?>
	        </label>
	    </div>
	    <div class="prfx-row-content">
	        <label for="meta-checkbox-two">
	            <input type="checkbox" name="meta-checkbox-two" id="meta-checkbox-two" value="yes" <?php if ( isset ( $prfx_stored_meta['meta-checkbox-two'] ) ) checked( $prfx_stored_meta['meta-checkbox-two'][0], 'yes' ); ?> />
	            <?php _e( 'Display this community on phone? Note: Community must also be featured.', 'prfx-textdomain' )?>
	        </label>
	    </div>
	</p>
	<?php

}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function myplugin_save_meta_box_data_community( $post_id ) {

	/*
	 * We need to verify this came from our screen and with proper authorization,
	 * because the save_post action can be triggered at other times.
	 */

	// Check if our nonce is set.
	if ( ! isset( $_POST['myplugin_meta_box_nonce'] ) ) {
		return;
	}

	// Verify that the nonce is valid.
	if ( ! wp_verify_nonce( $_POST['myplugin_meta_box_nonce'], 'myplugin_meta_box' ) ) {
		return;
	}

	// If this is an autosave, our form has not been submitted, so we don't want to do anything.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	// Check the user's permissions.
	if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {

		if ( ! current_user_can( 'edit_page', $post_id ) ) {
			return;
		}

	} else {

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
	}

	/* OK, it's safe for us to save the data now. */

	// Checks for input and saves
	if( isset( $_POST[ 'meta-checkbox' ] ) ) {
	    update_post_meta( $post_id, 'meta-checkbox', 'yes' );
	} else {
	    update_post_meta( $post_id, 'meta-checkbox', '' );
	}
	 
	// Checks for input and saves
	if( isset( $_POST[ 'meta-checkbox-two' ] ) ) {
	    update_post_meta( $post_id, 'meta-checkbox-two', 'yes' );
	} else {
	    update_post_meta( $post_id, 'meta-checkbox-two', '' );
	}
}
add_action( 'save_post', 'myplugin_save_meta_box_data_community' );

/** Start of Remove Date TimeStamp from blog posts */
function remove_post_dates() {

	$classes = get_body_class();
	if ( in_array('single-city', $classes )){
		add_filter('the_time', '__return_false');
		add_filter('get_the_time', '__return_false');
		add_filter('the_modified_time', '__return_false');
		add_filter('get_the_modified_time', '__return_false');
		add_filter('the_date', '__return_false');
		add_filter('get_the_date', '__return_false');
		add_filter('the_modified_date', '__return_false');
		add_filter('get_the_modified_date', '__return_false');
		add_filter('get_comment_date', '__return_false');
		add_filter('get_comment_time', '__return_false');
	}
}
add_action('loop_start', 'remove_post_dates');
/** End of Remove Date TimeStamp from blog posts */

// create city blog post type
if ( ! function_exists('community_posts_custom_post_type') ) {

	// Register Custom Post Type
	function community_posts_custom_post_type() {

		$labels = array(
			'name'                => _x( 'Community Posts', 'Post Type General Name', 'text_domain' ),
			'singular_name'       => _x( 'Community Post', 'Post Type Singular Name', 'text_domain' ),
			'menu_name'           => __( 'Community Posts', 'text_domain' ),
			'name_admin_bar'      => __( 'Community Post', 'text_domain' ),
			'parent_item_colon'   => __( 'Parent Community Post:', 'text_domain' ),
			'all_items'           => __( 'All Community Posts', 'text_domain' ),
			'add_new_item'        => __( 'Add New Community Post', 'text_domain' ),
			'add_new'             => __( 'Add New', 'text_domain' ),
			'new_item'            => __( 'New Community Post', 'text_domain' ),
			'edit_item'           => __( 'Edit Community Post', 'text_domain' ),
			'update_item'         => __( 'Update Community Post', 'text_domain' ),
			'view_item'           => __( 'View Community Post', 'text_domain' ),
			'search_items'        => __( 'Search Community Post', 'text_domain' ),
			'not_found'           => __( 'No Community Post found', 'text_domain' ),
			'not_found_in_trash'  => __( 'No Community Post found in Trash', 'text_domain' ),
		);
		$rewrite = array(
			'slug'                => 'community',
			'with_front'          => false,
			'pages'               => true,
			'feeds'               => true,
		);
		$args = array(
			'label'               => __( 'city_post', 'text_domain' ),
			'description'         => __( 'This section is for writing blog posts about your communities', 'text_domain' ),
			'labels'              => $labels,
			'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', ),
			// 'taxonomies'          => array( 'category', 'post_tag' ),
			'hierarchical'        => false,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'menu_position'       => 5,
			'show_in_admin_bar'   => true,
			'show_in_nav_menus'   => true,
			'can_export'          => true,
			'has_archive'         => true,		
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'rewrite'             => $rewrite,
			'capability_type'     => 'post',
			'cptp_permalink_structure'     => '/%communities%/%postname%/',
		);
		register_post_type( 'city_post', $args );

	}

	// Hook into the 'init' action
	add_action( 'init', 'community_posts_custom_post_type', 0 );

}

// communities taxonomy
function create_community_post_tax_wolfnet_instant_sites() {
	register_taxonomy(
		'communities',
		'city_post',
		array(
			'label' => __( 'Communities' ),
			'rewrite' => array( 'slug' => 'communities' ),
			'hierarchical' => true,
			'show_admin_column' => true,
			'show_in_quick_edit' => false,
			'show_in_nav_menus'   => false,
		)
	);
}
add_action( 'init', 'create_community_post_tax_wolfnet_instant_sites' );

// create taxonomy on every page load
function create_categories_based_on_city() {
	$allcityposts = array( 'post_type' => 'city', 'posts_per_page' => -1 );
	$allcitypostslist = get_posts( $allcityposts );
	foreach ( $allcitypostslist as $post ) : setup_postdata( $post ); ?>
		<?php
		$city_parents_wolf_instant_tax = get_post_ancestors( $post->ID );
		if( $city_parents_wolf_instant_tax == null ) {
			wp_insert_term(
				esc_html( $post->post_title ),
				'communities',
				array(
					'description'	=> 'This is a category for linking up community posts with its community.',
					'slug' 		=> basename( get_permalink( $post->ID ) )
				)
			);
		}
		?>
	<?php endforeach; 
	wp_reset_postdata();
}
add_action( 'admin_footer', 'create_categories_based_on_city' );

add_action('wp_head', 'theme_colors_on_home_value');
function theme_colors_on_home_value() {
	$color_main = get_theme_mod('cprimary');
	$color_button_link = get_theme_mod('button_color');
	?>
		<style>
			.bco-landing-pages--wrapper .gform_heading h1,
			.bco-landing-pages--wrapper .gform_heading h2,
			.bco-landing-pages--wrapper .gform_heading h3,
			.bco-landing-pages--wrapper .gform_heading {
				color: #fff !important;
			}
			.bco-landing-pages--wrapper .gform_heading {
				color: #fff !important;
				background-color: <?php echo $color_main; ?> !important;
			}
			.bco-landing-pages--wrapper .gform_footer input[type="submit"] {
				background-color: <?php echo $color_button_link; ?> !important;
			}

			.gfield_error .gfield_description.validation_message,
			.validation_error,
			.gform_validation_error .validation_message {
				color: red;
				font-size: 12px;
				margin: 5px 0;
			}
			.gfield_required {
				color: red;
			}

			body.home .gform_wrapper .top_label li.gfield.gf_left_half {
				clear: both;
			}
		</style>
	<?php
}

if ( ! function_exists('brandco_remove_custom_fields_metabox') ) :
	add_action('add_meta_boxes', 'brandco_remove_custom_fields_metabox');
	function brandco_remove_custom_fields_metabox() {
		global $post_type;
		if ( is_admin() && post_type_supports( $post_type, 'custom-fields' ) ) {
			remove_meta_box( 'postcustom', 'page', 'normal' );
			remove_meta_box( 'postcustom', 'post', 'normal' );
		}
	}
endif;

add_filter('wpseo_enable_xml_sitemap_transient_caching', '__return_false');

/** Gravity Forms Fixes */
add_filter('gform_confirmation_anchor', '__return_true');
add_filter('gform_tabindex', 'gform_tabindexer', 10, 2);
function gform_tabindexer($tab_index, $form = false) {
	$starting_index = 1000;
	if ($form) {
		add_filter( 'gform_tabindex_' . $form['id'], 'gform_tabindexer' );
	}
	return GFCommon::$tab_index >= $starting_index ? GFCommon::$tab_index : $starting_index;
}