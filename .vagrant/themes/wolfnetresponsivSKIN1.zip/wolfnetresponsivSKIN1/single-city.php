<?php
/**
 * The Template for displaying all single posts.
 *
 * @package bcore
 */

$post_for_query = get_post($post_id);
$query_tax_slug = $post_for_query->post_name;

$citypostsargs = array(
	'post_type' => 'city_post',
	'posts_per_page' => -1,
	'tax_query' => array(
		array(
			'taxonomy' => 'communities',
			'field'    => 'slug',
			'terms'    => $query_tax_slug,
		),
	),
);
$cityposts = new WP_Query( $citypostsargs );

get_header(); ?>

	<div class="container">
		<?php if( get_theme_mod( 'communitiesfull' ) == '') { ?>
		<div id="primary" class="content-area">
		<?php } else { ?>
		<div id="primary" class="content-area content-area-full">
		<?php } ?>
			<main id="main" class="site-main" role="main">

			<?php while ( have_posts() ) : the_post(); ?>

				<?php get_template_part( 'content', 'single' ); ?>

				<?php // bcore_post_nav(); ?>

				<?php
					// If comments are open or we have at least one comment, load up the comment template
					if ( comments_open() || '0' != get_comments_number() ) :
						comments_template();
					endif;
				?>

			<?php endwhile; // end of the loop. ?>
			<?php wp_reset_postdata(); ?>

			<?php 
			// Dispaly Community Posts
			if ( $cityposts->have_posts() ) {
				echo '<h1>' . get_the_title() . ' News Feed</h1>';
				echo '<ul style="list-style:none;margin:0;">';
				while ( $cityposts->have_posts() ) {
					$cityposts->the_post();
					echo '<li class="community-single-nf" style="width:33.33%;float:left;padding-right:30px;margin-top:15px;margin-bottom:15px;">';
						echo '<h2><a href="' . get_the_permalink( $cityposts->post->ID ) . '">' . get_the_title( $cityposts->post->ID ) . '</a></h2>';
						echo get_the_excerpt();
					echo '</li>';
				}
				echo '</ul>';
			}
			// Restore original Post Data
			wp_reset_postdata();
			?>

			<style>
				@media (max-width: 850px) {
					.community-single-nf {
						width: 50% !important;
					}
				}
				@media (max-width: 600px) {
					.community-single-nf {
						width: 100% !important;
					}
				}
			</style>

			</main><!-- #main -->
		</div><!-- #primary -->

		<?php if( get_theme_mod( 'communitiesfull' ) == '') { ?>
		<?php get_sidebar(); ?>
		<?php } ?>
	</div>

<?php get_footer(); ?>