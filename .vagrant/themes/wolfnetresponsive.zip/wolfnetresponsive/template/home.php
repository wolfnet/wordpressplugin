<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package bcore
 *
 * Template Name: Homepage
 *
 */

$communities = new WP_Query( 'post_type=city&orderby=title&order=ASC&posts_per_page=-1' );
$blogfeedargs = array(
	'post_type' => array( 'post', 'city_post' ),
	'posts_per_page' => 4
);
$blogpostsfour = new WP_Query( $blogfeedargs );

get_header(); ?>

	<div id="featuredproperties">
		<div class="container">
			<h1>Featured Properties</h1>
			<hr>
			<div class="container_home1">
				<?php $homefeatured = get_theme_mod( 'homefeatured' ); if( !empty( $homefeatured ) ): ?>
					<?php echo do_shortcode($homefeatured); ?>
				<?php endif; ?>
			</div>
			<div class="clear"></div>
		</div>
	</div>

	<div id="searchbyarea">
		<div class="container">
			<h1>Search By Area</h1>
			<hr>
			<?php
			if ( $communities->have_posts() ) {
				echo '<ul>';
				while ( $communities->have_posts() ) {
					$communities->the_post();
					echo '<li><a href="';
					echo the_permalink();
					echo '">' . get_the_title() . '</a></li>';
				}
				echo '</ul>';
			} else {
				// no posts found
			}
			wp_reset_postdata();
			?>
			<div class="clear"></div>
		</div>		
	</div>

	<?php $homefeatured2 = get_theme_mod( 'homefeatured2' ); if( !empty( $homefeatured2 ) ): ?>
	<div id="featuredproperties2">
		<div class="container">
			<?php $homefeatured2_title = get_theme_mod( 'homefeatured2_title' ); if( !empty( $homefeatured2_title ) ) { ?>
			<h1><?php echo $homefeatured2_title; ?></h1>
			<?php } else { ?>
			<h1>Featured Properties</h1>
			<?php } ?>
			<hr>
			<div class="container_home1">
				<?php echo do_shortcode($homefeatured2); ?>
			</div>
			<div class="clear"></div>
		</div>
	</div>
	<?php endif; ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			<div class="container">
				<h1>Latest Blog Posts</h1>
				<hr>
				<?php $count = 0; ?>
				<?php while ( $blogpostsfour->have_posts() ) : $blogpostsfour->the_post(); ?>

					<?php $count++; ?>

					<div class="singlepost singlepost-<?php echo $count; ?>">

						<?php // get_template_part( 'content', 'page' ); ?>

						<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						<?php bcore_posted_on(); ?>
						<?php the_excerpt(); ?>

					</div>

				<?php endwhile; // end of the loop. ?>

				<div class="clear"></div>

				<div class="footerwidgets">
					<div class="first">
						<?php dynamic_sidebar('footer1'); ?>
					</div>
					<div class="second">
						<?php dynamic_sidebar('footer2'); ?>
					</div>
				</div>
				<div class="clear"></div>
			</div>
		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_footer(); ?>
