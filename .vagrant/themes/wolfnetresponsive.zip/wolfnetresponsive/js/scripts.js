/**
 * scripts.js
 */

jQuery(function($) {

	// Homepage Wolfnet Quick Search Dropdown Fix
	
	$('.wolfnet_quickSearch_basic .wolfnet_widgetBeds select option:first-child').text('Beds'); 
	$('.wolfnet_quickSearch_legacy .wolfnet_widgetBeds select option:first-child').text('Beds'); 
	// $('.wolfnet_quickSearch_basic .wolfnet_widgetBeds select option:nth-child(2)').append(' Bed'); // Add "Bed" after "1"
	// $('.wolfnet_quickSearch_basic .wolfnet_widgetBeds select option:gt(1)').append(' Beds'); // Add "Beds" after "2, 3, ..."

	$('.wolfnet_quickSearch_basic .wolfnet_widgetBaths select option:first-child').text('Baths'); 
	$('.wolfnet_quickSearch_legacy .wolfnet_widgetBaths select option:first-child').text('Baths'); 
	// $('.wolfnet_quickSearch_basic .wolfnet_widgetBaths select option:nth-child(2)').append(' Bath'); // Add "Bath" after "1"
	// $('.wolfnet_quickSearch_basic .wolfnet_widgetBaths select option:gt(1)').append(' Baths'); // Add "Baths" after "2, 3, ..."

	// $(document).ready(function() {
	// });

	// window height
	var windowwidth = $(window).width();
	// var windowheight = $(window).height();

	// scroll top
	// var scrollTop = $(window).scrollTop();

	// img width
	var imagewidth = 1920;
	// var imageheight = 624;

	// if (windowwidth > imagewidth) {
	// 	$( "header#bcore-header" ).css( "backgrond-size", function( index ) {
	// 		return 100%;
	// 	});
	// }
	// $(window).resize(function() {
	// 	windowwidth = $(window).width();
	// 	if (windowwidth > imagewidth) {
	// 		$( "header#bcore-header" ).css( "backgrond-size", function( index ) {
	// 			return 100%;
	// 		});
	// 	}
	// 	$( "#content h1" ).text( "windowwidth:" + windowwidth + ", imagewidth: " + imagewidth);
	// }

});
