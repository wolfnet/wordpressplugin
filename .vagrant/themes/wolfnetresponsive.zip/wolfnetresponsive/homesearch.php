<div id="wolfnet_quickSearch_5421cbc3a56a6" class="wolfnet_widget wolfnet_quickSearch wolfnet_wWide">


            <h2 class="wolfnet_widgetTitle">Quick Search</h2>
    
    <form id="wolfnet_quickSearch_5421cbc3a56a6_quickSearchForm" class="wolfnet_quickSearch_form" name="wolfnet_quickSearch_5421cbc3a56a6_quickSearchForm" method="get" action="http://www.mlsfinder.com/mn_rmls/wordpressplugincobrandsite/index.cfm">

        <input name="action" type="hidden" value="newsearchsession">
        <input name="submit" type="hidden" value="Search">

        <input type="hidden" name="search_source" value="wp_plugin">
        
        <ul class="wolfnet_searchType">
            <li><a href="javascript:;" wolfnet:search_type="opentxt" class="wolfnet_active"><span>Location</span></a></li>
            <li><a href="javascript:;" wolfnet:search_type="mlsnum"><span>Listing Number</span></a></li>
        </ul>

        <div class="wolfnet_searchTypeField">
            <input id="wolfnet_quickSearch_5421cbc3a56a6_search_text" class="wolfnet_quickSearch_searchText hintText" name="open_text" type="text">
        </div>

        <div class="wolfnet_widgetPrice">

            <label>Price</label>

            <div>
                <select id="wolfnet_quickSearch_5421cbc3a56a6_min_price" name="min_price">
                    <option value="">Min. Price</option>
                                        <option value="250">$250</option>
                                        <option value="500">$500</option>
                                        <option value="750">$750</option>
                                        <option value="1000">$1,000</option>
                                        <option value="1500">$1,500</option>
                                        <option value="2000">$2,000</option>
                                        <option value="2500">$2,500</option>
                                        <option value="5000">$5,000</option>
                                        <option value="10000">$10,000</option>
                                        <option value="20000">$20,000</option>
                                        <option value="30000">$30,000</option>
                                        <option value="40000">$40,000</option>
                                        <option value="50000">$50,000</option>
                                        <option value="60000">$60,000</option>
                                        <option value="70000">$70,000</option>
                                        <option value="75000">$75,000</option>
                                        <option value="80000">$80,000</option>
                                        <option value="85000">$85,000</option>
                                        <option value="90000">$90,000</option>
                                        <option value="95000">$95,000</option>
                                        <option value="100000">$100,000</option>
                                        <option value="110000">$110,000</option>
                                        <option value="120000">$120,000</option>
                                        <option value="130000">$130,000</option>
                                        <option value="140000">$140,000</option>
                                        <option value="150000">$150,000</option>
                                        <option value="160000">$160,000</option>
                                        <option value="170000">$170,000</option>
                                        <option value="180000">$180,000</option>
                                        <option value="190000">$190,000</option>
                                        <option value="200000">$200,000</option>
                                        <option value="210000">$210,000</option>
                                        <option value="220000">$220,000</option>
                                        <option value="230000">$230,000</option>
                                        <option value="240000">$240,000</option>
                                        <option value="250000">$250,000</option>
                                        <option value="260000">$260,000</option>
                                        <option value="270000">$270,000</option>
                                        <option value="280000">$280,000</option>
                                        <option value="290000">$290,000</option>
                                        <option value="300000">$300,000</option>
                                        <option value="310000">$310,000</option>
                                        <option value="320000">$320,000</option>
                                        <option value="330000">$330,000</option>
                                        <option value="340000">$340,000</option>
                                        <option value="350000">$350,000</option>
                                        <option value="360000">$360,000</option>
                                        <option value="370000">$370,000</option>
                                        <option value="380000">$380,000</option>
                                        <option value="390000">$390,000</option>
                                        <option value="400000">$400,000</option>
                                        <option value="410000">$410,000</option>
                                        <option value="420000">$420,000</option>
                                        <option value="430000">$430,000</option>
                                        <option value="440000">$440,000</option>
                                        <option value="450000">$450,000</option>
                                        <option value="460000">$460,000</option>
                                        <option value="470000">$470,000</option>
                                        <option value="480000">$480,000</option>
                                        <option value="490000">$490,000</option>
                                        <option value="500000">$500,000</option>
                                        <option value="510000">$510,000</option>
                                        <option value="520000">$520,000</option>
                                        <option value="530000">$530,000</option>
                                        <option value="540000">$540,000</option>
                                        <option value="550000">$550,000</option>
                                        <option value="560000">$560,000</option>
                                        <option value="570000">$570,000</option>
                                        <option value="580000">$580,000</option>
                                        <option value="590000">$590,000</option>
                                        <option value="600000">$600,000</option>
                                        <option value="610000">$610,000</option>
                                        <option value="620000">$620,000</option>
                                        <option value="630000">$630,000</option>
                                        <option value="640000">$640,000</option>
                                        <option value="650000">$650,000</option>
                                        <option value="660000">$660,000</option>
                                        <option value="670000">$670,000</option>
                                        <option value="680000">$680,000</option>
                                        <option value="690000">$690,000</option>
                                        <option value="700000">$700,000</option>
                                        <option value="710000">$710,000</option>
                                        <option value="720000">$720,000</option>
                                        <option value="730000">$730,000</option>
                                        <option value="740000">$740,000</option>
                                        <option value="750000">$750,000</option>
                                        <option value="760000">$760,000</option>
                                        <option value="770000">$770,000</option>
                                        <option value="780000">$780,000</option>
                                        <option value="790000">$790,000</option>
                                        <option value="800000">$800,000</option>
                                        <option value="810000">$810,000</option>
                                        <option value="820000">$820,000</option>
                                        <option value="830000">$830,000</option>
                                        <option value="840000">$840,000</option>
                                        <option value="850000">$850,000</option>
                                        <option value="860000">$860,000</option>
                                        <option value="870000">$870,000</option>
                                        <option value="880000">$880,000</option>
                                        <option value="890000">$890,000</option>
                                        <option value="900000">$900,000</option>
                                        <option value="910000">$910,000</option>
                                        <option value="920000">$920,000</option>
                                        <option value="930000">$930,000</option>
                                        <option value="940000">$940,000</option>
                                        <option value="950000">$950,000</option>
                                        <option value="960000">$960,000</option>
                                        <option value="970000">$970,000</option>
                                        <option value="980000">$980,000</option>
                                        <option value="990000">$990,000</option>
                                        <option value="1000000">$1,000,000</option>
                                        <option value="1100000">$1,100,000</option>
                                        <option value="1200000">$1,200,000</option>
                                        <option value="1300000">$1,300,000</option>
                                        <option value="1400000">$1,400,000</option>
                                        <option value="1500000">$1,500,000</option>
                                        <option value="1600000">$1,600,000</option>
                                        <option value="1700000">$1,700,000</option>
                                        <option value="1800000">$1,800,000</option>
                                        <option value="1900000">$1,900,000</option>
                                        <option value="2000000">$2,000,000</option>
                                        <option value="2500000">$2,500,000</option>
                                        <option value="3000000">$3,000,000</option>
                                        <option value="3500000">$3,500,000</option>
                                        <option value="4000000">$4,000,000</option>
                                        <option value="4500000">$4,500,000</option>
                                        <option value="5000000">$5,000,000</option>
                                        <option value="6000000">$6,000,000</option>
                                        <option value="8000000">$8,000,000</option>
                                        <option value="10000000">$10,000,000</option>
                                        <option value="12000000">$12,000,000</option>
                                        <option value="14000000">$14,000,000</option>
                                        <option value="16000000">$16,000,000</option>
                                        <option value="18000000">$18,000,000</option>
                                        <option value="20000000">$20,000,000</option>
                                        <option value="22000000">$22,000,000</option>
                                        <option value="23000000">$23,000,000</option>
                                        <option value="24000000">$24,000,000</option>
                                        <option value="25000000">$25,000,000</option>
                                    </select>
            </div>

            <div>
                <select id="wolfnet_quickSearch_5421cbc3a56a6_max_price" name="max_price">
                    <option value="">Max. Price</option>
                                        <option value="250">$250</option>
                                        <option value="500">$500</option>
                                        <option value="750">$750</option>
                                        <option value="1000">$1,000</option>
                                        <option value="1500">$1,500</option>
                                        <option value="2000">$2,000</option>
                                        <option value="2500">$2,500</option>
                                        <option value="5000">$5,000</option>
                                        <option value="10000">$10,000</option>
                                        <option value="20000">$20,000</option>
                                        <option value="30000">$30,000</option>
                                        <option value="40000">$40,000</option>
                                        <option value="50000">$50,000</option>
                                        <option value="60000">$60,000</option>
                                        <option value="70000">$70,000</option>
                                        <option value="75000">$75,000</option>
                                        <option value="80000">$80,000</option>
                                        <option value="85000">$85,000</option>
                                        <option value="90000">$90,000</option>
                                        <option value="95000">$95,000</option>
                                        <option value="100000">$100,000</option>
                                        <option value="110000">$110,000</option>
                                        <option value="120000">$120,000</option>
                                        <option value="130000">$130,000</option>
                                        <option value="140000">$140,000</option>
                                        <option value="150000">$150,000</option>
                                        <option value="160000">$160,000</option>
                                        <option value="170000">$170,000</option>
                                        <option value="180000">$180,000</option>
                                        <option value="190000">$190,000</option>
                                        <option value="200000">$200,000</option>
                                        <option value="210000">$210,000</option>
                                        <option value="220000">$220,000</option>
                                        <option value="230000">$230,000</option>
                                        <option value="240000">$240,000</option>
                                        <option value="250000">$250,000</option>
                                        <option value="260000">$260,000</option>
                                        <option value="270000">$270,000</option>
                                        <option value="280000">$280,000</option>
                                        <option value="290000">$290,000</option>
                                        <option value="300000">$300,000</option>
                                        <option value="310000">$310,000</option>
                                        <option value="320000">$320,000</option>
                                        <option value="330000">$330,000</option>
                                        <option value="340000">$340,000</option>
                                        <option value="350000">$350,000</option>
                                        <option value="360000">$360,000</option>
                                        <option value="370000">$370,000</option>
                                        <option value="380000">$380,000</option>
                                        <option value="390000">$390,000</option>
                                        <option value="400000">$400,000</option>
                                        <option value="410000">$410,000</option>
                                        <option value="420000">$420,000</option>
                                        <option value="430000">$430,000</option>
                                        <option value="440000">$440,000</option>
                                        <option value="450000">$450,000</option>
                                        <option value="460000">$460,000</option>
                                        <option value="470000">$470,000</option>
                                        <option value="480000">$480,000</option>
                                        <option value="490000">$490,000</option>
                                        <option value="500000">$500,000</option>
                                        <option value="510000">$510,000</option>
                                        <option value="520000">$520,000</option>
                                        <option value="530000">$530,000</option>
                                        <option value="540000">$540,000</option>
                                        <option value="550000">$550,000</option>
                                        <option value="560000">$560,000</option>
                                        <option value="570000">$570,000</option>
                                        <option value="580000">$580,000</option>
                                        <option value="590000">$590,000</option>
                                        <option value="600000">$600,000</option>
                                        <option value="610000">$610,000</option>
                                        <option value="620000">$620,000</option>
                                        <option value="630000">$630,000</option>
                                        <option value="640000">$640,000</option>
                                        <option value="650000">$650,000</option>
                                        <option value="660000">$660,000</option>
                                        <option value="670000">$670,000</option>
                                        <option value="680000">$680,000</option>
                                        <option value="690000">$690,000</option>
                                        <option value="700000">$700,000</option>
                                        <option value="710000">$710,000</option>
                                        <option value="720000">$720,000</option>
                                        <option value="730000">$730,000</option>
                                        <option value="740000">$740,000</option>
                                        <option value="750000">$750,000</option>
                                        <option value="760000">$760,000</option>
                                        <option value="770000">$770,000</option>
                                        <option value="780000">$780,000</option>
                                        <option value="790000">$790,000</option>
                                        <option value="800000">$800,000</option>
                                        <option value="810000">$810,000</option>
                                        <option value="820000">$820,000</option>
                                        <option value="830000">$830,000</option>
                                        <option value="840000">$840,000</option>
                                        <option value="850000">$850,000</option>
                                        <option value="860000">$860,000</option>
                                        <option value="870000">$870,000</option>
                                        <option value="880000">$880,000</option>
                                        <option value="890000">$890,000</option>
                                        <option value="900000">$900,000</option>
                                        <option value="910000">$910,000</option>
                                        <option value="920000">$920,000</option>
                                        <option value="930000">$930,000</option>
                                        <option value="940000">$940,000</option>
                                        <option value="950000">$950,000</option>
                                        <option value="960000">$960,000</option>
                                        <option value="970000">$970,000</option>
                                        <option value="980000">$980,000</option>
                                        <option value="990000">$990,000</option>
                                        <option value="1000000">$1,000,000</option>
                                        <option value="1100000">$1,100,000</option>
                                        <option value="1200000">$1,200,000</option>
                                        <option value="1300000">$1,300,000</option>
                                        <option value="1400000">$1,400,000</option>
                                        <option value="1500000">$1,500,000</option>
                                        <option value="1600000">$1,600,000</option>
                                        <option value="1700000">$1,700,000</option>
                                        <option value="1800000">$1,800,000</option>
                                        <option value="1900000">$1,900,000</option>
                                        <option value="2000000">$2,000,000</option>
                                        <option value="2500000">$2,500,000</option>
                                        <option value="3000000">$3,000,000</option>
                                        <option value="3500000">$3,500,000</option>
                                        <option value="4000000">$4,000,000</option>
                                        <option value="4500000">$4,500,000</option>
                                        <option value="5000000">$5,000,000</option>
                                        <option value="6000000">$6,000,000</option>
                                        <option value="8000000">$8,000,000</option>
                                        <option value="10000000">$10,000,000</option>
                                        <option value="12000000">$12,000,000</option>
                                        <option value="14000000">$14,000,000</option>
                                        <option value="16000000">$16,000,000</option>
                                        <option value="18000000">$18,000,000</option>
                                        <option value="20000000">$20,000,000</option>
                                        <option value="22000000">$22,000,000</option>
                                        <option value="23000000">$23,000,000</option>
                                        <option value="24000000">$24,000,000</option>
                                        <option value="25000000">$25,000,000</option>
                                    </select>
            </div>

            <div class="wolfnet_clearfix"></div>

        </div>

        <div class="wolfnet_widgetBedBath">

            <div class="wolfnet_widgetBeds">
                <label for="wolfnet_quickSearch_5421cbc3a56a6_min_beds">Beds</label>
                <select id="wolfnet_quickSearch_5421cbc3a56a6_min_beds" name="min_bedrooms">
                    <option value="">Beds (Any)</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                        <option value="6">6</option>
                                        <option value="7">7</option>
                                    </select>
            </div>

            <div class="wolfnet_widgetBaths">

                <label for="wolfnet_quickSearch_5421cbc3a56a6_min_baths">Baths</label>
                <select id="wolfnet_quickSearch_5421cbc3a56a6_min_baths" name="min_bathrooms">
                    <option value="">Baths (Any)</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                        <option value="6">6</option>
                                        <option value="7">7</option>
                                    </select>

            </div>

        </div>

        <div class="wolfnet_quickSearchFormButton">

            <button class="wolfnet_quickSearchForm_submitButton" name="search" type="submit">Search!</button>

        </div>

    </form>

</div>