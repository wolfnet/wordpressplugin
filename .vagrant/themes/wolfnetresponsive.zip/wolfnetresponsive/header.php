<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package bcore
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- <title><?php wp_title( '|', true, 'right' ); ?></title> -->
<title><?php bloginfo('name'); ?> |  <?php wp_title(''); //is_front_page() ? bloginfo('description') : wp_title(''); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

<?php $this_sites_home_url = esc_url( home_url() ); ?>
<?php $logo_favicon = get_theme_mod('logofavicon'); ?>
<?php if ( ! empty( $logo_favicon ) ) : ?>
		<?php $logo_favicon_2 = parse_url($logo_favicon); ?>
		<?php $logo_favicon_3 = $logo_favicon_2['path'] . '?' . $logo_favicon_2['query'] . '#' . $logo_favicon_2['fragment']; ?>
		<link rel="icon" href="<?php echo $this_sites_home_url; ?><?php echo esc_url( $logo_favicon_3 ); ?>" />
<?php endif ?>

<?php wp_head(); ?>

	<?php
		$color_main = get_theme_mod('cprimary');
		$content_link_color = get_theme_mod('csecondary');
		$color_main_text = get_theme_mod('cprimary_text');
		$content_link_color_text = get_theme_mod('csecondary_text');
		$advancedsearchlink = get_theme_mod( 'advancedsearchlink' );
		$header_image = get_theme_mod('imageheader');
		$header_image2 = get_theme_mod('imageheader2');
		$header_image3 = get_theme_mod('imageheader3');
		$heder_image_choice = 0; /*false*/
		$random_temp = 0;
		// images edit
		$header_image_part2 = parse_url($header_image);
		$header_image2_part2 = parse_url($header_image2);
		$header_image3_part2 = parse_url($header_image3);
		// image result
		$header_image_part3 = $header_image_part2['path'] . '?' . $header_image_part2['query'] . '#' . $header_image_part2['fragment'];
		$header_image2_part3 = $header_image2_part2['path'] . '?' . $header_image2_part2['query'] . '#' . $header_image2_part2['fragment'];
		$header_image3_part3 = $header_image3_part2['path'] . '?' . $header_image3_part2['query'] . '#' . $header_image3_part2['fragment'];
		// if all 3 (1 situation)
		if ($header_image != '' && $header_image2 != '' && $header_image3 != '') {
			$heder_image_choice = rand(1,3);
		}
		// if 2 (3 situations)
		else if ($header_image != '' && $header_image2 != '' && $header_image3 == '') {
			$heder_image_choice = rand(1,2);
		}
		else if ($header_image != '' && $header_image2 == '' && $header_image3 != '') {
			$random_temp = rand(1,2);
			if ($random_temp == 2) {
				$heder_image_choice = 3;
			}
		}
		else if ($header_image == '' && $header_image2 != '' && $header_image3 != '') {
			$random_temp = rand(1,2);
			if ($random_temp == 1) {
				$heder_image_choice = 3;
			}
		}
		// if 1 (3 situatioins)
		else if ($header_image != '' && $header_image2 == '' && $header_image3 == '') {
			$heder_image_choice = 1;
		}
		else if ($header_image == '' && $header_image2 != '' && $header_image3 == '') {
			$heder_image_choice = 2;
		}
		else if ($header_image == '' && $header_image2 == '' && $header_image3 != '') {
			$heder_image_choice = 3;
		}
	?>
	<style>
		body, body.custom-background { background: <?php echo $content_link_color; ?>; }
		<?php if ($heder_image_choice != 0) { ?>
			<?php if ($heder_image_choice == 1) { ?>
				header#bcore-header { background-image: url(<?php echo $this_sites_home_url; ?><?php echo $header_image_part3; ?>) !important; }
			<?php } ?>
			<?php if ($heder_image_choice == 2) { ?>
				header#bcore-header { background-image: url(<?php echo $this_sites_home_url; ?><?php echo $header_image2_part3; ?>) !important; }
			<?php } ?>
			<?php if ($heder_image_choice == 3) { ?>
				header#bcore-header { background-image: url(<?php echo $this_sites_home_url; ?><?php echo $header_image3_part3; ?>) !important; }
			<?php } ?>
		<?php } ?>
		<?php if( !empty( $advancedsearchlink ) ) { ?>
			body.home .wolfnet_quickSearch {
				padding-bottom: 40px;
				z-index: 10;
			}
			body.home header#bcore-header .header-container .advancedsearchcontain .advancedsearchlink {
				color: <?php echo $color_main; ?>;
			}
		<?php } ?>
		<?php if( get_theme_mod( 'homequicksearchdisplay' ) == '1') { ?>
			body.home #bcore-header .wolfnet_widget.wolfnet_smartSearch { display: none; }
			#bcore-header #homepage-search-box, #bcore-header .home3buttons { display: none !important; }
			#bcore-header .advancedsearchcontain { display: none; }
		<?php } ?>
		#mobile_navigation_contain #mobile_nav ul li { background: <?php echo $color_main; ?>; }
		header#bcore-header .header-container { background: <?php echo $color_main; ?>; }
		header#bcore-header .header-container a { color: <?php echo $color_main_text; ?>; }
		header#bcore-header .sub-menu { background: <?php echo $color_main; ?>; }
		body.home .wolfnet_quickSearch .wolfnet_widgetBedBath label { color: <?php echo $color_main; ?>; }
		button.wolfnet_quickSearchForm_submitButton, button.wolfnet_quickSearchForm_submitButton:hover { background: <?php echo $color_main; ?>; }
		button.wolfnet_smartSearchForm_submitButton, button.wolfnet_smartSearchForm_submitButton:hover { background: <?php echo $color_main; ?> !important; }
		.homepage-search-box input[type="submit"],
		.homepage-search-box input[type="submit"]:hover {
			background: <?php echo $color_main; ?> !important;
		}
		.homepage-search-box input[type="text"] {
			border-color: <?php echo $color_main; ?> !important;
		}
		body.home #searchbyarea { background: <?php echo $color_main; ?>; }
		body.home #searchbyarea h1 { color: <?php echo $color_main_text; ?>; }
		body.home #searchbyarea ul li a { color: #ffffff; }
		body.home #searchbyarea ul li a { color: <?php echo $color_main_text; ?>; }
		h1, h2, h3, h4, h5, h6, a, a:hover, a:focus, a:active, a:visited { color: <?php echo $color_main; ?>; }
		footer#bcore-footer { background: <?php echo $content_link_color; ?>; }
		@media screen and (max-width: 900px) { .main-navigation.toggled ul.nav-menu li { background: <?php echo $color_main; ?>; } }
		body.home .wolfnet_widget.wolfnet_quickSearch.wolfnet_wWide .wolfnet_quickSearch_form select { color: <?php echo $color_main; ?> !important; }
		footer#bcore-footer { color: <?php echo $content_link_color_text; ?>; }
		footer#bcore-footer a { color: <?php echo $content_link_color_text; ?>; }
		.wolfnet_marketDisclaimer { color: <?php echo $content_link_color_text; ?>; }
	</style>
</head>

<body <?php body_class(); ?>>
<div id="page" class="hfeed site">
	<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'bcore' ); ?></a>

	<header id="bcore-header" class="site-header" role="banner">
		<div class="social-container">
			<div class="social-float">
				Connect with us:
				<?php $phone = get_theme_mod( 'fphone' ); $phone_display = get_theme_mod( 'fphoned' ); if( !empty( $phone ) && !empty( $phone_display ) ): ?>
					<a href="tel:+<?php echo $phone; ?>" target="_blank" class="phone"><?php echo $phone_display; ?></a>
				<?php endif; ?>
			</div>
			<div class="clear"></div>
			<div class="social-float-phone">
				<?php $tw = get_theme_mod( 'tw' ); if( !empty( $tw ) ): ?>
					<a href="<?php echo $tw; ?>" target="_blank" class="sl tw">twitter</a>
				<?php endif; ?>
				<?php $pin = get_theme_mod( 'pin' ); if( !empty( $pin ) ): ?>
					<a href="<?php echo $pin; ?>" target="_blank" class="sl pin">pintrest</a>
				<?php endif; ?>
				<?php $in = get_theme_mod( 'in' ); if( !empty( $in ) ): ?>
					<a href="<?php echo $in; ?>" target="_blank" class="sl in">linkedin</a>
				<?php endif; ?>
				<?php $insta = get_theme_mod( 'insta' ); if( !empty( $insta ) ): ?>
					<a href="<?php echo $insta; ?>" target="_blank" class="sl insta">instagram</a>
				<?php endif; ?>
				<?php $gp = get_theme_mod( 'gp' ); if( !empty( $gp ) ): ?>
					<a href="<?php echo $gp; ?>" target="_blank" class="sl gp">google+</a>
				<?php endif; ?>
				<?php $fb = get_theme_mod( 'fb' ); if( !empty( $fb ) ): ?>
					<a href="<?php echo $fb; ?>" target="_blank" class="sl fb">facebook</a>
				<?php endif; ?>
				<?php $yt = get_theme_mod( 'yt' ); if( !empty( $yt ) ): ?>
					<a href="<?php echo $yt; ?>" target="_blank" class="sl yt" style="background-position: -160px 0;">YouTube</a>
				<?php endif; ?>
			</div>
			<div class="clear"></div>
		</div>
		<div class="header-container">
			<div class="bcore-container">
				<div class="site-branding">
					<?php $brokerimage = get_theme_mod( 'logob' ); if( !empty( $brokerimage ) ): ?>
						<?php $brokerimage_2 = parse_url($brokerimage); ?>
						<?php $brokerimage_3 = $brokerimage_2['path'] . '?' . $brokerimage_2['query'] . '#' . $brokerimage_2['fragment']; ?>
						<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
							<img src="<?php echo $this_sites_home_url; ?><?php echo $brokerimage_3; ?>">
							<span><?php bloginfo( 'name' ); ?></span>
						</a></h1>
					<?php else: ?>
						<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
							<!-- <img src=""> -->
							<span><?php bloginfo( 'name' ); ?></span>
						</a></h1>
					<?php endif; ?>
				</div>
				<nav id="site-navigation" class="main-navigation" role="navigation">
					<button class="menu-toggle"><img src="<?php bloginfo('template_url'); ?>/img/menu_mobile.png"></button>
					<?php wp_nav_menu( array( 'theme_location' => 'primary' ) ); ?>
				</nav>
				<div class="clear"></div>
				<?php $logom = get_theme_mod( 'logom' ); if( !empty( $logom ) ): ?>
					<?php $logom_2 = parse_url($logom); ?>
					<?php $logom_3 = $logom_2['path'] . '?' . $logom_2['query'] . '#' . $logom_2['fragment']; ?>
					<img src="<?php echo $this_sites_home_url; ?><?php echo $logom_3; ?>" alt="logo" class="mainlogo">
				<?php else: ?>
					<style>
						body.home .header-container .wolfnet_quickSearch {
							margin-top: 100px;
						}
					</style>
				<?php endif; ?>


				<style>
					[data-search-box="search"] #homepage-search-box--toggle-search {
						background-color: <?php echo $color_main; ?> !important;
					}
					[data-search-box="value"] #homepage-search-box--toggle-value {
						background-color: <?php echo $color_main; ?> !important;
					}
					.homepage-search-box {
						display: block;
						position: relative;
						padding: 15px 15px 5px;
						margin: 0 auto;
						width: 40%;
						width: 660px;
						width: 90%;
						background: #444444;
						background: rgba(255, 255, 255, 0.9);
						border: 3px solid rgba(143, 143, 143, 0.6);
						-webkit-border-radius: 0;
						border-radius: 0;
						/*top: 2em;*/
						margin-top: 150px;
						font-size: 14px;
						border-radius: 3px;
						max-width: 660px;
					}
					[data-search-box="value"] {
						padding: 15px;
					}
					.homepage-search-box .advancedsearchcontain {
						top: 0 !important;
					}
					.homepage-search-box--toggles {
						position: absolute;
						bottom: 100%;
						left: 0;
					}
					.homepage-search-box--toggles div {
						background-color: rgba(49, 49, 49, 0.9);
						display: inline-block;
						margin-right: 5px;
						padding: 5px 10px;
						border-radius: 3px 3px 0 0;
						font-weight: 700;
						cursor: pointer;
						color: rgba(255,255,255,0.7);
					}
					.homepage-search-box--toggles div:hover {
						color: rgba(255,255,255,0.9);
					}
					[data-search-box="search"] #homepage-search-box--toggle-search {
						background-color: rgba(49, 49, 49, 0.7);
						color: #fff;
					}
					[data-search-box="value"] #homepage-search-box--toggle-value {
						background-color: rgba(49, 49, 49, 0.7);
						color: #fff;
					}
					[data-search-box="value"] .homepage-search-box--advanced {
						display: none !important;
					}
					[data-search-box="search"] .homepage-search-box--value {
						display: none;
					}
					[data-search-box="value"] .homepage-search-box--search {
						display: none;
					}
					.homepage-search-box .gform_heading {
						text-align: center;
					}
					.homepage-search-box form:before,
					.homepage-search-box form:after {
						content: "";
						clear: both;
						display: table;
					}
					.homepage-search-box .gform_title {
						text-align: center;
						text-transform: none;
						font-weight: 400;
						font-size: 2em;
						line-height: normal;
						margin: 0 0 14px !important;
						font-weight: 400 !important;
						font-size: 2em !important;
					}
					.homepage-search-box .gform_body {
						float: left;
						padding-right: 10px;
						width: calc(100% - 100px);
					}
					.homepage-search-box .gform_body li {
						margin: 0 !important;
					}
					.homepage-search-box .ginput_container {
						margin: 0 !important;
					}
					.homepage-search-box .gform_footer {
						float: right;
						width: 100px;
						margin: 0 !important;
						padding: 0 !important;
						clear: none !important;
					}
					.homepage-search-box input[type="submit"] {
						color: #fff !important;
						width: 100% !important;
						height: 42px;
						border-radius: 0 3px 3px 0;
						border: 0 !important;
					}
					.homepage-search-box .wolfnet_smartSearch,
					.homepage-search-box .wolfnet_quickSearch {
						padding: 0 !important;
						margin: 0 !important;
						background: transparent !important;
						width: 100% !important;
						top: 0 !important;
						border: 0 !important;
					}
					.homepage-search-box .gform_wrapper {
						margin: 0 !important;
					}
					.homepage-search-box input[type="text"] {
						width: 100% !important;
						height: 42px;
						padding: 0 10px;
						border: 2px solid;
						border-radius: 3px 0 0 3px;
					}
					@media (max-width: 789px) {
						.homepage-search-box .gform_body {
							width: 100%;
						}
						.homepage-search-box .gform_footer {
							width: 100%;
						}
					}
					.homepage-search-box .gfield_description.validation_message {
						color: #ffd5d5;
					}
					.homepage-search-box .gform_wrapper .validation_error {
						padding: 0;
						margin: 0 0 10px;
						border: none;
						color: red;
						font-size: 14px;
					}
					.homepage-search-box .gform_wrapper .gfield_label {
						display: none !important;
					}
					.homepage-search-box .gform_description {
						color: <?php echo $color_main; ?>;
						margin-bottom: 20px;
						display: block;
					}
				</style>
				<?php if(is_front_page()): ?>
					<?php if( get_theme_mod( 'homequicksearchdisplay' ) == '1') : ?>
						<?php if( get_option('front_page_home_value_form') ) : ?>
							<div id="homepage-search-box" class="homepage-search-box" data-search-box="value">
						<?php endif;?>
					<?php else: ?>
						<?php if( get_option('front_page_home_value_form') ) : ?>
							<div id="homepage-search-box" class="homepage-search-box" data-search-box="search">
						<?php endif; ?>
					<?php endif; ?>
					<?php if ( get_option('front_page_home_value_form') ) : ?>
						<?php if( get_theme_mod( 'homequicksearchdisplay' ) == '1') : ?>
							<div id="homepage-search-box--toggles" class="homepage-search-box--toggles">
								<div id="homepage-search-box--toggle-value">What Is My Home Worth?</div>
							</div>
						<?php else: ?>
							<div id="homepage-search-box--toggles" class="homepage-search-box--toggles">
								<div id="homepage-search-box--toggle-search">Search Homes</div>
								<div id="homepage-search-box--toggle-value">What Is My Home Worth?</div>
							</div>
						<?php endif; ?>
					<?php endif; ?>
					<?php if( get_theme_mod( 'homequicksearchdisplay' ) != '1') : ?>
					<div id="homepage-search-box--search" class="homepage-search-box--search">
						<?php
							$manual_shortcode = get_theme_mod( 'homeqsshortcode' );
							if ( get_theme_mod('homeqsshortcode' ) ) {
								echo ( is_front_page() ) ? do_shortcode($manual_shortcode) : '';

							} elseif ( get_theme_mod('smartsearch') == '1' ) {
								echo ( is_front_page() ) ? do_shortcode('[wnt_search title="QuickSearch" smartsearch="false" view="basic" /]') : '';

							} else {
								echo ( is_front_page() ) ? do_shortcode('[wnt_search title="Quick Search" smartsearch="true" /]') : '';
							}
						?>
					</div>
					<?php endif; ?>
					<?php if ( is_front_page() && get_option('front_page_home_value_form') ) : ?>
						<div id="homepage-search-box--value" class="homepage-search-box--value">
							<?php echo do_shortcode('[gravityform id="' . get_option('front_page_home_value_form') . '" title="true" description="true" ajax="false"]'); ?>
						</div>
						<div id="homepage-search-box--advanced" class="homepage-search-box--advanced">
							<?php $advancedsearchlink = get_theme_mod( 'advancedsearchlink' ); if( !empty( $advancedsearchlink ) ): ?>
								<div class="advancedsearchcontain"><a href="<?php echo $advancedsearchlink; ?>" target="_blank" class="advancedsearchlink">Advanced Search</a></div>
							<?php endif; ?>
						</div>
					<?php endif; ?>
					<?php if( get_option('front_page_home_value_form') || (get_theme_mod( 'homequicksearchdisplay' ) != '1')) : ?>
						</div>
					<?php endif; ?>
			<?php endif; ?>
			</div>
		</div>
	</header>

	<div id="content" class="site-content">
		<!-- <div class="container"> -->
