/* 

TO DO:

1) Better image minification (sprites and progressive jpgs)

*/    

module.exports = function(grunt) {

  grunt.initConfig({

    pkg: grunt.file.readJSON('package.json'),

    // START CSS/SASS {

      // SASS (build + combine)
      sass: {
        dist: {
          options: {
            style: 'expanded'
          },
          files: {
            'css/build/admin.css': 'css/admin.scss',
            'css/build/style.css': 'css/style.scss',
          }
        }
      },

      // SASS --> Autoprefixer (W3C)
      autoprefixer: {
        options: {
          // browsers: ['last 2 version']
          browsers: ['Android >= 2.1', 'Chrome >= 21', 'Explorer >= 7', 'Firefox >= 17', 'Opera >= 12.1', 'Safari >= 6.0']
        },
        theme: {
          expand: true,
          flatten: true,
          src: 'css/build/style.css',
          dest: ''
        },
        admin: {
          expand: true,
          flatten: true,
          src: 'css/build/admin.css',
          dest: 'css/'
        }
      },

      // SASS --> Autoprefixer --> Minify CSS (Compress + Combine)
      // cssmin: {
      //   combine: {
      //     options: {
      //       banner: '/* Theme Name: BCore | Theme URI: http://www.brandco.com | Description: This theme was made by BrandCo | Version: 0.1 | Author: BrandCo | Author URI: http://www.brandco.com | Tags: BrandCo */'
      //   	},
      //     expand: true,
      //   	files: {
      //       'style.css': [
      //         'css/build/prefixed/reset.css',
      //         'css/build/prefixed/base.css',
      //         'css/build/prefixed/style.css']
      //     }
      //   }
      // },
    
    // } END CSS/SASS 
    // START JS {

      // js lint
      jshint: {
        // beforeconcat: ['js/scripts.js','js/admin.js']
        beforeconcat: ['js/scripts.js']
      },

      // combine js files
      // concat: {
      //   dist: {
      //     src: [
      //       'js/flexslider.js',
      //       'js/fitvids.js',
      //       'js/imagelightbox.js',
      //       'js/easing.js', 
      //       'js/scripts.js',
      //       'js/mobilemenu.js'
      //     ],
      //     dest: 'js/production/global.js'
      //   }
      // },

      // minify js
      // uglify: {
      //   build: {
      //     src: 'js/production/global.js',
      //     dest: 'js/global.js'
      //   }
      // },
    
    // }

    // optimize images {
      imagemin: {
        dynamic: {
          files: [{
            expand: true,
            // cwd: 'images/',
            src: ['images/*.{png,jpg,gif,jpeg}'],
            dest: ''
          }]
        }
      },
    // }

    // imagemin: {
    //   png: {
    //     options: {
    //         optimizationLevel: 7
    //     },
    //     files: [
    //       {
    //           expand: true,
    //           cwd: './app/images/',
    //           src: ['**/*.png'],
    //           dest: './app/images/compressed/',
    //           ext: '.png'
    //       }
    //     ]
    //   },
    //   jpg: {
    //     options: {
    //         progressive: true
    //     },
    //     files: [
    //       {
    //         expand: true,
    //         cwd: './app/images/',
    //         src: ['**/*.jpg'],
    //         dest: './app/images/compressed/',
    //         ext: '.jpg'
    //       }
    //     ]
    //   }
    // }

    // Tasks to run when using certian files
    watch: {
      // sass and css files
      css: {
        files: ['css/*.scss'],
        // tasks: ['sass', 'autoprefixer', 'cssmin'],
        tasks: ['sass', 'autoprefixer'],
        options: {
          spawn: false,
          livereload: true,
        }
      },
      scripts: {
        // files: ['js/*.js'],
        files: ['js/scripts.js'],
        tasks: ['jshint'],
        options: {
          spawn: false,
          livereload: true,
        }
      },
      // image files
      images: {
        files: ['images/**/*.{png,jpg,jpeg,gif}', 'images/*.{png,jpg,jpeg,gif}'],
        tasks: ['imagemin'],
        options: {
          spawn: false,
        }
      }
    },

  });

  require('load-grunt-tasks')(grunt);

  // grunt.registerTask('default', ['concat', 'uglify', 'sass', 'autoprefixer', 'cssmin', 'imagemin']);
  grunt.registerTask('default', ['sass', 'autoprefixer', 'concat', 'uglify']);

  grunt.registerTask('css', ['sass', 'autoprefixer']);
  grunt.registerTask('js', ['jshint']);
  grunt.registerTask('img', ['imagemin']);

  // grunt.registerTask('dev', ['connect', 'watch']);

};