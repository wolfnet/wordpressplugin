/**
 * scripts.js
 */

jQuery(function($) {

	//	Menu Height Fix (70 + 35)
	/*$(document).ready(function() {
		$( '.menu-toggle' ).click(function() {
			var document_height_for_menu = $(document).height() - 70;
			$('.main-navigation.toggled .menu').css('height',document_height_for_menu);
			if ($('#wpadminbar').length > 0) {
				$('.main-navigation.toggled .menu').css('height',document_height_for_menu-35);
			}
		});
	});*/

	//	Homepage Wolfnet Quick Search Dropdown Fix
	//	part 1
	$('.wolfnet_widgetBeds select option:first-child').text('Beds'); //	Replace default "Any" with "Beds"
	$('.wolfnet_widgetBeds select option:nth-child(2)').append(' Bed'); //	Add "Bed" after "1"
	$('.wolfnet_widgetBeds select option:gt(1)').append(' Beds'); //	Add "Beds" after "2, 3, ..."
	$('.wolfnet_widgetBeds label').hide();
	//	part 2
	$('.wolfnet_widgetBaths select option:first-child').text('Baths'); //	Replace default "Any" with "Baths"
	$('.wolfnet_widgetBaths select option:nth-child(2)').append(' Bath'); //	Add "Bath" after "1"
	$('.wolfnet_widgetBaths select option:gt(1)').append(' Baths'); //	Add "Baths" after "2, 3, ..."
	$('.wolfnet_widgetBaths label').hide();

	$('.wolfnet_widgetPrice div:first-of-type select option:first-child').text('Min. Price');
	$('.wolfnet_widgetPrice div:nth-of-type(2) select option:first-child').text('Max. Price');

	//	hide search text
	//	$('body.home #bcore-header button.wolfnet_quickSearchForm_submitButton').html('');
	//	$( document ).ready(function() {
	//	$('body.home .wolfnet_quickSearchForm_submitButton').addClass('icon-search');
	//	});
	$('button.wolfnet_quickSearchForm_submitButton').html('SEARCH');

	//	sidebar
	$('#secondary .wolfnet_quickSearchFormButton').wrap('<div class="clear"></div>');
	$('.wolfnet_quickSearch_searchText').attr('placeholder','House #, Street, City, State or Zip');
	$('.home3buttons').appendTo('#secondary .widget_wolfnet_quicksearchwidget');

	//	Homepage Widgets
	/*if ( $('.footerwidgets .first .widget-title').is(':empty') ) {
	}
	else {
		$('.footerwidgets .first .widget-title').append('<hr>');
	}
	if ( $('.footerwidgets .second .widget-title').is(':empty') ) {
	}
	else {
		$('.footerwidgets .second .widget-title').append('<hr>');
	}*/

	//	window height
	var windowwidth = $(window).width();
	//	var windowheight = $(window).height();

	//	scroll top
	//	var scrollTop = $(window).scrollTop();

	//	img width
	var imagewidth = 1920;
	//	var imageheight = 624;

	/*if (windowwidth > imagewidth) {
		$( "header#bcore-header" ).css( "backgrond-size", function( index ) {
			return 100%;
		});
	}
	$(window).resize(function() {
		windowwidth = $(window).width();
		if (windowwidth > imagewidth) {
			$( "header#bcore-header" ).css( "backgrond-size", function( index ) {
				return 100%;
			});
		}
		$( "#content h1" ).text( "windowwidth:" + windowwidth + ", imagewidth: " + imagewidth);
	}*/

	$.fn.bcoreMobileMenu = function() {
		var menuCopy = this.clone(),
			siteTitle = $("head title").html();
		$('body').addClass('bcore-mobile-menu-enabled');
		this.addClass('bcore-menu-selected');
		this.before('<div class="bcore-mobile-toggle icon-menu2"></div>');

		$('body').append( '<nav id="bcore-mobile-menu"></nav>' );
		$('nav#bcore-mobile-menu').append( menuCopy ).prepend('<h4 class="bcore-mob-title">Site Navigation</h4>');
		$('nav#bcore-mobile-menu .menu-item-has-children > a').after('<div class="open-children">></div>');
		$('.open-children').each(function(){
			$(this).click(function(){
				$(this).next().slideToggle(300);
			});
		});
		//	$('#bcore-mobile-menu').hide();
		$('.bcore-mobile-toggle').click(function(){
			//	$('#bcore-mobile-menu').show();
			$('body').toggleClass('bcore-open-menu');
			//	$('#page').addClass('page-2');
			//	$('.wolfnet_marketDisclaimer').addClass('wolfnet_marketDisclaimer-2');
			$('.bcore-mobile-toggle').toggleClass('icon-menu2');
			$('.bcore-mobile-toggle').toggleClass('icon-close');
		});
		//	$('nav#bcore-mobile-menu ul.menu > li:last-of-type').after('<li class="bcore-close-menu"><a href="#">Close menu &times;</a></li>');
		$(document.body).on('click', '#bcorr-body-cover' ,function(){
			//	$('#bcore-mobile-menu').hide();
			$('body').removeClass('bcore-open-menu');
			$('.bcore-mobile-toggle').removeClass('icon-close');
			$('.bcore-mobile-toggle').addClass('icon-menu2');
		});
	};
	$('#site-navigation > div').bcoreMobileMenu();

	//	gravity forms
	/*var gfields = $('li.gfield .ginput_container input, li.gfield .ginput_container textarea');
	gfields.focus(function(){
		$(this).parent().parent().addClass('field-active');
	});
	gfields.blur(function(){
		$(this).parent().parent().removeClass('field-active');
		if( $(this).val().length !== 0 ) {
			$(this).parent().parent().addClass('field-complete');
		} else {
			$(this).parent().parent().removeClass('field-complete');
		}
	});
	gfields.keypress(function(){
		if( $(this).val().length !== 0 ) {
			$(this).parent().parent().addClass('field-keypress-filled');
		} else {
			$(this).parent().parent().removeClass('field-keypress-filled');
		}
	});*/

	/*
	$( document ).ready(function() {
		//	gravity forms custom placeholders
		$('.gform_wrapper li.gfield .gfield_label').click(function(){
			$(this).next('.ginput_container').find('input[type="text"], textarea').focus();
		});

		$('.gform_wrapper .ginput_container input[type="text"], .gform_wrapper .ginput_container textarea')
		.focus(function(){
			$(this).closest('.ginput_container').prev('.gfield_label').hide();
		})
		.blur(function(){
			if( $(this).val() === "" ){
				$(this).closest('.ginput_container').prev('.gfield_label').show();
			}
		});

		$('.gform_wrapper .ginput_container input[type="text"], .gform_wrapper .ginput_container textarea').each(function(){
			if( $(this).val() !== "" ){
				$(this).closest('.ginput_container').prev('.gfield_label').hide();
			}
		});
	});
	*/

	var canParallax = !( (navigator.userAgent.indexOf('Safari') != -1) && (navigator.userAgent.indexOf('Chrome') == -1) || navigator.userAgent.match(/(iPod|iPhone|iPad)/) );

	//	parallax header
	//	var parallaximagesource = $('body.home header#bcore-header').css('background-image').replace('url(', '').replace(')', '');

	//	run test on initial page load
	//	checkSize();

	//	//	run test on resize of the window
	//	$(window).resize(checkSize);

	//	function checkSize(){

		if ($(window).width() > 768){
			if (canParallax) {
				if (typeof(choosen_header_image_js) !== "undefined") {
					$('body.home header#bcore-header').parallax({imageSrc: choosen_header_image_js});
					$('body.home header#bcore-header').css('background','transparent');
				}

				//	parallax middle
				//	var parallaximagesource = $('body.home #searchbyarea').css('background-image').replace('url(', '').replace(')', '');
				if (typeof(choosen_header_image_js) !== "undefined") {
					$('body.home #searchbyarea').parallax({imageSrc: choosen_middle_image_js});
					$('body.home #searchbyarea').css('background','transparent');
				}
			}
		}
	//	}

	//	if (choosen_header_image_js) {
	//		$('body.home header#bcore-header').parallax({imageSrc: choosen_header_image_js});
	//		$('body.home header#bcore-header').css('background','transparent');
	//	}

	//	//	parallax middle
	//	//	var parallaximagesource = $('body.home #searchbyarea').css('background-image').replace('url(', '').replace(')', '');
	//	if (choosen_header_image_js) {
	//		$('body.home #searchbyarea').parallax({imageSrc: choosen_middle_image_js});
	//		$('body.home #searchbyarea').css('background','transparent');
	//	}

	//	first parallax layer
	if (canParallax) {
		$('body.home .parallax-mirror:first-of-type').css('opacity','0.75');
	}

	//	var parallaximagesource_2 = $('body.home #searchbyarea').css('background-image').replace('url(', '').replace(')', '');
	//	$('body.home #searchbyarea').parallax({imageSrc: parallaximagesource_2});
	//	$('body.home #searchbyarea').css('background','transparent');
	if (canParallax) {
		$('.site').css('background','transparent');
	}

	//	dot dot dot
	$(document).ready(function() {
		$(".singlepost .excerpt-span").dotdotdot({
			/*	The text to add as ellipsis. */
			ellipsis	: '... ',
			/*	How to cut off the text/html: 'word'/'letter'/'children' */
			wrap		: 'word',
			/*	Wrap-option fallback to 'letter' for long words */
			fallbackToLetter: true,
			/*	jQuery-selector for the element to keep and put after the ellipsis. */
			after		: null,
			/*	Whether to update the ellipsis: true/'window' */
			watch		: false,
			/*	Optionally set a max-height, if null, the height will be measured. */
			height		: null,
			/*	Deviation for the height-option. */
			tolerance	: 0,
			/*	Callback function that is fired after the ellipsis is added,
				receives two parameters: isTruncated(boolean), orgContent(string). */
			callback	: function( isTruncated, orgContent ) {},
			lastCharacter	: {
				/*	Remove these characters from the end of the truncated text. */
				remove		: [ ' ', ',', ';', '.', '!', '?' ],
				/*	Don't add an ellipsis if this array contains
					the last character of the truncated text. */
				noEllipsis	: []
			}
		});
		$( window ).resize(function() {
			$(".singlepost p").trigger("update");
		});
		$('.ginput_container input[type=text]').each(function(){
			$(this).parent().parent().addClass('text-input-container');
		});
	});

});
