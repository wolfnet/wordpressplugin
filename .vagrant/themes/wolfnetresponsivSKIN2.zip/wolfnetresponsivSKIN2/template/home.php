<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package bcore
 *
 * Template Name: Homepage
 *
 */

$communities = new WP_Query( 'post_type=city&orderby=title&order=ASC&posts_per_page=-1&meta_key=meta-checkbox&meta_value=yes' );
$communities_2 = new WP_Query( 'post_type=city&orderby=title&order=ASC&posts_per_page=3' );
$featured_pages = new WP_Query( 'post_type=page&orderby=title&order=ASC&posts_per_page=12&meta_key=meta-checkbox-homepage&meta_value=yes' );
$no_featured_pages = new WP_Query( 'post_type=page&orderby=title&order=ASC&posts_per_page=3' );
$blogfeedargs = array(
	'post_type' => array( 'post', 'city_post' ),
	'posts_per_page' => 4
	);
$blogpostsfour = new WP_Query( $blogfeedargs );

get_header(); ?>

<div id="featuredpages">
	<div class="container">
		<h1>Quick Links</h1>
		<p class="home_description">Learn more about the way we do business.</p>
		<?php
			// count total before reall loop (aready a max of 12)
		$featured_pages_total_count = 0;
		if ( $featured_pages->have_posts() ) {
			while ( $featured_pages->have_posts() ) {
				$featured_pages->the_post();
				$featured_pages_total_count++;
			}
		}
			// 10, 11, 12
		$featured_pages_to_display = 12;
			// 7, 8, 9
		if ( $featured_pages_total_count = 12 ) {
			$featured_pages_to_display = 12;
			if ( $featured_pages_total_count < 12 ) {
				$featured_pages_to_display = 9;


				// 4, 5, 6
				if ( $featured_pages_total_count = 9 ) {
					$featured_pages_to_display = 9;
					if ( $featured_pages_total_count < 9 ) {
						$featured_pages_to_display = 6;


					// 1, 2, 3
						if ( $featured_pages_total_count = 6 ) {
							$featured_pages_to_display = 6;
							if ( $featured_pages_total_count < 6 ) {
								$featured_pages_to_display = 3;


							}}}}
						}
					}
					wp_reset_postdata();
					?>
					<?php
			// the real loop
					$featured_pages_count = 0;
					if ( $featured_pages->have_posts() ) {
						echo '<ul>';
						while ( $featured_pages->have_posts() && $featured_pages_to_display > 0 ) {
							$featured_pages->the_post();
							$featured_pages_count++;
							$featured_pages_display_on_phone = get_post_meta(get_the_ID(), 'meta-checkbox-homepage-two', true);
							if ($featured_pages_display_on_phone == 'yes') {
								echo '<li class="featured_pages_li featured_pages_count_' . $featured_pages_count . ' featured_pages_display_on_phone"><a href="';
							}
							else {
								echo '<li class="featured_pages_li featured_pages_count_' . $featured_pages_count . '"><a href="';
							}
							echo the_permalink();
							echo '">';
							$fp_thumb_id = get_post_thumbnail_id();
							$fp_thumb_url_array = wp_get_attachment_image_src($fp_thumb_id, 'medium', true);
							$fp_thumb_url = $fp_thumb_url_array[0];
							echo '<div class="featured_page_image clear" style="background-image:url(' . $fp_thumb_url . ');">';
							echo '<div class="grey-tint"></div>';
							echo '</div>';
							echo '<div class="featured_page_link">';
							echo get_the_title();
							echo '</div>';
							echo '</a></li>';
					// calculate how many more you can display
							$featured_pages_to_display--;
						}
						echo '</ul>';
					} elseif ( $no_featured_pages->have_posts() ) {
						echo '<ul>';
						while ( $no_featured_pages->have_posts() && $featured_pages_to_display > 0 ) {
							$no_featured_pages->the_post();
							$featured_pages_count++;
							$featured_pages_display_on_phone = get_post_meta(get_the_ID(), 'meta-checkbox-homepage-two', true);
							if ($featured_pages_display_on_phone == 'yes') {
								echo '<li class="featured_pages_li featured_pages_count_' . $featured_pages_count . ' featured_pages_display_on_phone"><a href="';
							}
							else {
								echo '<li class="featured_pages_li featured_pages_count_' . $featured_pages_count . '"><a href="';
							}
							echo the_permalink();
							echo '">';
							$fp_thumb_id = get_post_thumbnail_id();
							$fp_thumb_url_array = wp_get_attachment_image_src($fp_thumb_id, 'medium', true);
							$fp_thumb_url = $fp_thumb_url_array[0];
							echo '<div class="featured_page_image clear" style="background-image:url(' . $fp_thumb_url . ');">';
							echo '<div class="grey-tint"></div>';
							echo '</div>';
							echo '<div class="featured_page_link">';
							echo get_the_title();
							echo '</div>';
							echo '</a></li>';
					// calculate how many more you can display
							$featured_pages_to_display--;
						}
						echo '</ul>';
					}
					else {
				// no posts found
					}
					wp_reset_postdata();
					?>
					<div class="clear"></div>
				</div>		
			</div>

			<div id="searchbyarea">
				<div class="container">
					<?php $communitiestitle = get_theme_mod( 'communitiestitle' ); if( !empty( $communitiestitle ) ): ?>
					<h1><?php echo $communitiestitle; ?></h1>
				<?php else: ?>
					<h1>Search By Area</h1>
				<?php endif; ?>
				<p class="home_description">Select an area for your custom home search.</p>
				<?php
			// count total before reall loop (aready a max of 21)
				$communities_total_count = 0;
				if ( $communities->have_posts() ) {
					while ( $communities->have_posts() ) {
						$communities->the_post();
						$communities_total_count++;
					}
				}
				// 19, 20, 21
				$communities_to_display = 21;
						// 16, 17, 18
				if ( $communities_total_count < 21 ) {
					$communities_to_display = 18;

					if ( $communities_total_count < 18 ) {
								// 13, 14, 15
						$communities_to_display = 15;
						if ( $communities_total_count < 15 ) {
							// 10, 11, 12
							$communities_to_display = 12;
							// 7, 8, 9
							if ( $communities_total_count < 12 ) {
								$communities_to_display = 9;
								// 4, 5, 6
								if ( $communities_total_count < 9 ) {
									$communities_to_display = 6;
									// 1, 2, 3
									if ( $communities_total_count < 6 ) {
										$communities_to_display = 3;
									}
								}
							}
						}
					}
				}
				wp_reset_postdata();
				?>
				<?php
			// the real loop
				$communities_count = 0;
				if ( $communities->have_posts() ) {
					echo '<ul>';
				// while ( $communities->have_posts() && $communities_to_display > 0 ) {
					while ( $communities->have_posts() ) {
						$communities->the_post();
						$communities_count++;
						$communities_display_on_phone = get_post_meta(get_the_ID(), 'meta-checkbox-homepage-two', true);
						if ($communities_display_on_phone == 'yes') {
							echo '<li class="communities_li communities_count_' . $communities_count . ' communities_display_on_phone"><div class="aspect-ratio-inner"><a href="';
						}
						else {
							echo '<li class="communities_li communities_count_' . $communities_count . '"><div class="aspect-ratio-inner"><a href="';
						}
						echo the_permalink();
						echo '">';
						echo '<div class="single_area"><div class="single_area_background"><div class="single_area_background_cover"><div class="single_area_text">';
						echo get_the_title();
						echo '</div></div></div></div></div>';
						echo '</a></li>';
					// calculate how many more you can display
					// $communities_to_display--;
					}
					echo '</ul>';
				} elseif($communities_2->have_posts()) {
				// no featured found
				// if ( $communities_2->have_posts() ) {
					echo '<ul>';
					while ( $communities_2->have_posts() ) {
						$communities_2->the_post();
						$communities_count++;
						$communities_display_on_phone = get_post_meta(get_the_ID(), 'meta-checkbox-homepage-two', true);
						if ($communities_display_on_phone == 'yes') {
							echo '<li class="communities_li communities_count_' . $communities_count . ' communities_display_on_phone"><div class="aspect-ratio-inner"><a href="';
						}
						else {
							echo '<li class="communities_li communities_count_' . $communities_count . '"><div class="aspect-ratio-inner"><a href="';
						}
						echo the_permalink();
						echo '">';
						echo '<div class="single_area"><div class="single_area_background"><div class="single_area_background_cover"><div class="single_area_text">';
						echo get_the_title();
						echo '</div></div></div></div></div>';
						echo '</a></li>';
					// calculate how many more you can display
						$communities_to_display--;
					}
					echo '</ul>';
				}
				else{
				//no posts found at all
				}
				wp_reset_postdata();
				?>
				<div class="clear"></div>
			</div>		
		</div>


		<div id="featuredproperties">
			<div class="container">
				<?php $homefeaturedtitle = get_theme_mod( 'homefeaturedtitle' ); if( !empty( $homefeaturedtitle ) ): ?>
				<h1><?php echo $homefeaturedtitle; ?></h1>
			<?php else: ?>
				<h1>Featured Listings</h1>
			<?php endif; ?>
			<p class="home_description">Select a featured listing from the properties below.</p>
			<div class="container_home1">
				<?php $homefeatured = get_theme_mod( 'homefeatured' ); if( !empty( $homefeatured ) ): ?>
				<?php echo do_shortcode($homefeatured); ?>
			<?php endif; ?>
		</div>
		<div class="clear"></div>
	</div>
</div>

<!--<?php $homefeatured2 = get_theme_mod( 'homefeatured2' ); if( !empty( $homefeatured2 ) ): ?>
	<div id="featuredproperties2">
		<div class="container">
			<?php $homefeatured2_title = get_theme_mod( 'homefeatured2_title' ); if( !empty( $homefeatured2_title ) ) { ?>
				<h1><?php echo $homefeatured2_title; ?></h1>
				<?php } else { ?>
					<h1>Featured Properties</h1>
					<?php } ?>
					<div class="container_home1">
						<?php echo do_shortcode($homefeatured2); ?>
					</div>
					<div class="clear"></div>
				</div>
			</div>
		<?php endif; ?>-->

	</div>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			<div class="container">
				<h1>Latest Blog Posts</h1>
				<p class="home_description">We've got something to say.</p>
				<?php $count = 0; ?>
				<?php while ( $blogpostsfour->have_posts() ) : $blogpostsfour->the_post(); ?>

					<?php $count++; ?>
					<?php $theexcerpt = get_the_excerpt(); ?>

					<a href="<?php the_permalink(); ?>">
						<div class="singlepost singlepost-<?php echo $count; ?>">
							<div class="tiltoutter">
								<div class="tiltinner latest-blog-posts-color"></div>
								<div class="tiltcontent"><?php bcore_posted_on(); ?></div>
							</div>						
							<span class="excerpt-span"><?php echo $theexcerpt; ?></span>
						</div>
					</a>

				<?php endwhile; // end of the loop. ?>

				<div class="view-all"><a href="<?php echo get_permalink( get_option('page_for_posts') );?>"><button>View All ></button></a></div>

				<div class="clear"></div>

			</div>
		</main><!-- #main -->
	</div><!-- #primary -->

	<div class="site-content">

		<div id="homecontactform">
			<div class="container">
			<!-- <h3>Contact Us</h3>
			<div class="contact_form_left">
				<?php 
				$secondary_image = get_theme_mod('secondaryimage');
				// images edit
				$secondary_image_part2 = parse_url($secondary_image);
				// image result
				$this_sites_home_url_footer = esc_url( home_url() );
				$secondary_image_part3 = $this_sites_home_url . $secondary_image_part2['path'] . $secondary_image_part2['query'] . $secondary_image_part2['fragment'];
				?>
				<img src="<?php echo $secondary_image_part3; ?>" alt="team photo">
			</div>
			<div class="contact_form_right">
				<?php // Get gravity forms shortcode from theme customizer
				$homegravityform = get_theme_mod('homegravityform'); 
				if ( $homegravityform ) { 
					echo do_shortcode( $homegravityform );
				}; ?>
			</div> -->
			<div class="footerwidgets">
				<div class="first">
					<?php dynamic_sidebar('footer1'); ?>
				</div>
				<div class="second">
					<?php dynamic_sidebar('footer2'); ?>
				</div>
			</div>
		</div>
	</div>

	<?php get_footer(); ?>
