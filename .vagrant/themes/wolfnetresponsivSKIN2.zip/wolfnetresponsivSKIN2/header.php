<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package bcore
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php wp_title( '|', true, 'right' ); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

<?php $this_sites_home_url = esc_url( home_url() ); ?>
<?php $logo_favicon = get_theme_mod('logofavicon'); ?>
<?php if ( ! empty( $logo_favicon ) ) : ?>
		<?php $logo_favicon_2 = parse_url($logo_favicon); ?>
		<?php $logo_favicon_3 = $logo_favicon_2['path'] . '?' . $logo_favicon_2['query'] . '#' . $logo_favicon_2['fragment']; ?>
		<link rel="icon" href="<?php echo $this_sites_home_url; ?><?php echo esc_url( $logo_favicon_3 ); ?>" />
<?php endif ?>

<!-- Test -->
<?php wp_head(); ?>

<?php
	$color_main = get_theme_mod('cprimary');
	$content_link_color = get_theme_mod('csecondary');
	$color_main_text = get_theme_mod('cprimary_text');
	$content_link_color_text = get_theme_mod('csecondary_text');
	$advancedsearchlink = get_theme_mod( 'advancedsearchlink' );
	$header_image = get_theme_mod('imageheader');
	$header_image2 = get_theme_mod('imageheader2');
	$header_image3 = get_theme_mod('imageheader3');
	// $header_image = get_theme_mod('imageheader');
	$heder_image_choice = 0; /*false*/
	$random_temp = 0;
	// new color
	$color_button_link = get_theme_mod('button_color');
	if ($color_button_link == null) {
		$color_button_link = $color_main;
	}
	$color_footer = get_theme_mod('csecondary_text');
	if ($color_footer == null) {
		$color_footer = $color_main;
	}
	// images edit
	$header_image_part2 = parse_url($header_image);
	$header_image2_part2 = parse_url($header_image2);
	$header_image3_part2 = parse_url($header_image3);
	// image result
	$header_image_part3 = $this_sites_home_url . $header_image_part2['path'] . $header_image_part2['query'] . $header_image_part2['fragment'];
	$header_image2_part3 = $this_sites_home_url . $header_image2_part2['path'] . $header_image2_part2['query'] . $header_image2_part2['fragment'];
	$header_image3_part3 = $this_sites_home_url . $header_image3_part2['path'] . $header_image3_part2['query'] . $header_image3_part2['fragment'];
	// if all 3 (1 situation)
	if ($header_image != '' && $header_image2 != '' && $header_image3 != '') {
		$heder_image_choice = rand(1,3);
	}
	// if 2 (3 situations)
	else if ($header_image != '' && $header_image2 != '' && $header_image3 == '') {
		$heder_image_choice = rand(1,2);
	}
	else if ($header_image != '' && $header_image2 == '' && $header_image3 != '') {
		$random_temp = rand(1,2);
		if ($random_temp == 2) {
			$heder_image_choice = 3;
		} else {
			$heder_image_choice = 1;
		}
	}
	else if ($header_image == '' && $header_image2 != '' && $header_image3 != '') {
		$random_temp = rand(1,2);
		if ($random_temp == 1) {
			$heder_image_choice = 3;
		} else {
			$heder_image_choice = 2;
		}
	}
	// if 1 (3 situatioins)
	else if ($header_image != '' && $header_image2 == '' && $header_image3 == '') {
		$heder_image_choice = 1;
	}
	else if ($header_image == '' && $header_image2 != '' && $header_image3 == '') {
		$heder_image_choice = 2;
	}
	else if ($header_image == '' && $header_image2 == '' && $header_image3 != '') {
		$heder_image_choice = 3;
	}
	// secondary image
	$secondary_image = get_theme_mod('secondaryimage');
	$secondary_image_part2 = parse_url($secondary_image);
	$secondary_image_part3 = $this_sites_home_url . $secondary_image_part2['path'] . $secondary_image_part2['query'] . $secondary_image_part2['fragment'];
	$choosen_middle_image = $secondary_image_part3;
	if ($secondary_image == null) {
		$choosen_middle_image = $this_sites_home_url . '/wp-content/themes/wolfnetresponsivSKIN2/img/skin2/unit.jpg';
	}
?>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script> -->
<?php $quicksearchtitle = get_theme_mod( 'homequicksearchtitle' ); ?>
<style>

	#site-navigation .bcore-mobile-toggle {
		display: none !important;
	}

	#site-navigation .bcore-mobile-toggle:first-of-type {
		display: block !important;
	}

	#bcore-mobile-menu {
		display: none;
	}

	/*#bcore-mobile-menu:last-of-type {
		display: block !important;
	}*/

	#bcore-mobile-menu .bcore-mobile-toggle {
		display: none !important;
	}


		<?php $choosen_header_image = ''; ?>
	<?php if ($heder_image_choice != 0) { ?>
		<?php if ($heder_image_choice == 1) { ?>
			header#bcore-header { background-image: url(<?php echo $header_image_part3; ?>); }
			[data-bcowolf="true"] header#bcore-header { background-image: url(<?php echo $header_image_part3; ?>) !important; }
			<?php $choosen_header_image = $header_image_part3; ?>
		<?php } ?>
		<?php if ($heder_image_choice == 2) { ?>
			header#bcore-header { background-image: url(<?php echo $header_image2_part3; ?>); }
			[data-bcowolf="true"] header#bcore-header { background-image: url(<?php echo $header_image2_part3; ?>) !important; }
			<?php $choosen_header_image = $header_image2_part3; ?>
		<?php } ?>
		<?php if ($heder_image_choice == 3) { ?>
			header#bcore-header { background-image: url(<?php echo $header_image3_part3; ?>); }
			[data-bcowolf="true"] header#bcore-header { background-image: url(<?php echo $header_image3_part3; ?>) !important; }
			<?php $choosen_header_image = $header_image3_part3; ?>
		<?php } ?>
	<?php } ?>
	<?php if ($choosen_header_image == '') {
		$choosen_header_image = $this_sites_home_url . '/wp-content/themes/wolfnetresponsivSKIN2/img/skin2/buildings.jpg';
	} ?>
</style>
<script type="text/javascript">
	// rbga
	var jsrgba_hex = '<?php echo $color_main; ?>';
	var jsrgba_opacity = '75';
	var jsrgba_light_opacity = '15';
	var jsrgba_opacity_hover = '90';
	jsrgba_hex = jsrgba_hex.replace('#','');
	var jsrgba_r = parseInt(jsrgba_hex.substring(0,2), 16);
	var jsrgba_g = parseInt(jsrgba_hex.substring(2,4), 16);
	var jsrgba_b = parseInt(jsrgba_hex.substring(4,6), 16);
	var jsrgba_result = 'rgba('+jsrgba_r+','+jsrgba_g+','+jsrgba_b+','+jsrgba_opacity/100+')';
	var jsrgba_result_hover = 'rgba('+jsrgba_r+','+jsrgba_g+','+jsrgba_b+','+jsrgba_opacity_hover/100+')';
	var jsrgba_light_result = 'rgba('+jsrgba_r+','+jsrgba_g+','+jsrgba_b+','+jsrgba_light_opacity/100+')';
	// rgba button
	var jsrgba_hex_button = '<?php echo $color_button_link; ?>';
	if (jsrgba_hex_button !== '') {
		jsrgba_hex_button = jsrgba_hex_button.replace('#','');
		var jsrgba_r_button = parseInt(jsrgba_hex_button.substring(0,2), 16);
		var jsrgba_g_button = parseInt(jsrgba_hex_button.substring(2,4), 16);
		var jsrgba_b_button = parseInt(jsrgba_hex_button.substring(4,6), 16);
		var jsrgba_result_button = 'rgba('+jsrgba_r_button+','+jsrgba_g_button+','+jsrgba_b_button+','+jsrgba_opacity/100+')';
		var jsrgba_result_hover_button = 'rgba('+jsrgba_r_button+','+jsrgba_g_button+','+jsrgba_b_button+','+jsrgba_opacity_hover/100+')';
		var jsrgba_light_result_button = 'rgba('+jsrgba_r_button+','+jsrgba_g_button+','+jsrgba_b_button+','+jsrgba_light_opacity/100+')';
	}
	// works here
	jQuery(function($) {
		// stops workin ghere
		// alert('test');
		$('header#bcore-header .header-container').css('background',jsrgba_result);
		$('#secondary .wolfnet_widget.wolfnet_quickSearch').css('background',jsrgba_light_result);
		$('b.home3buttons .home3buttons-single').css('background',jsrgba_result);
		$('b.home3buttons .home3buttons-single').hover(
			function() {
				$(this).css('background',jsrgba_result_hover);
			}, function() {
				$(this).css('background',jsrgba_result);
			}
		);
		$('body.home #searchbyarea h1').css('background',jsrgba_result);
		$('body.home #searchbyarea .home_description').css('background',jsrgba_result);
		$('#secondary .wolfnet_widget.wolfnet_quickSearch').css('background',jsrgba_result);
		if (jsrgba_hex_button !== '') {
			$('.home3buttons .home3buttons-single').css('background',jsrgba_result_button);
			$('.home3buttons .home3buttons-single').hover(
				function() {
					$(this).css('background',jsrgba_result_hover_button);
				}, function() {
					$(this).css('background',jsrgba_result_button);
				}
			);
		}
	});
	// alert(jsrgba_result);
	// QuickSearch Title
	jQuery(function($) {
		var quicksearchtitle = '<?php echo $quicksearchtitle; ?>';
		if (quicksearchtitle !== '') {
			$('body.home #bcore-header .wolfnet_widgetTitle').html(quicksearchtitle);
		} else {
			$('body.home #bcore-header .wolfnet_widgetTitle').html('Search and Find. Your home awaits.');
		}
	});
	// for parallax
	var choosen_header_image_js = '<?php echo $choosen_header_image; ?>';
	var choosen_middle_image_js = '<?php echo $choosen_middle_image; ?>';
</script>
<?php//wp_head(); ?>


<style>
	/*body, body.custom-background { background: <?php echo $content_link_color; ?>; }*/

	<?php if( get_theme_mod( 'homequicksearchdisplay' ) == '1') { ?>
		#bcore-header .wolfnet_smartSearch { display: none !important; }
		#bcore-header .advancedsearchcontain { display: none !important; }
		#bcore-header #homepage-search-box, #bcore-header .home3buttons { display: none !important; }
		#bcore-header #qs-spacer { display: block; }
	/*	body.home header#bcore-header { height: 300px; }*/
	<?php } ?>
	#mobile_navigation_contain #mobile_nav ul li { background: <?php echo $color_main; ?>; }
	/*test*/
	header#bcore-header .header-container { background: <?php echo $color_main; ?>; color: <?php echo $color_main_text; ?>; }
	header#bcore-header .header-container a { color: <?php echo $color_main_text; ?>; }
	/*header#bcore-header .sub-menu { background: <?php echo $color_main; ?>; }*/
	body.home .wolfnet_quickSearch .wolfnet_widgetBedBath label { color: <?php echo $color_main; ?>; }
	button.wolfnet_quickSearchForm_submitButton,
	button.wolfnet_quickSearchForm_submitButton:hover,
	button.wolfnet_smartSearchForm_submitButton,
	button.wolfnet_smartSearchForm_submitButton:hover,
	.homepage-search-box input[type="submit"],
	.homepage-search-box input[type="submit"]:hover {
		background: <?php echo $color_main; ?> !important;
	}
	body.home #bcore-header .wolfnet_widget.wolfnet_smartSearch .wolfnet_smartBedBathFields .wolfnet_smartBeds,
	body.home #bcore-header .wolfnet_widget.wolfnet_smartSearch .wolfnet_smartBedBathFields .wolfnet_smartBaths,
	body.home #bcore-header .wolfnet_widget.wolfnet_smartSearch .wnt-smartsearch,
	body.home #bcore-header .wolfnet_widget.wolfnet_smartSearch .wolfnet_smartPriceFields > div {
		border-color: <?php echo $color_main; ?> !important;
	}
	.home3buttons .home3buttons-single { background: <?php echo $color_main; ?>; }
	/*body.home .home3buttons .home3buttons-single:hover { background: <?php echo $color_main; ?> !important; }*/
	body.home header#bcore-header .wolfnet_quickSearch .wolfnet_widgetPrice div select, body.home header#bcore-header .wolfnet_quickSearch .wolfnet_widgetPrice div select, body.home header#bcore-header .wolfnet_quickSearch .wolfnet_widgetBedBath div select { border-top: 2px solid <?php echo $color_main; ?>; border-bottom: 2px solid <?php echo $color_main; ?>; }
	@media (max-width: 789px) { body.home header#bcore-header .wolfnet_quickSearch .wolfnet_widgetPrice div:nth-of-type(1) select { border-left: 2px solid <?php echo $color_main; ?> !important; border-bottom: 2px solid <?php echo $color_main; ?> !important; } }
	@media (max-width: 789px) { body.home header#bcore-header .wolfnet_quickSearch .wolfnet_widgetBedBath div:first-of-type select { border-left: 2px solid <?php echo $color_main; ?> !important; border-bottom: 2px solid <?php echo $color_main; ?> !important; } }
	@media (max-width: 789px) { body.home header#bcore-header .wolfnet_quickSearch .wolfnet_widgetPrice div:nth-of-type(2) select { border-right: 2px solid <?php echo $color_main; ?> !important; border-bottom: 2px solid <?php echo $color_main; ?> !important; } }
	@media (max-width: 789px) { body.home header#bcore-header .wolfnet_quickSearch .wolfnet_widgetBedBath div:last-of-type select { border-right: 2px solid <?php echo $color_main; ?> !important; border-bottom: 2px solid <?php echo $color_main; ?> !important; } }
	@media (max-width: 789px) { body.home header#bcore-header .wolfnet_quickSearch .wolfnet_widgetPrice > div:first-of-type, body.home header#bcore-header .wolfnet_quickSearch .wolfnet_widgetBedBath > div:first-of-type { border-right: 2px solid <?php echo $color_main; ?>; } }
	.gform_wrapper input[type=submit] { border: 2px solid <?php echo $color_main; ?>; }
	hr { background: <?php echo $color_main; ?>; }
	a, a:hover, a:focus, a:active, a:visited { color: <?php echo $color_main; ?>; }
	body.home .wolfnet_widget.wolfnet_quickSearch.wolfnet_wWide .wolfnet_quickSearch_form select { color: <?php echo $color_main; ?> !important; }
	footer#bcore-footer a { color: <?php echo $content_link_color_text; ?>; }
	/*primary color update*/
	body.bcore-mobile-menu-enabled nav#bcore-mobile-menu ul.menu > li a:hover { color: <?php echo $color_main; ?>; }
	body.bcore-mobile-menu-enabled .open-children:hover { color: <?php echo $color_main; ?>; border-color: <?php echo $color_main; ?>; }
	button.wolfnet_quickSearchForm_submitButton:hover { color: <?php echo $color_main; ?> !important; }
	button.wolfnet_smartSearchForm_submitButton:hover { color: <?php echo $color_main; ?> !important; }
/*	body.home #featuredproperties .wolfnet_listing span.wolfnet_price, body.home #featuredproperties2 .wolfnet_listing span.wolfnet_price { color: <?php echo $color_main; ?>; }*/
	/*.footerwidgets .wolfnet_widget.wolfnet_listingGrid .wolfnet_listings .wolfnet_listing span.wolfnet_price { color: <?php echo $color_main; ?>; }*/
	body.home #homecontactform input[type=submit] { border-color: <?php echo $color_main; ?>; }
	body.home .gform_button:hover { background: <?php echo $color_main; ?>; }
	/*primary color update - internal*/
	#secondary aside.widget_wolfnet_quicksearchwidget .wolfnet_widgetPrice div:first-of-type select, #secondary aside.widget_wolfnet_quicksearchwidget .wolfnet_widgetBedBath div:first-of-type select { border-left: 2px solid <?php echo $color_main; ?> !important; }
	#secondary aside.widget_wolfnet_quicksearchwidget .wolfnet_quickSearch .wolfnet_widgetPrice div select, #secondary aside.widget_wolfnet_quicksearchwidget .wolfnet_quickSearch .wolfnet_widgetBedBath div select { border-top: 2px solid <?php echo $color_main; ?> !important; border-bottom: 2px solid <?php echo $color_main; ?> !important; }
	#secondary aside.widget_wolfnet_quicksearchwidget .wolfnet_widgetPrice div:nth-of-type(2) select, #secondary aside.widget_wolfnet_quicksearchwidget .wolfnet_widgetPrice div:last-of-type select, #secondary aside.widget_wolfnet_quicksearchwidget .wolfnet_widgetBedBath div:last-of-type select { border-right: 2px solid <?php echo $color_main; ?> !important; }
	button.wolfnet_quickSearchForm_submitButton:hover { border: 2px solid <?php echo $color_main; ?> !important; }
	button.wolfnet_smartSearchForm_submitButton:hover { border: 2px solid <?php echo $color_main; ?> !important; }
	/*.gform_wrapper input:hover, .gform_wrapper textarea:hover { border: 1px solid <?php echo $color_main; ?>; }*/
	body.home #primary .view-all button { border: 2px solid <?php echo $color_main; ?>; }
	body.home #primary .view-all button:hover { background: <?php echo $color_main; ?>; }
	@media (max-width: 789px) { body.home header#bcore-header .wolfnet_quickSearch .wolfnet_widgetBedBath div:last-of-type select { border-right: 0 !important; } }
	/*button and link color*/
	a, a:hover, a:focus, a:active, a:visited { color: <?php echo $color_button_link; ?>; }
	button, input[type=submit] { border: 2px solid <?php echo $color_button_link; ?>; }
	button:hover, input[type=submit]:hover, .gform_wrapper input[type=submit] { border: 2px solid <?php echo $color_button_link; ?>; color: #313131; }
	body.home #primary .view-all button, body.home #homecontactform input[type=submit], .gform_footer input[type=submit] { border: 2px solid <?php echo $color_button_link; ?>; }
	body.home #primary .view-all button:hover, body.home .gform_button:hover, .gform_footer input[type=submit]:hover { background: <?php echo $color_button_link; ?>; }
	body:not(.home) button.wolfnet_quickSearchForm_submitButton,
	body:not(.home) button.wolfnet_quickSearchForm_submitButton:hover,
	body:not(.home) button.wolfnet_smartSearchForm_submitButton,
	body:not(.home) button.wolfnet_smartSearchForm_submitButton:hover {
		background: <?php echo $color_button_link; ?>;
	}

	body:not(.home) .entry-content .wolfnet_widget.wolfnet_quickSearch.wolfnet_quickSearch_basic .wnt-smartsearch .wnt-smart-search,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_smartSearch .wnt-smartsearch .wnt-smart-search,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_quickSearch.wolfnet_quickSearch_basic .wolfnet_searchTypeField input,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_smartSearch .wolfnet_searchTypeField input,
	body:not(.home) #secondary .wolfnet_widget.wolfnet_smartSearch .wnt-smartsearch .wnt-smart-search,
	body:not(.home) #secondary .wolfnet_widget.wolfnet_smartSearch .wolfnet_smartPriceFields > div select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_quickSearch.wolfnet_quickSearch_basic .wolfnet_widgetPrice > div select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_quickSearch.wolfnet_quickSearch_basic .wolfnet_smartPriceFields > div select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_smartSearch .wolfnet_widgetPrice > div select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_smartSearch .wolfnet_smartPriceFields > div select,
	body:not(.home) #secondary .wolfnet_widget.wolfnet_smartSearch .wolfnet_smartBedBathFields .wolfnet_smartBeds select,
	body:not(.home) #secondary .wolfnet_widget.wolfnet_smartSearch .wolfnet_smartBedBathFields .wolfnet_smartBaths select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_quickSearch.wolfnet_quickSearch_basic .wolfnet_widgetBedBath .wolfnet_widgetBeds select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_quickSearch.wolfnet_quickSearch_basic .wolfnet_widgetBedBath .wolfnet_widgetBaths select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_quickSearch.wolfnet_quickSearch_basic .wolfnet_widgetBedBath .wolfnet_smartBeds select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_quickSearch.wolfnet_quickSearch_basic .wolfnet_widgetBedBath .wolfnet_smartBaths select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_quickSearch.wolfnet_quickSearch_basic .wolfnet_smartBedBathFields .wolfnet_widgetBeds select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_quickSearch.wolfnet_quickSearch_basic .wolfnet_smartBedBathFields .wolfnet_widgetBaths select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_quickSearch.wolfnet_quickSearch_basic .wolfnet_smartBedBathFields .wolfnet_smartBeds select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_quickSearch.wolfnet_quickSearch_basic .wolfnet_smartBedBathFields .wolfnet_smartBaths select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_smartSearch .wolfnet_widgetBedBath .wolfnet_widgetBeds select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_smartSearch .wolfnet_widgetBedBath .wolfnet_widgetBaths select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_smartSearch .wolfnet_widgetBedBath .wolfnet_smartBeds select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_smartSearch .wolfnet_widgetBedBath .wolfnet_smartBaths select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_smartSearch .wolfnet_smartBedBathFields .wolfnet_widgetBeds select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_smartSearch .wolfnet_smartBedBathFields .wolfnet_widgetBaths select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_smartSearch .wolfnet_smartBedBathFields .wolfnet_smartBeds select,
	body:not(.home) .entry-content .wolfnet_widget.wolfnet_smartSearch .wolfnet_smartBedBathFields .wolfnet_smartBaths select {
		border-color: <?php echo $color_main; ?> !important;
	}

	body:not(.home) button.wolfnet_quickSearchForm_submitButton:hover { background: <?php echo $color_button_link; ?> !important; }
	body:not(.home) button.wolfnet_quickSearchForm_submitButton { border: 2px solid <?php echo $color_button_link; ?> !important; }
	body:not(.home) button.wolfnet_smartSearchForm_submitButton:hover { background: <?php echo $color_button_link; ?> !important; }
	body:not(.home) button.wolfnet_smartSearchForm_submitButton { border: 2px solid <?php echo $color_button_link; ?> !important; }

	#secondary aside.widget_wolfnet_quicksearchwidget .wolfnet_quickSearch .wolfnet_searchType li a.wolfnet_active { background: <?php echo $color_button_link; ?>; }
	#secondary aside.widget_wolfnet_quicksearchwidget .wolfnet_quickSearch .wolfnet_searchType li { border-color: <?php echo $color_button_link; ?>; }
	/*body.home #featuredproperties .wolfnet_listing span.wolfnet_price, body.home #featuredproperties2 .wolfnet_listing span.wolfnet_price { color: <?php echo $color_button_link; ?>; }*/
	/*.footerwidgets .wolfnet_widget.wolfnet_listingGrid .wolfnet_listings .wolfnet_listing span.wolfnet_price { color: <?php echo $color_button_link; ?>; }*/
	/*footer*/
	footer#bcore-footer { color: <?php echo $color_footer; ?>; }
	.wolfnet_marketDisclaimer { color: <?php echo $color_footer; ?>; }
	/*header*/
	/*h1,h2,h3,h4,h5,h6 { color: <?php echo $color_main_text; ?>; }*/
	.bcore-header { color: <?php echo $color_main_text; ?>; }
	/*skin2*/
	body.home #searchbyarea ul .single_area .single_area_text { border: 2px solid <?php echo $color_main; ?>; }
	.latest-blog-posts-color { background: <?php echo $color_main; ?>; }
	.latest-blog-posts-color-svg { fill: <?php echo $color_main; ?>; }
	body.home h1, body.home #homecontactform h3 { color: <?php echo $color_main; ?>; }
	body.home #primary .view-all button { color: <?php echo $color_main; ?>; }
	#secondary aside.widget_wolfnet_quicksearchwidget .wolfnet_quickSearch .wolfnet_quickSearchFormButton button { background: <?php echo $color_main; ?>; }
	header#bcore-header { background-image: url(<?php echo $choosen_header_image; ?>); }
	body.home #searchbyarea { background-image: url(<?php echo $choosen_middle_image; ?>); }
</style>

</head>

<body <?php body_class(); ?>>
<div id="bcorr-body-cover"></div>
<div id="page" class="hfeed site">
	<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'bcore' ); ?></a>
	<?php if(!is_archive() && !is_singular('agent')): ?>
		<?php if(has_post_thumbnail()): ?>
			<?php $thumb = wp_get_attachment_url(get_post_thumbnail_id($post->ID)); ?>
		<header id="bcore-header" class="site-header" role="banner" style="background-image: url( <?php echo $thumb; ?>);">
		<?php else: ?>
		<header id="bcore-header" class="site-header" role="banner">
		<?php endif; ?>
	<?php elseif(is_singular('agent')): ?>
		<header id="bcore-header" class="site-header" role="banner">
	<?php else: ?>
		<header id="bcore-header" class="site-header" role="banner">
	<?php endif; ?>
		<div class="header-container">
			<div class="container container-first">
				<div class="site-branding">
					<?php $brokerimage = get_theme_mod( 'logob' ); if( !empty( $brokerimage ) ): ?>
						<?php $brokerimage_2 = parse_url($brokerimage); ?>
						<?php $brokerimage_3 = $brokerimage_2['path'] . '?' . $brokerimage_2['query'] . '#' . $brokerimage_2['fragment']; ?>
						<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
							<img src="<?php echo $this_sites_home_url; ?><?php echo $brokerimage_3; ?>" id="headerbrokerlogo">
							<span><?php bloginfo( 'name' ); ?></span>
						</a></h1>
					<?php else: ?>
						<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
							<!-- <img src=""> -->
							<span><?php bloginfo( 'name' ); ?></span>
						</a></h1>
					<?php endif; ?>
				</div>
				<nav id="site-navigation" class="main-navigation" role="navigation">
					<!-- <button class="menu-toggle"><img src="<?php bloginfo('template_url'); ?>/img/menu_mobile.png"></button> -->
					<?php wp_nav_menu( array( 'theme_location' => 'primary' ) ); ?>
				</nav>
				<div class="social-links">
					<?php $tw = get_theme_mod( 'tw' ); if( !empty( $tw ) ): ?>
						<a href="<?php echo $tw; ?>" target="_blank" class="sl tw">twitter</a>
					<?php endif; ?>
					<?php $pin = get_theme_mod( 'pin' ); if( !empty( $pin ) ): ?>
						<a href="<?php echo $pin; ?>" target="_blank" class="sl pin">pintrest</a>
					<?php endif; ?>
					<?php $in = get_theme_mod( 'in' ); if( !empty( $in ) ): ?>
						<a href="<?php echo $in; ?>" target="_blank" class="sl in">linkedin</a>
					<?php endif; ?>
					<?php $insta = get_theme_mod( 'insta' ); if( !empty( $insta ) ): ?>
						<a href="<?php echo $insta; ?>" target="_blank" class="sl insta">instagram</a>
					<?php endif; ?>
					<?php $gp = get_theme_mod( 'gp' ); if( !empty( $gp ) ): ?>
						<a href="<?php echo $gp; ?>" target="_blank" class="sl gp">google+</a>
					<?php endif; ?>
					<?php $fb = get_theme_mod( 'fb' ); if( !empty( $fb ) ): ?>
						<a href="<?php echo $fb; ?>" target="_blank" class="sl fb">facebook</a>
					<?php endif; ?>
					<?php $yt = get_theme_mod( 'yt' ); if( !empty( $yt ) ): ?>
						<a href="<?php echo $yt; ?>" target="_blank" class="sl yt" style="background-position: -160px 0;">YouTube</a>
					<?php endif; ?>
				</div>
				<div class="clear"></div>
				<?php $logom = get_theme_mod( 'logom' ); if( !empty( $logom ) ): ?>
					<?php $logom_2 = parse_url($logom); ?>
					<?php $logom_3 = $logom_2['path'] . '?' . $logom_2['query'] . '#' . $logom_2['fragment']; ?>
					<img src="<?php echo $this_sites_home_url; ?><?php echo $logom_3; ?>" alt="logo" class="mainlogo">
					<style>
						/*body.home .wolfnet_quickSearch {
							margin-top: 0;
						}*/
						@media (max-width: 789px) { body.home header#bcore-header { height: 700px; } }
					</style>
				<?php else: ?>
					<style>
						body.home .wolfnet_quickSearch {
							margin-top: 250px;
						}
						@media (max-width: 789px) { body.home .wolfnet_quickSearch { margin-top: 225px; } }
						@media (max-width: 450px) { body.home .wolfnet_quickSearch { margin-top: 55px; } }
					</style>
				<?php endif; ?>
			</div>
			<?php //if ( is_front_page() ): ?>
			<div class="container container-second">

				<?php //echo do_shortcode('[wnt_search title="Quick Search" smartsearch="true" /]'); ?>

				<style>
					.homepage-search-box {
						display: block;
						position: relative;
						padding: 9px 25px 20px 25px;
						margin: 0 auto;
						width: 40%;
						width: 660px;
						width: 90%;
						max-width: 700px;
						background: #444444;
						background: rgba(49, 49, 49, 0.7);
						-webkit-border-radius: 0;
						border-radius: 0;
						border: 0;
						top: 2em;
						margin-top: 150px;
						font-size: 14px;
					}
					@media (max-width: 789px) {
						.homepage-search-box {
							margin-top: 33px;
						}
					}
					.homepage-search-box--toggles {
						position: absolute;
						bottom: 100%;
						left: 0;
					}
					.homepage-search-box--toggles div {
						background-color: rgba(49, 49, 49, 0.9);
						display: inline-block;
						margin-right: 5px;
						padding: 5px 10px;
						border-radius: 3px 3px 0 0;
						font-weight: 700;
						cursor: pointer;
						color: rgba(255,255,255,0.7);
					}
					.homepage-search-box--toggles div:hover {
						color: rgba(255,255,255,0.9);
					}
					[data-search-box="search"] #homepage-search-box--toggle-search {
						background-color: rgba(49, 49, 49, 0.7);
						color: #fff;
					}
					[data-search-box="value"] #homepage-search-box--toggle-value {
						background-color: rgba(49, 49, 49, 0.7);
						color: #fff;
					}
					[data-search-box="search"] .homepage-search-box--value {
						display: none;
					}
					[data-search-box="value"] .homepage-search-box--search {
						display: none;
					}
					.homepage-search-box .gform_heading {
						text-align: center;
					}
					.homepage-search-box form:before,
					.homepage-search-box form:after {
						content: "";
						clear: both;
						display: table;
					}
					.homepage-search-box .gform_title {
						text-align: center;
						text-transform: none;
						font-weight: 400;
						font-size: 2em;
						line-height: normal;
						margin: 0 0 14px !important;
						font-weight: 400 !important;
						color: #ffffff;
						text-shadow: 1px 1px 4px black;
						font-size: 2em !important;
					}
					.homepage-search-box .gform_body {
						float: left;
						width: calc(100% - 108px);
					}
					.homepage-search-box .gform_body li {
						margin: 0 !important;
					}
					.homepage-search-box .ginput_container {
						margin: 0 !important;
					}
					.homepage-search-box .gform_footer {
						float: right;
						width: 108px;
						margin: 0 !important;
						padding: 0 !important;
						clear: none !important;
					}
					.homepage-search-box input[type="submit"] {
						color: #fff !important;
					}
					.homepage-search-box .wolfnet_smartSearch,
					.homepage-search-box .wolfnet_quickSearch {
						padding: 0 !important;
						margin: 0 !important;
						background: transparent !important;
						width: 100% !important;
						top: 0 !important;
					}
					.homepage-search-box .gform_wrapper {
						margin: 0 !important;
					}
					@media (max-width: 789px) {
						.homepage-search-box .gform_body {
							width: 100%;
						}
						.homepage-search-box .gform_footer {
							width: 100%;
						}
					}
					.homepage-search-box .gfield_description.validation_message {
						color: #ffd5d5;
					}
					.homepage-search-box .gform_wrapper .validation_error {
						padding: 0;
						margin: 0 0 10px;
						border: none;
						color: #ffd5d5;
						font-size: 14px;
					}
					.homepage-search-box .gform_wrapper .gfield_label {
						display: none !important;
					}
				</style>
				<?php if( get_theme_mod( 'homequicksearchdisplay' ) == '1') : ?>
					<?php if( get_option('front_page_home_value_form') ) : ?>
						<div id="homepage-search-box" class="homepage-search-box" data-search-box="value">
					<?php endif;?>
				<?php else: ?>
					<div id="homepage-search-box" class="homepage-search-box" data-search-box="search">
				<?php endif; ?>
				<?php if ( get_option('front_page_home_value_form') ) : ?>
					<?php if( get_theme_mod( 'homequicksearchdisplay' ) == '1') : ?>
						<div id="homepage-search-box--toggles" class="homepage-search-box--toggles">
							<div id="homepage-search-box--toggle-value">What Is My Home Worth?</div>
						</div>
					<?php else: ?>
						<div id="homepage-search-box--toggles" class="homepage-search-box--toggles">
							<div id="homepage-search-box--toggle-search">Search Homes</div>
							<div id="homepage-search-box--toggle-value">What Is My Home Worth?</div>
						</div>
					<?php endif; ?>
				<?php endif; ?>
				<?php if( get_theme_mod( 'homequicksearchdisplay' ) != '1') : ?>
					<div id="homepage-search-box--search" class="homepage-search-box--search">
						<?php
							$manual_shortcode = get_theme_mod( 'homeqsshortcode' );
							if ( get_theme_mod('homeqsshortcode' ) ) {
								echo ( is_front_page() ) ? do_shortcode($manual_shortcode) : '';

							} elseif ( get_theme_mod('smartsearch') == '1' ) {
								echo ( is_front_page() ) ? do_shortcode('[wnt_search title="QuickSearch" smartsearch="false" view="basic" /]') : '';

							} else {
								echo ( is_front_page() ) ? do_shortcode('[wnt_search title="<?php echo $quicksearchtitle; ?>" smartsearch="true" /]') : '';
							}
						?>
					</div>
				<?php endif; ?>
					<?php if ( is_front_page() && get_option('front_page_home_value_form') ) : ?>
						<div id="homepage-search-box--value" class="homepage-search-box--value">
							<?php echo do_shortcode('[gravityform id="' . get_option('front_page_home_value_form') . '" title="true" description="true" ajax="false"]'); ?>
						</div>
					<?php endif; ?>
				<?php if( get_option('front_page_home_value_form') || (get_theme_mod( 'homequicksearchdisplay' ) != '1')) : ?>
					</div>
				<?php endif; ?>


				<!-- <div id="qs-spacer"></div> -->
				<div class="clear"></div>
				<?php $advancedsearchlink = get_theme_mod( 'advancedsearchlink' );
				$searchbygallerylink = get_theme_mod( 'searchbygallerylink' );
				$searchbylistlinks = get_theme_mod( 'searchbylistlinks' );
				$home_buttons_count = 0;
				if( !empty( $advancedsearchlink ) || !empty( $searchbygallerylink ) || !empty( $searchbylistlinks ) ):
				?>
					<div class="home3buttons">
						<?php if( !empty( $advancedsearchlink ) ): ?>
						<a href="<?php echo $advancedsearchlink; ?>" class="home3buttons-1-link">
							<div class="home3buttons-single home3buttons-1">
								<img src="<?php bloginfo('template_url'); ?>/img/skin2/search_by_map.png" alt="search by map">
							</div>
						</a>
						<?php $home_buttons_count++; ?>
						<?php endif; ?>
						<?php if( !empty( $searchbygallerylink ) ): ?>
						<a href="<?php echo $searchbygallerylink; ?>" class="home3buttons-2-link">
							<div class="home3buttons-single home3buttons-2">
								<img src="<?php bloginfo('template_url'); ?>/img/skin2/search_by_gallery.png" alt="search by gallery">
							</div>
						</a>
						<?php $home_buttons_count++; ?>
						<?php endif; ?>
						<?php if( !empty( $searchbylistlinks ) ): ?>
						<a href="<?php echo $searchbylistlinks; ?>" class="home3buttons-3-link">
							<div class="home3buttons-single home3buttons-3">
								<img src="<?php bloginfo('template_url'); ?>/img/skin2/search_by_list.png" alt="search by list">
							</div>
						</a>
						<?php $home_buttons_count++; ?>
						<?php endif; ?>
						<?php if ( $home_buttons_count == 2 ): ?>
							<style>
								body.home .home3buttons { width: 50%; }
								@media (max-width: 1080px) { body.home .home3buttons { width: 75%; } }
								@media (max-width: 789px) { body.home .home3buttons { width: 50%; } }
								@media (max-width: 500px) { body.home .home3buttons { width: 70%; } }
							</style>
						<?php endif; ?>
						<?php if ( $home_buttons_count == 1 ): ?>
							<style>
								body.home .home3buttons { -webkit-justify-content: center; justify-content: center; }
							</style>
						<?php endif; ?>
					</div>
				<?php //endif; ?>
			</div>
		</div>
		<?php endif ?>
	</header>

	<div id="content" class="site-content">
		<!-- <div class="container"> -->
