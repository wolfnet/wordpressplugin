<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */
?>


	<div id="footer">
		<div id="centerfooter">
			<?php wp_nav_menu(array('theme_location' => 'footer','depth' => 1)); ?>
			<div id="footercredit"><p>Website Services by <a href="http://wolfnet.com" target="_blank">WolfNet Technologies</a> and <a href="http://brandco.com/" title="BrandCo" target="_blank">BrandCo</a></p></div>
		</div>
	</div>

	<?php wp_footer(); ?>

</body>
</html>
