Image Sizes:
	Custom Logo (png suggested): 
		232px x 63px
	Featured Image: 
		615px x 315px
	Slider Images: 
		630px x 255px
Instructions:
	For Uploading Areas:
		1. Click add new area
		2. Give it a title
		3. Give it a link url (when they click on the link, they will be taken to this page) (on the left sidebar under publish)
		3. Click publish
	For Uploading a New Slide:
		1. Click on new slide
		2. Add a title (Shows up on top of image)
		3. Add a link url (when user clicks on images, they will be taken to this url) (on the left sidebar under publish)
		4. Add a featured image (630px x 255px)
		5. Click publish
	Adding a Featured Image:
		on any page, add a featured image (can be seen in the sideabar at the bottom).
Getting Started:
	Go to the configuration page
		1. Put in the social icons you want
		2. Put in a link to your custom logo (PNG 232px x 63px)
		3. Fill out Location if you want the information to show up on the contact page
		4. Fill out the phone info if you want your phone information to show up in the header and the homepage
		5. Put a url under Map in order for the map image to show up. This link will take the user to that page when they click on the map image
