<?php

if ( function_exists('register_sidebar') ) {
	
	function create_sidebars($names) {
		$args = array('before_widget' => '<div id="%1$s" class="widget builtin %2$s">','after_widget' => '</div>','before_title' => '<h4 class="widgettitle">','after_title' => '</h4>');
		foreach ($names as $name) {
			if (!is_array($name))
				register_sidebar(array_merge($args,array('name'=>$name)));
			else
				register_sidebar(array_merge($args,$name));
		}

	}

	$sidebars = array(
		array('name' => 'Blog','id' => 'blog'),
		array('name' => 'Contact','id' => 'contact'),
		array('name' => 'Home','id' => 'home'),
		array('name' => 'Sellers','id' => 'sellers'),
		array('name' => 'Buyers','id' => 'buyers')
	);

	$sort = array();
	foreach ($sidebars as $sidebar)
		if (is_array($sidebar))
			$sort[] = $sidebar['name'];
		else
			$sort[] = $sidebar;
	array_multisort($sort,$sidebars);

	array_unshift($sidebars,array('name' => 'Default','id' => 'default'));

	create_sidebars($sidebars);

}

$widgets = array();

//$widgets[] = 'qconnect';
class qconnect extends WP_Widget {

	var $title = 'Quick Connect';

	function qconnect() {
		parent::__construct( false, $this->title );
	}

	function widget( $args, $instance ) {
		echo '<div id="qconnect" class="widget">';
			echo '<h4 class="widgettitle">Quick Connect</h4>';
			if (isset($_GET['success']))
				echo '<p>Thank you for contacting us!</p>';
			else {
				echo '<form method="post" action="">';
					echo '<input type="text" name="realistic" value="" />';
					echo '<input type="hidden" name="form_name" value="Quick Connect" />';
					if (isset($_GET['unable']) && $_GET['unable'] == 2)
						echo '<p>Unable to submit form. Please try again.</p>';
					echo '<ul>';
						echo '<li>';
							echo '<label for="qc_name">Full Name*</label>';
							echo '<input type="text" name="name" id="qc_name" class="required" />';
						echo '</li><li>';
							echo '<label for="qc_email">Email Address*</label>';
							echo '<input type="email" name="email" id="qc_email" class="required email" />';
						echo '</li><li>';
							echo '<label for="qc_comments">Comments</label>';
							echo '<textarea name="comments" id="qc_comments"></textarea>';
						echo '</li><li>';
							echo '<input type="submit" value="Submit &raquo;" />';
						echo '</li>';
					echo '</ul>';
					echo '<script type="text/javascript"> jQuery(function($) { $("#qconnect form").validate(); });</script>';
				echo '</form>';
			}
		echo '</div>';
	}
}

$widgets[] = 'latests';
class latests extends WP_Widget {

	var $title = 'Latest Blog Articles';

	function latests() {
		parent::__construct( false, $this->title );
	}

	function excerpt_length( $length ) {
		return 15;
	}

	function widget( $args, $instance ) {
		add_filter('excerpt_length',array(&$this,'excerpt_length'),999);

		$posts = new WP_Query('posts_per_page=5');
		echo '<div id="latests" class="widget">';
			echo '<h4 class="widgettitle">Our Blog</h4>';
			echo '<ul>';
				while ($posts->have_posts()) {
					$posts->the_post();
					echo '<li id="post-' . get_the_ID() . '">';
						echo '<h2><a href="' . get_permalink() . '">' . get_the_title() . '</a></h2>';
						echo '<div class="entry">';
							the_excerpt();
						echo '</div>';
					echo '</li>';
				}
			echo '</ul>';
		echo '</div>';

		remove_filter('excerpt_length',array(&$this,'excerpt_length'));

		wp_reset_query();
		wp_reset_postdata();
	}

}

$widgets[] = 'location';
class location extends WP_Widget {

	var $title = 'Office Information';

	function location() {
		$desc = get_site_config('address') . get_site_config('city',array(' ','')) . get_site_config('state',array(', ',' ')) . get_site_config('zip');
		parent::__construct( false, $this->title, array('description' => $desc ));
	}

	function widget( $args, $instance ) {
		echo '<div id="location" class="widget">';
			echo '<h4 class="widgettitle">Office Information</h4>';
			echo '<p>';
				site_config('address',array('','<br />'));
				site_config('city'); site_config('state',array(', ','')); site_config('zip');
			echo '</p><p>';
				site_config('main',array('<span>phone:</span> ','<br />'));
				site_config('fax',array('<span>fax:</span> ',''));
			echo '</p>';
		echo '</div>';
	}
}

//$widgets[] = 'testimonials';
class testimonials extends WP_Widget {

	var $title = 'Testimonials';

	function testimonials() {
		parent::__construct( false, $this->title );
	}

	function widget( $args, $instance ) {
		if (has_filter('the_content','st_add_widget'))
			remove_filter('the_content','st_add_widget');
		if (has_filter('get_the_excerpt','st_remove_st_add_link'))
			remove_filter('get_the_excerpt','st_remove_st_add_link',9);
		if (has_filter('the_excerpt','st_add_widget'))
			remove_filter('the_excerpt','st_add_widget');

		$testimonials = new WP_Query('post_type=testimonial&posts_per_page=1&orderby=rand');
		echo '<div id="testimonials" class="widget">';
			echo '<h4 class="widgettitle">Client Testimonial</h4>';
			while ($testimonials->have_posts()) {
				$testimonials->the_post();
				echo '<div class="entry">';
					the_content();
					echo '<p class="byline">&#151; ' . get_the_title() . '</p>';
				echo '</div>';
			}
		echo '</div>';

		if (function_exists('st_add_widget')) {
			add_filter('the_content','st_add_widget');
			add_filter('get_the_excerpt','st_remove_st_add_link',9);
			add_filter('the_excerpt','st_add_widget');
		}

		wp_reset_query();
		wp_reset_postdata();
	}
}

$widgets[] = 'googlemap';
class googlemap extends WP_Widget {

	var $title = 'Map';

	function googlemap() {
		parent::__construct( false, $this->title );
	}

	function widget( $args, $instance ) {
		echo '<div id="googlemap" class="widget">';
			echo '<h4 class="widgettitle">Map Search</h4>';
			if (get_site_config('mapsearchimageurl') != '') {
				// site_config('mapsearchurl',array('<div id="mapsearch"><a href="','"></a></div>'));
				echo '<div id="mapsearchcustom">';

					list($maxw,$maxh) = array(292,161);
					$img = get_site_config('mapsearchimageurl');
					$dims = getimagesize($img);
					list($w,$h) = $dims;
					$aspect = $w / $h;
					if ($w > $maxw) {
						$w = $maxw;
						$h = $w / $aspect;
					}
					if ($h < $maxh) {
						$h = $maxh;
						$w = $h * $aspect;
					}

					$w = round($w);
					$h = round($h);

					echo '<div style="width: ' . $maxw . 'px; height: ' . $maxh . 'px; overflow: hidden;"><img src="' . $img . '" alt="" style="width: ' . $w . 'px; height: ' . $h . 'px;" /></div>';
					echo '<a href="' . get_site_config('mapsearchurl') . '"></a>';
				echo '</div>';
				// site_config('mapsearchurl',array('<a href="','"><div id="mapsearch"><img src="' . get_bloginfo('stylesheet_directory') . '/images/map.png" alt="Map Search"></div></a>'));
			}
			else {
				site_config('mapsearchurl',array('<a href="','"><div id="mapsearch"><img src="' . get_bloginfo('stylesheet_directory') . '/images/map.png" alt="Map Search"></div></a>'));
			}
			
			// site_config('mapsearchurl',array('<a href="','"><div id="mapsearch"><img src="' . get_bloginfo('stylesheet_directory') . '/images/map.png" alt="Map Search"></div></a>'));

			//echo wp_oembed_get(get_post_meta(get_the_ID(),'_video_embed',true),array('width' => 215));
			//echo '<iframe width="215" height="120" src="' . get_post_meta(get_the_ID(),'_video_embed',true) . '" frameborder="0" allowfullscreen></iframe>';
			//echo '<?php site_config('mapsearchurl',array('<a href="','"><div id="mapsearch"><img src="' . get_bloginfo('stylesheet_directory') . '/images/map.png" alt="Map Search"></div></a>'))
			//site_config('mapsearchurl',array('<a href="','"><div id="mapsearch"><img src="' . get_bloginfo('stylesheet_directory') . '/images/map.png" alt="Map Search"></div></a>'));
			// site_config('mapsearchurl',array('<a href="','"><div id="mapsearch"><img src="' . $themapurl . '" alt="Map Search"></div></a>'));
			// 
			// echo '<a href="';
			// site_config('mapsearchurl');
			// echo '"><div id="mapsearch"><img src="';
			// site_config('mapurl');
			// echo '" alt="Map Search"></div></a>';
			//echo '<p style="margin-top: 5px; text-align: right;"><a href="' . $instance['link'] . '" target="_blank">More Videos &raquo;</a></p>';
		echo '</div>';
	}

	// function update( $new_instance, $old_instance ) {
	// 	$instance = $old_instance;
	// 	$instance['link'] = $new_instance['link'];

	// 	return $instance;
	// }

	// function form( $instance ) {
	// 	if ($instance)
	// 		$link = esc_attr($instance['link']);
	// 	else
	// 		$link = '#';

	// 	echo '<strong>"More Videos" Link</strong><br /><textarea name="' . $this->get_field_name('link') . '" style="width: 100%;">' . $link . '</textarea><br /><br />';
	// }
}

$widgets[] = 'searchbyarea';
class searchbyarea extends WP_Widget {

	var $title = 'Search By Area';

	function searchbyarea() {
		parent::__construct( false, $this->title );
	}

	function widget( $args, $instance ) {
		echo '<div id="searchbyareawidget" class="widget">';
			echo '<h4 class="widgettitle">Search By Area</h4>';
			echo '<ul>';
				// The Query
				$the_query_area = new WP_Query( 'post_type=city&orderby=title&order=asc&posts_per_page=15' );
				// The Loop
				while ( $the_query_area->have_posts() ) :
					$the_query_area->the_post();
					echo '<li>';
					echo '<a href="';
					echo the_permalink();
					echo '">';
					echo get_the_title();
					echo '</a>';
					echo '</li>';
				endwhile;
				// Restore original Query & Post Data
				wp_reset_query();
				wp_reset_postdata();
			echo '</ul>';
		echo '</div>';
	}
}

//$widgets[] = 'button';
class button extends WP_Widget {

	var $title = 'Button';

	var $data = array(
		'text' => array(
			'default' => "Button Text\r\nSecond Line",
			'label' => 'Text',
			'type' => 'textarea'
		),
		'link' => array(
			'default' => "#",
			'label' => 'Link',
		)
	);

	function button() {
		parent::__construct( false, $this->title );
	}

	function widget( $args, $instance ) {
		echo '<a class="widget button" href="' . $instance['link'] . '">' . wpautop(stripslashes($instance['text'])) . '</a>';
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		if (is_array($this->data) && count($this->data))
			foreach ($this->data as $key => $na)
				$instance[$key] = $new_instance[$key];

		return $instance;
	}

	function form( $instance ) {
		if (is_array($this->data) && count($this->data))
			foreach ($this->data as $key => $array) {
				if ($instance)
					$val = esc_attr($instance[$key]);
				else
					$val = $array['default'];

				$label = ucfirst($key);
				if (array_key_exists('label',$array))
					$label = $array['label'];

				echo '<strong>' . $label . '</strong><br />';
				if ($array['type'] == 'textarea')
					echo '<textarea name="' . $this->get_field_name($key) . '" style="width: 100%;">' . $val . '</textarea><br /><br />';
				else
					echo '<input type="text" name="' . $this->get_field_name($key) . '" value="' . $val . '" style="width: 100%;" /><br /><br />';
			}
	}
}




//$widgets[] = 'skeleton';
class skeleton extends WP_Widget {

	var $title = '';

	/* var $data = array(
		'field_id' => array(
			'default' => 'DEFAULT VALUE\r\nSECOND LINE',
			'label' => 'FIELD LABEL',
			'type' => 'TEXTAREA || TEXT'
		)
	); */

	function skeleton() {
		parent::__construct( false, $this->title );
	}

	function widget( $args, $instance ) {
		echo '<div id="" class="widget">';
			echo '<h4 class="widgettitle"></h4>';
		echo '</div>';
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		if (is_array($this->data) && count($this->data))
			foreach ($this->data as $key => $na)
				$instance[$key] = $new_instance[$key];

		return $instance;
	}

	function form( $instance ) {
		if (is_array($this->data) && count($this->data))
			foreach ($this->data as $key => $array) {
				if ($instance)
					$val = esc_attr($instance[$key]);
				else
					$val = $array['default'];

				$label = ucfirst($key);
				if (array_key_exists('label',$array))
					$label = $array['label'];

				echo '<strong>' . $label . '</strong><br />';
				$type = 'text';
				if (isset($array['type']))
					$type = ($array['type'] == '' ? 'text' : $array['type']);

				if ($type == 'textarea')
					echo '<textarea name="' . $this->get_field_name($key) . '" style="width: 100%;">' . $val . '</textarea><br /><br />';
				else
					echo '<input type="' . $type . '" name="' . $this->get_field_name($key) . '" value="' . $val . '" style="width: 100%;" /><br /><br />';
			}
	}
}




sort($widgets);
add_action('widgets_init','register_widgets');
function register_widgets() {
	global $widgets;
	if (!is_array($widgets) || !count($widgets))
		return;
	foreach ($widgets as $widget)
		register_widget($widget);
}

?>
