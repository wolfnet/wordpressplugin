<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */
?>



	<div id="sidebar" role="complementary">
	</div>
