<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */


add_theme_support('post-thumbnails');

if ( function_exists( 'register_nav_menu' ) ) {
	register_nav_menu('primary','Primary Navigation');
	register_nav_menu('footer','Footer Navigation');
}

require_once('slide/setup_slide.php');

require_once('functions_config.php');
require_once('functions_widgets.php');

$is_login = (strpos($_SERVER['PHP_SELF'],'wp-login.php') ? true : false);

if (is_admin() || $is_login)
	require_once('functions_admin.php');
else if (!$is_login)
	require_once('functions_public.php');

/* Adding Page Image Size */
add_image_size( 'featuredimage', 630, 255, false );
add_image_size( 'slideimage', 650, 325, false );


// /**
//  * Add Areas Custom Post Type
//  */
// function create_post_type() {
// 	register_post_type( 'Areas',
// 		array(
// 			'labels' => array(
// 				'name' => __( 'Areas' ),
// 				'singular_name' => __( 'Area' ),
// 				'add_new' => _x( 'Add New', 'area' ),
// 		        'add_new_item' => __( 'Add New Area' ),
// 		        'edit_item' => __( 'Edit Area' ),
// 		        'new_item' => __( 'New Area' ),
// 		        'all_items' => __( 'All Areas' ),
// 		        'view_item' => __( 'View Area' ),
// 		        'search_items' => __( 'Search Areas' ),
// 		        'not_found' => __( 'No Areas found' ),
// 		        'not_found_in_trash' => __( 'No Areas found in the Trash' ),
// 		        'parent_item_colon' => '',
//         		'menu_name' => 'Areas'
// 			),
// 			'public' => true,
// 			'has_archive' => true,
// 			'rewrite' => array('slug' => 'area'),
// 			'supports' => array( 'title', 'editor' ),
// 			'description' => 'Search by Area',
// 		)
// 	);
// }
// add_action( 'init', 'create_post_type' );

// *
//  * Add Slider Custom Post Type
 
// function create_post_type2() {
// 	register_post_type( 'Slider',
// 		array(
// 			'labels' => array(
// 				'name' => __( 'Slider' ),
// 				'singular_name' => __( 'Slider' ),
// 				'add_new' => _x( 'Add New', 'slide' ),
// 		        'add_new_item' => __( 'Add New Slide' ),
// 		        'edit_item' => __( 'Edit Slide' ),
// 		        'new_item' => __( 'New Slide' ),
// 		        'all_items' => __( 'All Slides' ),
// 		        'view_item' => __( 'View Slide' ),
// 		        'search_items' => __( 'Search Slidesd' ),
// 		        'not_found' => __( 'No Slides found' ),
// 		        'not_found_in_trash' => __( 'No Slides found in the Trash' ),
// 		        'parent_item_colon' => '',
//         		'menu_name' => 'Slider'
// 			),
// 			'public' => true,
// 			'has_archive' => true,
// 			'rewrite' => array('slug' => 'slider'),
// 			'supports' => array( 'title', 'editor' ),
// 			'description' => 'Search by Slider',
// 		)
// 	);
// }
// add_action( 'init', 'create_post_type2' );

?>
