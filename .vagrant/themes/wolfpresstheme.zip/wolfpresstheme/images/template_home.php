<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */

// wp_enqueue_style('home',get_bloginfo('template_url') . '/inc/home.css',array('site','orbit'));
// wp_enqueue_style('orbit',get_bloginfo('template_url') . '/inc/orbit.css',array('site'));
// wp_enqueue_script('orbit',get_bloginfo('template_url') . '/inc/orbit.js',array('site','jquery'));

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head profile="http://gmpg.org/xfn/11">
	
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	
	<title><?php wp_title(''); ?></title>

	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	
	<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>

	<?php wp_enqueue_style('site',get_bloginfo('stylesheet_url'),array('orbit')) ?>
		
	<?php wp_enqueue_script('jquery') ?>
	<?php wp_enqueue_script('jquery-color') ?>
	<?php wp_enqueue_script('validate',get_bloginfo('template_directory') . '/inc/validate.js',array('jquery'),'1.0') ?>
	<?php wp_enqueue_script('site',get_bloginfo('template_directory') . '/inc/scripts.js',array('jquery','jquery-color','validate'),'1.0') ?>
	<?php wp_enqueue_style('home',get_bloginfo('template_url') . '/inc/home.css',array('site','orbit')) ?>
	<?php wp_enqueue_style('orbit',get_bloginfo('template_url') . '/inc/foundation.min.css') ?>
	<?php wp_enqueue_script('orbit',get_bloginfo('template_url') . '/inc/foundation.min.js',array('jquery')) ?>

	
	<?php wp_head(); ?>
	
</head>
<body <?php body_class(); ?>>

<div id="header">
<div id="centerheader">
	<ul id="social">
		<?php site_config('fb',array('<li class="fb"><a href="','" target="_blank"><img src="wp-content/themes/wolfpresstheme/images/fb.jpg" alt="Facebook" width="30" height="27"></a></li>')) ?>
		<?php site_config('tw',array('<li class="tw"><a href="','" target="_blank"><img src="wp-content/themes/wolfpresstheme/images/tw.jpg" alt="Twitter" width="31" height="27"></a></li>')) ?>
		<?php site_config('in',array('<li class="in"><a href="','" target="_blank"><img src="wp-content/themes/wolfpresstheme/images/in.jpg" alt="LinkedIn" width="30" height="27"></a></li>')) ?>
		<?php site_config('yt',array('<li class="yt"><a href="','" target="_blank"><img src="wp-content/themes/wolfpresstheme/images/yt.jpg" alt="YouTube" width="31" height="27"></a></li>')) ?>
		<?php site_config('rss',array('<li class="rss"><a href="','" target="_blank"><img src="wp-content/themes/wolfpresstheme/images/rss.jpg" alt="RSS" width="30" height="27"></a></li>')) ?>
	</ul>
	<div id="callustoday"><?php site_config('main',array('Call Us Today: <div id="callustodaynumber">','</div>')) ?></div>
	<div id="logo">
		<?php site_config('customlogourl',array('<a href="davidparsons.me"><img src="','" alt="logo"></a>')) ?>
	</div>
	<div id="nav">
		<?php wp_nav_menu(array('theme_location' => 'primary','depth' => 1)); ?>
	</div>
	
	<div id="featuredimages">
	<div id="featuredimagesslides">
		<div id="featured">
			<?php
			// The Query
			$the_query = new WP_Query( 'post_type=slide' );
			// The Loop
			while ( $the_query->have_posts() ) :
				//if (has_post_thumbnail()) {
					$the_query->the_post();
					echo '<a href="' . esc_attr( get_post_meta( the_ID(), '_linkurl',true) ) . '">';
					echo '<div class="slidecontent">';
					//echo '<img src="' . get_the_post_thumbnail( the_ID(), 'thumbnail','src' ) . '" alt="slide image">';
					//get_the_post_thumbnail();
					the_post_thumbnail('featuredimage');
					echo '<span class="orbit-caption" id="htmlCaption"><div class="slidertext">' . get_the_title() . '</div></span>';
					echo '</div>'; 
					echo '</a>';
				//}
			endwhile;
			// Restore original Query & Post Data
			wp_reset_query();
			wp_reset_postdata();
			?>
		</div>

		<!-- <img src="http://localhost/wp-content/themes/wolfpresstheme/images/slide4.png" alt="slide1"> -->
<!-- 	    <div id="featured">
	    	<a href="...">
		    	<div class="slidecontent">
					<img src="http://localhost/wp-content/themes/wolfpresstheme/images/slide1.png" alt="slide image">
 -->					<!-- <div class="slidecontentpic">
						<h1>Orbit does content now.</h1>
						<h3>Highlight me...I'm CSS3 font-face text.</h3>
					</div> -->
<!-- 					<span class="orbit-caption" id="htmlCaption">...</span>
				</div>
			</a>
			<div class="slidecontent">
				<img src="http://localhost/wp-content/themes/wolfpresstheme/images/slide1.png" alt="slide image">
 -->				<!-- <div class="slidecontentpic">
					<h1>Orbit does content now.</h1>
					<h3>Highlight me...I'm CSS3 font-face text.</h3>
				</div> -->
<!-- 			</div>
	        <img src="http://localhost/wp-content/themes/wolfpresstheme/images/slide1.png" alt="slide image">
	        <img src="http://localhost/wp-content/themes/wolfpresstheme/images/slide1.png" alt="slide image">
 -->	        <!-- <img src="http://localhost/wp-content/themes/wolfpresstheme/images/slide4.png" alt="slide image"> -->
	        <!-- <img src="holder.js/1200x250/text:Slide_2" alt="slide image"> -->
	        <!-- <img src="holder.js/1200x250/text:Slide_3" alt="slide image"> -->
	    	<!-- <span class="orbit-caption" id="htmlCaption">I'm A Badass Caption</span> -->
	    <!-- </div> -->
	    <!-- Captions for Orbit -->
	</div> 
	</div>

</div>
</div>

<script type="text/javascript">
     $(window).load(function() {
         $('#featured').orbit({
              bullets: true,
              directionalNav: false,
              // startClockOnMouseOut: true,
              captions: true
         });
     });
</script>


<div id="subheader"></div>

<div id="torso">
	<div id="centertorso">
		<div id="contenthome">

			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

				<div <?php post_class() ?> id="post-<?php the_ID(); ?>">
					<!-- <h1 class="pagetitle"><?php the_title() ?></h1> -->
					<div class="entry">
						<?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?>
						<?php edit_post_link('Edit this entry.', '<p>', '</p>'); ?>
					</div>
				</div>

			<?php endwhile; endif; ?>

		</div>

		<div id="sidebarhome">
			<h1>Map Search</h1>
			<!-- <div id="mapsearch"><img src="http://localhost/wp-content/themes/wolfpresstheme/images/map.png" alt="Map Search"></div> -->
			<?php site_config('mapsearchurl',array('<a href="','"><div id="mapsearch"><img src="http://localhost/wp-content/themes/wolfpresstheme/images/map.png" alt="Map Search"></div></a>')) ?>
		</div>

		<div class="hrhome"></div>

		<div id="blogfeaturehome">
			<div id="newspic"><img src="http://localhost/wp-content/themes/wolfpresstheme/images/news.png" alt="latest blog posts"></div>
			<div id="fromtheblog">
				<h1>Latest from The Blog</h1>
				<ul><?php wp_get_archives( array( 'type' => 'postbypost', 'limit' => 4 ) ); ?></ul>
			</div>
		</div>
		<div id="searchbyareahome">
			<div id="searchpic"><img src="http://localhost/wp-content/themes/wolfpresstheme/images/magglass.png" alt="search by area"></div>
			<h1>Search by Area</h1>
			<ul>
				<?php
					$args = array( 'post_type' => 'Areas', 'posts_per_page' => 50 );
					$loop = new WP_Query( $args );
					while ( $loop->have_posts() ) : 
						$loop->the_post();
						//$cityname->the_title();
						//$permalink = get_permalink( $id );
						echo '<li>';
						echo '<a href="' . esc_url( get_permalink( get_page_by_title( get_the_title() ) ) ) . '">';
						the_title();
						echo '</a>';
						echo '</li>';
					endwhile;
				?>
			</ul>
		</div>

	</div>
</div>	

<?php get_footer(); ?>
