<?php

if (0 && current_user_can('manage_network')) {
	if (mail('caleb@brandco.com','Testing WolfnetWP mail',"Testing it out","From: mail@wolfnetwp.com"))
		echo 'mail() successful';
	if (wp_mail('caleb@brandco.com','Testing WolfnetWP wp_mail',"Testing it out","From: wp_mail@wolfnetwp.com"))
		echo 'wp_mail() successful';
}

add_editor_style();

// add_action('login_enqueue_scripts','login_includes');
// function login_includes() {
// 	echo "<link rel='stylesheet' id='custom-admin-css'  href='" . get_bloginfo('template_url') . "/inc/login.css' type='text/css' media='all' />";
// }

add_action('admin_enqueue_scripts','admin_includes');
function admin_includes() {
	//wp_enqueue_style('fonts','');
	wp_enqueue_style('custom-admin',get_bloginfo('template_url') . '/inc/admin.css');
}

add_action('add_meta_boxes','cpmbs');
function cpmbs() {
	global $post;

	if ($post->post_parent > 0) {
		$parent = $post->post_parent;
		$type = get_post_type_object(get_post_type($parent));
		$title = '<a href="' . get_edit_post_link($parent) . '" title="Edit \'' . get_the_title($parent) . '\'">&larr; Edit ' . apply_filters('parents_this_type',$type->labels->singular_name) . '\'s Parent</a>';
		add_meta_box('edit_parent',$title,'cpmb_edit_parent','','side');
	}

}

function cpmb_edit_parent() {
	return;
}

function video_url() {
	global $post;
	$video = get_post_meta($post->ID,'_video',true);

	if (isset($video) && !empty($video))
		echo '<div style="margin: 10px 0;">' . wp_oembed_get($video,array('width' => 257)) . '</div>';

	echo '<input type="hidden" name="page_video_url_noncename" id="page_video_url_noncename" value="' . wp_create_nonce( __FILE__ ) . '" />';
	echo 'URL: <input type="text" name="video_url" class="code" value="' . $video . '" style="width: 200px;" />';
}

	add_action('save_post','save_video_url');
	function save_video_url($post_id) {
		if (!is_admin())
			return;
		
		if ( !array_key_exists('page_video_url_noncename',$_POST) || !wp_verify_nonce( $_POST['page_video_url_noncename'], __FILE__ ))
			return $post_id;
		
		if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE )
			return $post_id;
			
		if (get_post_type($post_id) == 'post' && !current_user_can('edit_post',$post_id))
			return $post_id;

		if (get_post_type($post_id) == 'page' && !current_user_can('edit_page',$post_id))
			return $post_id;

		update_post_meta($post_id,'_video',$_POST['video_url']);
	}



add_action('admin_notices','warn_deleting_idx_template');
function warn_deleting_idx_template() {
	global $post;
	
	if (!isset($post->page_template) || $post->page_template != 'template_idx.php')
		return;

	echo '<div class="error">
       <p style="line-height: 20px;"><span style="font-size: 18px;">DO NOT DELETE THIS PAGE: BAD THINGS <EM>WILL</EM> HAPPEN!</span><br />Your IDX uses this page as reference for the header and footer: deleting this page will break your search and property pages.<br />Also, editing this page will not change anything on your site; best to just leave it alone.</p>
    </div>';
}

add_filter('admin_footer_text','admin_footer_text',11);
function admin_footer_text($content) {
	$search = 'WordPress</a>';
	$len = strpos($content,$search) + strlen($search);
	return substr($content,0,$len) . ' and choosing <a href="http://www.wolfnet.com" target="_blank">Wolfnet</a> and <a href="http://www.brandco.com" target="_blank">BrandCo</a>' . substr($content,$len);
}

?>
