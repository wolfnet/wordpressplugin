<?php

add_shortcode('hr',create_function('','return "<hr />";'));

add_shortcode('antispam','bco_antispam');
function bco_antispam($atts,$content = '') {	
	return antispam($content);
}

/*add_shortcode('contactform','contactform');
function contactform() {
	$output = '';
	
	if ($_GET['success'])
		return 'Thank you for contacting us! We will respond soon.';
	else if ($_GET['unable'])
		$output .= '<h3 style="margin-bottom: 10px;">Unable to send contact information. Please try again.</h3>';
		
	$output .= '<form id="contact_form" method="post" action="">';
		$output .= '<input type="text" name="realistic" value="" />';
		$output .= '<input type="hidden" name="formname" value="contactform" />';
		$output .= '<ul><li>';
			$output .= '<label for="contact_fname">First Name*</label>';
			$output .= '<input type="text" name="fname" id="contact_fname" tabindex="1" class="required" />';
		$output .= '</li><li>';
			$output .= '<label for="contact_lname">Last Name</label>';
			$output .= '<input type="text" name="lname" id="contact_lname" tabindex="2" />';
		$output .= '</li><li>';
			$output .= '<label for="contact_phone">Phone</label>';
			$output .= '<input type="text" name="phone" id="contact_phone" tabindex="3" />';
		$output .= '</li><li>';
			$output .= '<label for="contact_email">Email Address*</label>';
			$output .= '<input type="email" name="email" id="contact_email" tabindex="4" class="required email" />';
		$output .= '</li><li>';
			$output .= '<label for="contact_comments">Comments or Questions</label>';
			$output .= '<textarea name="comments" id="contact_comments" tabindex="5"></textarea>';
		$output .= '</li><li>';
			$output .= '<input type="submit" name="contact_form" value="Submit" tabindex="6" />';
		$output .= '</li></ul>';
	$output .= '</form>';
	
	$output .= '<script type="text/javascript"> jQuery(function($) { $("#contact_form").validate(); });</script>';
	
	return $output;
}*/

?>
