<?php

$bco_config_opt = 'bco_config';
$bco_config = new bco_config();
$bco_config->init();

class bco_config {

	var $cap = 'edit_others_posts';
    var $opt = 'bco_config';
	var $dev = false;

	var $last_group = '';

	var $created = '';
	var $saved = '';
    var $defaults = '';
    var $types = array();
	var $medias = array();

	var $temp = '';

	function init() {

        $this->defaults = array(
			'switch' => false,
			'class' => '',
			'type' => 'text',
			'around' => array('',''),
			'readonly' => false,
            'default' => '',
			'desc' => '',
			'image_size' => 'full',
			'switch_display' => false
		);

		$this->created = new stdClass();
		$this->saved = get_option($this->opt);
        $this->types = get_post_types(array('hierarchical' => 1));

		add_action('admin_bar_menu',array(&$this,'admin_bar'),50);

		$this->create();

		if (is_admin())
			$this->admin_hooks();

		if (!wp_cache_get($this->opt))
			wp_cache_add($this->opt,$this);

	}

		function create() {

			do_action('bco_config_fields',$this);

			$this->vals();

		}

		function vals() {

            if (is_array($this->saved))
    			foreach ($this->saved as $group => $fields)
    				if (isset($this->created->$group) && isset($this->created->$group->fields) && is_array($fields) && count($fields))
    					foreach ($fields as $field => $val) {
							if (!array_key_exists($field,$this->created->$group->fields))
								continue;
    						if (is_array($val) && count($val)) {
                                if (array_key_exists('val',$val))
                                    $this->created->$group->fields[$field]->value = $val['val'];
								if (array_key_exists('on',$val))
									$this->created->$group->fields[$field]->on = $val['on'];
								if (array_key_exists('custom',$val))
									$this->created->$group->fields[$field]->custom = $val['custom'];
                            } else
    							$this->created->$group->fields[$field]->value = $val;
                        }
		}

		function admin_hooks() {
			add_action('admin_menu',array(&$this,'admin_menu'));
			add_action('admin_notices',array(&$this,'notices'));
			if (isset($_GET['page']) && $_GET['page'] == $this->opt && isset($_POST) && is_array($_POST) && count($_POST))
				add_action('admin_init',array(&$this,'submit'));
		}

			function admin_menu() {
				$menu = add_submenu_page('themes.php','Agent Info','Agent Info',$this->cap,'bco_config',array(&$this,'main'),'',3);
				//add_action('admin_head-'.$menu,array(&$this,'create'));
				add_action('admin_init',array(&$this,'add_media_setup'));
				add_action('admin_head-'.$menu,array(&$this,'plugin_head'));
			}

				function add_media_setup() {
					global $pagenow;  
  
					if ('media-upload.php' == $pagenow || 'async-upload.php' == $pagenow)
						add_filter('gettext',array(&$this,'replace_thickbox_text'),1,3);
				}

					function replace_thickbox_text($translated_text,$text,$domain) {
						if ('Insert into Post' == $text) {
							$referer = strpos(wp_get_referer(),'bco_config'); 
							if ($referer != '')
								return __('Insert media link into configuration');
						}  
						return $translated_text;  
					} 

				function plugin_head() {
                    wp_enqueue_script('masonry',get_bloginfo('template_url') . '/inc/masonry.js',array('jquery'));
					wp_enqueue_script('config',get_bloginfo('template_url') . '/inc/config.js',array('jquery'));
					wp_enqueue_style('config',get_bloginfo('template_url') . '/inc/config.css');
					wp_enqueue_script('thickbox');
					wp_enqueue_style('thickbox');
					wp_enqueue_script('media-upload');

					$current_user = wp_get_current_user();
					if (class_exists('wpdev')) {
						$wpdev = new wpdev();
						if ($wpdev->check_user())
							$this->dev = true;
					}
				}

			function admin_bar() {
				if (is_admin())
					return;
				global $wp_admin_bar;
				$wp_admin_bar->add_node(array('id' => 'site-config','title' => 'Configuration','href' => admin_url('themes.php?page=bco_config'),'parent' => 'site-name'));
			}

			function notices() {
                if (isset($_GET['updated']))
                    echo '<div class="updated"><p>Configuration settings updated.</p></div>';
                else if (isset($_GET['unable']))
                    echo '<div class="error"><p>Unable to update settings. Please try again.</p></div>';
        		else if (isset($_GET['defaulted']))
        			echo '<div class="updated"><p>Configuration settings set to default values.</p></div>';
        		else if (isset($_GET['undefaulted']))
        			echo '<div class="error"><p>Unable to set configuration settings to default values. <span style="font-size: 10px; font-style: italic;">Most likely this means values were already defaulted.</span></p></div>';

        		return;
			}

	function main() {

		echo '<div class="wrap">';

			echo '<div id="icon-options-general" class="icon32"><br></div>';
			echo '<h2>Configuration</h2>';

			echo '<form method="post" action="">';

				echo '<div class="masonry' . ($this->dev ? ' bco_dev' : '') . '">';

					$i = 1;

					foreach ($this->created as $name => $group) {

						if (!isset($group->fields) || isset($group->parent))
							if (!isset($group->childs))
								continue;

						$checked = 0;
						$group_name = $name;

						if (isset($group->fields) && is_array($group->fields) && count($group->fields))
							foreach ($group->fields as $name => $field)
								if (isset($field->on))
									$checked++;

						echo '<div id="config-' . $group_name . '" class="box config-group">';

							echo '<input type="submit" value="Save" class="button-primary" />';
							echo '<h3>' . $group->settings['label'] . '</h3>';

							if (isset($group->fields) && count($group->fields)) {

								echo '<ul>';

									if (array_key_exists('switch',$group->settings) && $group->settings['switch'])
										echo '<li class="check-all"><input type="checkbox" id="config-' . $group_name . '-checkboxes-all"' . checked($checked,count($group->fields),false) . ' /> <label for="config-' . $group_name . '-checkboxes-all">Check All</label></li>';

									foreach ($group->fields as $name => $field)
										$this->display_field($name,$field,$group_name);

								echo '</ul>';

							}

							if (isset($group->childs) && is_array($group->childs) && count($group->childs)) {

								foreach ($group->childs as $child) {
									$child_name = $child;
									$child = $this->created->$child;

									echo '<div id="config-' . $name . '" class="config-group">';

										echo '<h4>' . $child->settings['label'] . '</h4>';
											
										echo '<ul>';

											foreach ($child->fields as $name => $field)
												$this->display_field($name,$field,$child_name);

										echo '</ul>';

									echo '</div>';
								}

							}

						echo '</div>';
					}

					//echo '<pre>' . print_r($this->saved,true) . '</pre><br /><br />';
					//echo '<pre>' . print_r($this->created,true) . '</pre>';

					echo '<div class="box submit-box">';
						echo '<input type="submit" value="Save" class="button-primary" />&nbsp;&nbsp;&nbsp;';
						echo '<input type="reset" value="Reset" class="button" />';
						if ($this->dev)
							echo '&nbsp;&nbsp;&nbsp;<input type="submit" name="default" value="Delete Saved Settings" class="button bco_dev" />';
					echo '</div>';

                    if ($this->dev) {
						echo '<div class="box bco_dev" style="width: 670px; min-width: 270px;">';
							echo '<h3>print_r($' . $this->opt . '->created)</h3>';
							echo '<textarea wrap="off" style="width: 100%; height: 400px;" class="code" readonly="readonly">' . print_r($this->created,true) . '</textarea>';
						echo '</div>';

						echo '<div class="box bco_dev">';
							echo '<h3>print_r($' . $this->opt . '->saved)</h3>';
							echo '<textarea wrap="off" style="width: 100%; height: 300px;" class="code" readonly="readonly">' . (!empty($this->saved) ? print_r($this->saved,true) : 'DEFAULTS : NO SAVED SETTINGS') . '</textarea>';
						echo '</div>';
					}

					echo '<br style="clear: both;" />';

				echo '</div>';

				echo '<br style="clear: both;" />';

			echo '</div>';

			echo '<br style="clear: both;" />';

		echo '</div>';

		echo '<br style="clear: both;" />';

	}

		function display_field($name,$field,$group) {
            extract($this->parse_args($field->settings,$group));

			$id = $group . '-' . $name;

			echo '<li' . ($switch ? ' class="switch"' : '') . '>';

				if ($switch)
					echo '<input type="checkbox" id="' . $id . '_switch" name="' . $this->opt . '[' . $group . '][' . $name . '][on]" value="1"' . checked(isset($field->on),1,false) . ' /> ';

				echo '<label for="' . $id . ($switch ? '_switch' : '') . '"' . ($type == 'textarea' ? ' style="vertical-align: top;"' : '') . '>' . $label . '</label>';

                if (in_array($type,$this->types)) {
                    if (is_post_type_hierarchical($type)) {
						$args = array(
							'name' => $this->opt . '[' . $group . '][' . $name . '][val]',
							'show_option_none' => ' ',
							'selected' => (isset($field->value) ? stripslashes($field->value) : $default),
							'post_type' => $field->settings['type']
						);
						$this->temp = array('post_type' => $field->settings['type'],'selected' => $args['selected']);
						add_filter('wp_dropdown_pages',array(&$this,'add_custom_url_option'));
						wp_dropdown_pages($args);
						remove_filter('wp_dropdown_pages',array(&$this,'add_custom_url_option'));
					} else {
						$query = new WP_Query('post_type='.$type.'&posts_per_page=50&orderby=title&order=asc');
						if (!$query->have_posts())
							return;
						echo '<select ' . 
							'name="' . $this->opt . '[' . $group . '][' . $name . '][val]" ' . 
							'id="' . $group . '-' . $name . '" ' . 
							'>';
							while ($query->have_posts()) {
								$query->the_post();
								echo '<option value="' . get_the_ID() . '">' . get_the_title() . '</option>';
							}
						echo '</select>';

					}
					$value = $custom = '';
					if (isset($field->value)) $value = $field->value;
					if (isset($field->custom)) $custom = $field->custom;
					echo '<div class="link-custom-url"' . ($value == 'link-custom-url' ? ' style="display: block;"' : '') . '>';
						echo '<input ' . 
							'id="' . $id . '-custom-url" ' . 
							'type="text" ' . 
							'name="' . $this->opt . '[' . $group . '][' . $name . '][custom]" ' . 
							'class="' . (!empty($class) ? $class : '' ) . ' code" ' . 
							'value="' . ($custom != '' ? stripslashes($custom) : 'http://') . '" ' . 
							' />';
					echo '</div>';
				} else if ($type == 'media') {
					echo '<input ' . 
    					'id="' . $id . '" ' . 
    					'type="hidden" ' . 
    					'name="' . $this->opt . '[' . $group . '][' . $name . ']' . ($switch ? '[val]' : '') . '" ' . 
    					(!empty($class) ? ' class="' . $class . ' short code"' : '' ) . ' class="short code"' . 
    					($readonly ? ' readonly="readonly"' : '') . ' ' . 
    					'value="' . (isset($field->value) ? stripslashes($field->value) : $default) . '" ' . 
    					' />';
					echo '<input ' . 
						'type="button" ' . 
						'class="button add-media" ' . 
						'value="Add Media" ' . 
						'rel="' . $id . '" ' . 
						' />';
					if (isset($field->value)) {
						$img_id = $field->value;
						if (is_numeric($field->value)) {
							$full = wp_get_attachment_image_src($img_id,'full');
							$full = $full[0];
						} else
							$full = $field->value;
						echo '<a href="' . $full . '" class="media-url thickbox" title="' . $full . '">View media</a> <a href="#" class="delete-media-url">Delete media</a>';
					}
				} else if ($type == 'textarea') {
					echo '<textarea ' . 
    					'id="' . $id . '" ' . 
    					'type="' . $type . '" ' . 
    					'name="' . $this->opt . '[' . $group . '][' . $name . ']' . ($switch ? '[val]' : '') . '" ' . 
    					(!empty($class) ? ' class="' . $class . '"' : '' ) . ' ' . 
    					($readonly ? ' readonly="readonly"' : '') . '>' . 
							(isset($field->value) ? stripslashes($field->value) : $default) . 
    					'</textarea>';
                } else
    				echo '<input ' . 
    					'id="' . $id . '" ' . 
    					'type="' . $type . '" ' . 
    					'name="' . $this->opt . '[' . $group . '][' . $name . ']' . ($switch ? '[val]' : '') . '" ' . 
    					(!empty($class) ? ' class="' . $class . '"' : '' ) . ' ' . 
    					($readonly ? ' readonly="readonly"' : '') . ' ' . 
    					'value="' . (isset($field->value) ? stripslashes($field->value) : $default) . '" ' . 
    					' />';

				if (!empty($desc))
					echo '<div class="desc">' . stripslashes($desc) . '</div>';

			echo '</li>';

			foreach (array_keys($field->settings) as $key)
				unset($key);

			unset($id);
		}

			function add_custom_url_option($output) {
				$pt = get_post_type_object($this->temp['post_type']);
				$output = str_replace('<option value=""> </option>','<option value=""> </option>'."\n\t".'<option value="link-custom-url"' . selected($this->temp['selected'],'link-custom-url',false) . ')>Custom URL</option>'."\n\t".'<option value=""> </option><optgroup label="' . $pt->labels->name . '">',$output);
				$output = str_replace('</select>','</optgroup></select>',$output);
				unset($this->temp);
				return $output;
			}
        
	function submit() {
        $url = remove_query_arg('updated');
        $url = remove_query_arg('unable',$url);
        $url = remove_query_arg('defaulted',$url);
        $url = remove_query_arg('undefaulted',$url);

        if (isset($_POST['default'])) {
			if (delete_option($this->opt))
				wp_redirect(add_query_arg('defaulted',1,$url));
			else
				wp_redirect(add_query_arg('undefaulted',1,$url));
			exit();
		}

		$configs = $_POST[$this->opt];

		foreach ($configs as $group => $fields) {

			foreach ($fields as $field => $val) {

				$settings = $this->parse_args($this->created->$group->fields[$field]->settings,$group);

                if (is_array($val) && count($val))
					if ($val['val'] == 'link-custom-url' && array_key_exists('custom',$val)) {
						if ($val['custom'] == 'http://')
							$val = $val['val'];
						$configs[$group][$field] = $val;
					} else if (!array_key_exists('on',$val))
                        $configs[$group][$field] = $val = $val['val'];
					else if ($val['val'] == $settings['default'])
                        unset($configs[$group][$field]['val']);

                if ($val == $settings['default'])
                    unset($configs[$group][$field]);

            }

            if (!count($configs[$group]))
                unset($configs[$group]);
        }

        $updated = false;
        if (count($configs))
            $updated = update_option($this->opt,$configs);
        else {
            $updated = 'blank';
            delete_option($this->opt);
        }

		//echo '<pre>' . print_r($configs,true) . '</pre>';

        if ($updated || $updated == 'blank')
            $url = add_query_arg('updated',1,$url);
        else
            $url = add_query_arg('unable',1,$url);

        wp_redirect($url);

        exit();
	}

	function add_group($a,$b = '') {

		if (is_array($b))
			$settings = $b;
		else
			$settings = array('label' => $b);

		if (!array_key_exists('label',$settings) || empty($settings['label']))
			$settings['label'] = $this->gen_label($a);

		if (!isset($this->created->$a))
			$this->created->$a = new stdClass();

		if (array_key_exists('parent',$settings)) {
			$parent = $settings['parent'];
			unset($settings['parent']);

			if (!isset($this->created->$parent))
				$this->created->$parent = new stdClass();

			$this->created->$parent->childs[] = $a;
			$this->created->$a->parent = $parent;
		}

		$this->created->$a->settings = $settings;

		$this->last_group = $a;

		unset($a,$b,$parent,$settings);

	}

	function add_field($a,$b = '',$c = '') {

		if (is_array($b))
			$settings = $b;
		else
			$settings = array('label' => $b);

		if (!empty($c))
			$settings['desc'] = $c;

		if (!array_key_exists('label',$settings) || empty($settings['label']))
			$settings['label'] = $this->gen_label($a);

		if (!array_key_exists('group',$settings))
			$group = $this->last_group;
		else {
			$group = $settings['group'];
			unset($settings['group']);
		}

		$field = new stdClass();
		$field->settings = $settings;
        unset($settings);

		if (!isset($this->created->$group->fields) || !is_array($this->created->$group->fields))
			$this->created->$group->fields = array();

		$this->created->$group->fields[$a] = $field;

		unset($a,$b,$group,$field);

	}




	function gen_label($text) {
		$text = str_replace('-',' ',$text);
		$text = str_replace('_',' ',$text);
		$text = ucwords($text);

		return $text;
	}

	function parse_args($settings,$group) {
		$settings = wp_parse_args($settings,$this->created->$group->settings);
        $settings = wp_parse_args($settings,$this->defaults);
        return $settings;
	}

}




// if $field is array, first key is group, second is field name
function get_site_config($field,$around = '',$image_size = 'full') {
	global $bco_config_opt;

	if (!is_array($around) || empty($around))
		$around = array('','');

	$bco_config = wp_cache_get($bco_config_opt);

	$created = $bco_config->created;

	if (is_array($field)) {
		$temp = $field;
		list($group,$field) = $temp;
	} else
		foreach ($created as $gname => $group)
			if (isset($group->fields) && is_array($group->fields))
				foreach ($group->fields as $fname => $temp)
					if ($fname == $field) {
						$group = $gname;
						break 2;
					}

	if (is_object($group) || empty($group) || !isset($created->$group))
		return;

	$group = $created->$group;
	$field = $group->fields[$field];

	$settings = wp_parse_args(array_merge(array('around' => $around),$field->settings),$group->settings);
	$settings = wp_parse_args($settings,$bco_config->defaults);

	if ($settings['switch'])
		if ((!isset($field->on) || !isset($field->value)) && !$settings['readonly'] && !$settings['switch_display'])
			return;

	$value = isset($field->value) ? $field->value : $settings['default'];

	if ($settings['type'] == 'email')
		$value = antispam($value);
	else if ($settings['type'] == 'media') {
		if (is_numeric($value)) {
			$img = wp_get_attachment_image_src($value,$image_size);
			$value = $img[0];
		}
		if (strpos($around[0],'<img') !== false) {
			foreach ($around as $i => $wrap) {
				if (strpos($wrap,'class=') !== false) {
					if (strpos($wrap,'attachment-') === false) {
						$quote = strpos($wrap,'class="') !== false ? '"' : '\'';
						$around[$i] = str_replace('class='.$quote,'class='.$quote.'attachment-'.$image_size.' ',$wrap);
					}
					break;
				} else {
					$around[$i] = str_replace('src=','class="attachment-'.$image_size.'" src=',$wrap);
				}
			}
		}
		if ($value == '')
			return '';
	} else if (in_array($settings['type'],$bco_config->types)) {
		if ($value == 'link-custom-url' && isset($field->custom))
			$value = $field->custom;
		else if ($value == '')
			$value = '#';
		else
			$value = get_permalink($value);
	}

	return $around[0] . $value . $around[1];

}

function site_config($field,$around = '',$image_size = 'full') { echo get_site_config($field,$around,$image_size); }



?>
