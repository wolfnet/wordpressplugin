<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head profile="http://gmpg.org/xfn/11">
	
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	
	<title><?php wp_title(''); ?></title>

	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

	<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
	
	<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>

	<?php wp_enqueue_style('site',get_bloginfo('stylesheet_url')) ?>
		
	<?php wp_enqueue_script('jquery') ?>
	<?php wp_enqueue_script('jquery-color') ?>
	<?php wp_enqueue_script('validate',get_bloginfo('template_directory') . '/inc/validate.js',array('jquery'),'1.0') ?>
	<?php wp_enqueue_script('site',get_bloginfo('template_directory') . '/inc/scripts.js',array('jquery','jquery-color','validate'),'1.0') ?>
	<?php 
		// site_config('themecolor',array('<a href="davidparsons.me"><img src="','" alt="logo"></a>')) 
		// site_config('themecolor',array(wp_enqueue_script('themecolorchoice',get_bloginfo('template_url') . '','.css',array('site','orbit','home')))) 
	?>
	
	<?php wp_head(); ?>
	
</head>
<body <?php body_class(); ?>>

	<div id="header">
	<div id="centerheader">
		<div id="logo">
			<?php site_config('customlogourl',array('<a href="' . get_home_url() . '"><img src="','" alt="" /></a>')) ?>
		</div>
		<ul id="social">
			<?php site_config('fb',array('<li class="fb"><a href="','" target="_blank"><img src="' . get_bloginfo('stylesheet_directory') . '/images/fb.jpg" alt="Facebook" width="30" height="27"></a></li>')) ?>
			<?php site_config('tw',array('<li class="tw"><a href="','" target="_blank"><img src="' . get_bloginfo('stylesheet_directory') . '/images/tw.jpg" alt="Twitter" width="31" height="27"></a></li>')) ?>
			<?php site_config('in',array('<li class="in"><a href="','" target="_blank"><img src="' . get_bloginfo('stylesheet_directory') . '/images/in.jpg" alt="LinkedIn" width="30" height="27"></a></li>')) ?>
			<?php site_config('yt',array('<li class="yt"><a href="','" target="_blank"><img src="' . get_bloginfo('stylesheet_directory') . '/images/yt.jpg" alt="YouTube" width="31" height="27"></a></li>')) ?>
			<?php site_config('rss',array('<li class="rss"><a href="','" target="_blank"><img src="' . get_bloginfo('stylesheet_directory') . '/images/rss.jpg" alt="RSS" width="30" height="27"></a></li>')) ?>
		</ul>
		<div id="callustoday"><?php site_config('main',array('Call Us Today: <div id="callustodaynumber">','</div>')) ?></div>
		<?php site_config('brokerurl',array('<div id="brokerlogo"><a href="' . get_home_url() . '"><img src="','" alt="brokerlogo" /></a></div>')) ?>
		<div id="nav">
			<?php wp_nav_menu(array('theme_location' => 'primary','depth' => 2)); ?>
		</div>

	</div>
	</div>

	<div id="subheader"></div>
