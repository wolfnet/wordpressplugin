// JavaScript Document

jQuery(function($) {

	jQuery.fn.hoverColor = function(args) {
		var config = {
			'on' : '#FFF',
			'off' : 'black',
			'time' : '150'
		}

		$.extend(config,args);

		return this.each(function() {
			if ($(this).css('cursor') != 'default')
				$(this).hover(function() {
					$(this).stop(true).animate({color: config.on},config.time);
				},function() {
					$(this).stop(true).animate({color: config.off},config.time);
				});
		});
	};

	//$("#header a").hoverColor({on: 'white',off: 'black'});
    
	$("form li input[type=text],form li input[type=email],form li input[type=tel],form li input[type=number],form li textarea,#sidebar #searchform input[type=text]").each(function() {
		if ($(this).val() != "")
			$(this).parent().find("label").hide();
	}).focus(function() {
		$(this).parent().find("label").addClass("focus");
	}).keypress(function() {
		$(this).parent().find("label").hide();
	}).blur(function() {
		if ($(this).val() == "")
			$(this).parent().find("label").removeClass("focus").fadeIn();
	});

	$("form li input[type=number]").click(function() {
		$(this).parent().find("label").hide();
	});

	// $("#social li").hover(function() {
	// 	$(this).find('a').stop(true).fadeTo(350,1).css('display','inline-block');
	// },function() {
	// 	$(this).find('a').stop(true).fadeTo(350,0).css('display','inline-block');
	// });

	$(document).ready(function() {
		$(".gform_wrapper form li input:not([type=checkbox],[type=radio],[type=submit],[type=button],[type=hidden])").each(function() {
			if ($(this).val() != "")
				$(this).parent().parent().find("label").hide();
		}).live('focus',function() {
			$(this).parent().parent().find("label").addClass("focus");
		}).live('keypress',function() {
			$(this).parent().parent().find("label").fadeOut(100);
		}).live('blur',function() {
			if ($(this).val() == "")
				$(this).parent().parent().find("label").removeClass("focus").fadeIn();
			else
				$(this).parent().parent().find("label").hide();
		});

		$(".gform_wrapper form li textarea").each(function() {
			if ($(this).val() != "")
				$(this).parent().parent().find("label").hide();
		}).live('focus',function() {
			$(this).parent().parent().find("label").addClass("focus");
		}).live('keypress',function() {
			$(this).parent().parent().find("label").fadeOut(100);
		}).live('blur',function() {
			if ($(this).val() == "")
				$(this).parent().parent().find("label").removeClass("focus").fadeIn();
			else
				$(this).parent().parent().find("label").hide();
		});

		$(document).bind('gform_post_render',function(a,b) {
			$("#gform_wrapper_"+b+" input:not([type=checkbox],[type=radio],[type=submit],[type=button],[type=hidden])").each(function() {
				if ($(this).val() != "")
					$(this).parent().parent().find("label").hide();
			});
			$("#gform_wrapper_"+b+" textarea").each(function() {
				if ($(this).val() != "")
					$(this).parent().parent().find("label").hide();
			});
		});

		$(".gform_wrapper form li select").each(function() {
			if ($(this).find("option:selected").val() != "")
				$(this).parent().parent().find("label").hide();
		}).live('change',function() {
			if ($(this).find("option:selected").val() != "")
				$(this).parent().parent().find("label").hide();
			else
				$(this).parent().parent().find("label").show();
		}).live('blur',function() {
			if ($(this).find("option:selected").val() == "")
				$(this).parent().parent().find("label").show();
		});

		$("table.ui-datepicker tbody a").live('click',function() {
			var clicked = $(this).parent().attr('onclick').split("'");
			$(clicked[1]).parent().parent().find('label').hide();
		});

		$(".gform_wrapper li.radios input").each(function() {
			if ($(this).is(':checked'))
				$(this).parent().find('label').addClass('checked');
		}).click(function() {
			$(this).parent().parent().find('label.checked').removeClass('checked');
			if ($(this).is(':checked'))
				$(this).parent().find('label').addClass('checked');
		});

		$("#content a").click(function(ev) {
			var href = $(this).attr('href').split('#');
			if ($.isArray(href) && href[1].length > 1) {
				ev.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top - 40}, 500);
			}
		});

	});


	/* POSTS SLIDER
	$("#achilles #posts_nav:not(.disabled) span").click(function(ev) {
		ev.preventDefault();

		var cur = $("#achilles #posts_container .post.cur");

		if ($(this).hasClass('left')) var left = 1;
		else var left = 0;

		if (left) {
			var next = cur.prev();
			var nnext = cur.prev().prev();
		} else {
			var next = cur.next();
			var nnext = cur.next().next();
		}

		if (!next.length)
			return;

		$("#achilles #posts_nav").addClass('disabled');

		$("#achilles #posts_nav span.disabled").fadeTo(250,1,function() { $(this).removeClass('disabled'); });

		if (!nnext.length)
			if (left)
				$("#achilles #posts_nav span.left").fadeTo(250,.4,function() {
					$(this).addClass('disabled');
				});
			else
				$("#achilles #posts_nav span.right").fadeTo(250,.4,function() {
					$(this).addClass('disabled');
				});

		cur.fadeTo(250,0,function() {
			cur.removeClass('cur').hide();
			next.fadeTo(250,1,function() {
				next.addClass('cur');
				$("#achilles #posts_nav").removeClass('disabled');
			});
		});
	});
	*/


});
