jQuery(function($) {

	if ($("body").hasClass('dashboard_page_bco_config')) {
		setTimeout(function() {
			$(".wrap > .updated,.wrap > .error").animate({backgroundColor: '#FCFCFC',borderTopColor: '#EEE',borderLeftColor: '#EEE',borderRightColor: '#EEE',borderBottomColor: '#EEE',color: '#999'},500,function() { $(this).addClass('faded'); });
		},4000);
	}

	$(".wrap .masonry").masonry({
		itemSelect: '.box',
		columnWidth: 350,
		isAnimated: true
	});

	$(".config-group li.check-all input").click(function() {
		if ($(this).is(':checked'))
			$(this).parent().parent().parent().find('input[type=checkbox]').attr('checked','checked');
		else
			$(this).parent().parent().parent().find('input[type=checkbox]').removeAttr('checked');
	});

	$(".config-group li.switch label").click(function() {
		if (!$(this).parent().find('input[type=checkbox]').is(':checked'))
			if ($(this).parent().find('input').not('[type=checkbox]').attr('readonly') == undefined)
				$(this).parent().find('input').not('[type=checkbox]').focus();
	});

	$('input.add-media').click(function() {  
		var rel = $(this).attr('rel');
		window.location.hash = 'media-field=' + rel;
        tb_show('Upload media to Configuration','media-upload.php?referer=bco_config&type=file&TB_iframe=true&post_id=0',false);  
        return false;  
    });

	$('a.delete-media-url').live('click',function(ev) {
		ev.preventDefault();
		var par = $(this).parent();
		var input = par.find('input[type=hidden]');

		if (yes = confirm('Are you sure you want to remove current media for \'' + par.find('label').html() + '\'?')) {
			input.val('');
			par.find('a.media-url').remove();
			$(this).after('<span class="please-save">Deleted!</span>').remove();
			par.parent().parent().addClass('please-save');
		}

	});

	$("div.masonry div.config-group ul li select").change(function() {
		if ($(this).find('option:selected').val() != 'link-custom-url') {
			$(this).parent().find('div.link-custom-url').slideUp(400);
			return true;
		}
		$(this).parent().find('div.link-custom-url').slideDown(400,function() { $(this).find('input').focus(); $("div.masonry").masonry('reload'); });
	});

	window.send_to_editor = function(html) {
		var media_url = '';

		var found = false;
		if (html.indexOf('<img ') != -1) {
			var image_url = $('img',html).attr('src');
			var image_classes = $('img',html).attr('class');

			if (image_url && image_classes && image_classes.indexOf(' ') != -1) {
				image_classes = image_classes.split(' ');

				for (var i = 0; i < image_classes.length; i++) {
					if (image_classes[i].indexOf('wp-image-') != -1) {
						var temp = image_classes[i].split('-');
						var image_id = temp[temp.length-1];
						found = true;
						break;
					}
				}

				media_url = image_url;
				
			} else {
				var start = html.indexOf(' src="') + 6;
				var end = html.substring(start).indexOf('"') + start;
				media_url = html.substring(start,end);
			}
		} else {
			media_url = $('a',html).attr('href');

			if (!media_url) {
				var start = html.indexOf('href=') + 6;
				var end = html.substring(start).indexOf('\'') + start;
				media_url = html.substring(start,end);
			}
		}

		var hash = window.location.hash;
		var field = hash.split("=");
		var sel = '#' + field[1];
		window.location.hash = '';
		$(sel).parent().find('a.media-url').remove();
		$(sel).parent().find('input[type=button]').after('<a href="' + media_url + '" class="media-url thickbox" title="' + media_url + '">View media</a> <a href="#" class="delete-media-url">Delete media</a>');

		if (found)
			$(sel).val(image_id);
		else
			$(sel).val(media_url);

		tb_remove();
	}  

});
