<?php
/**
 * @package WordPress
 * @subpackage Default_Theme 
 * Template Name: IDX 
 */

get_header(); ?>

	<div id="torso">
	<div id="centertorso">

		<div id="content" class="nosidebar">
			<!-- BrandCo idx header -->

			<!-- BrandCo idx footer -->
		</div>

	</div>
	</div>

<?php get_footer(); ?>
