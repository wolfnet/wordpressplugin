<?php
/*
Template Name: Contact
*/
?>

<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */

get_header(); ?>

	<div id="torso">
	<div id="centertorso">

		<div id="contentcontact">

			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

				<div <?php post_class() ?> id="post-<?php the_ID(); ?>">
					<?php
					if (has_post_thumbnail()) {
						$img = wp_get_attachment_image_src(get_post_thumbnail_id(),'fullwidthfeaturedimage');
						echo '<img src="' . $img[0] . '" class="featuredimagefullwidth" />';
					}
					else {
						// echo '<img src="' . get_bloginfo( 'template_url' ) . '/images/map.jpg" />';
						echo '<div class="nofeaturedimage"></div>';
					}
					?>
					<h1 class="pagetitle"><?php the_title() ?></h1>
					<div class="entry">
						<?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?>
						<?php edit_post_link('Edit this entry.', '<p>', '</p>'); ?>

						<div class="hrcontact"></div>

						<div id="agentcontact">
							<?php site_config('name',array('<h2>','</h2>')) ?>
							<?php site_config('address1',array('<p>','</p>')) ?>
							<?php site_config('address2',array('<p>','</p>')) ?>
							<?php
								if($tempforphone = get_site_config('contactphone',array('<p><strong>phone:</strong> ','</p>'))) {
									if (isset($tempforphone) && '<p><strong>phone:</strong> </p>' != $tempforphone)
										echo $tempforphone;
								}
							?>
							<?php
								if($tempforfax = get_site_config('contactfax',array('<p><strong>fax:</strong> ','</p>'))) {
									if (isset($tempforfax) && '<p><strong>fax:</strong> </p>' != $tempforfax)
										echo $tempforfax;
								}
							?>
							<?php
								if($tempforemail = get_site_config('contactemail',array('<p><strong>email:</strong> ','</p>'))) {
									if (isset($tempforemail) && '<p><strong>email:</strong> </p>' != $tempforemail)
										echo $tempforemail;
								}
							?>
						</div>
						<div id="agentcontactform">
							<?php dynamic_sidebar('Contact'); ?>
						</div>
					</div>
				</div>

			<?php endwhile; endif; ?>

		</div>

	</div>
	</div>

<?php get_footer(); ?>
