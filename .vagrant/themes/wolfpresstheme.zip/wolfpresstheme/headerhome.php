<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head profile="http://gmpg.org/xfn/11">
	
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	
	<title><?php wp_title(''); ?></title>

	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	
	<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>

	<?php wp_enqueue_style('site',get_bloginfo('stylesheet_url')) ?>
		
	<?php wp_enqueue_script('jquery') ?>
	<?php wp_enqueue_script('jquery-color') ?>
	<?php wp_enqueue_script('validate',get_bloginfo('template_directory') . '/inc/validate.js',array('jquery'),'1.0') ?>
	<?php wp_enqueue_script('site',get_bloginfo('template_directory') . '/inc/scripts.js',array('jquery','jquery-color','validate'),'1.0') ?>
	
	<?php wp_head(); ?>
	
</head>
<body <?php body_class(); ?>>

	<div id="headerhome">
	<div id="centerheader">

		<ul id="social">
			<?php site_config('fb',array('<li class="fb"><a href="','" target="_blank">Like us on Facebook</a></li>')) ?>
			<?php site_config('tw',array('<li class="tw"><a href="','" target="_blank">Follow us on Twitter</a></li>')) ?>
			<?php site_config('gp',array('<li class="gp"><a href="','" target="_blank">Hang with us on Google Plus</a></li>')) ?>
			<?php site_config('in',array('<li class="in"><a href="','" target="_blank">View us on LinkedIn</a></li>')) ?>
			<?php site_config('yt',array('<li class="yt"><a href="','" target="_blank">Watch us on YouTube</a></li>')) ?>
			<?php site_config('rss',array('<li class="rss"><a href="','" target="_blank">Subscribe via RSS</a></li>')) ?>
		</ul>

		<div id="nav">
			<?php wp_nav_menu(array('theme_location' => 'primary','depth' => 1)); ?>
		</div>

	</div>
	</div>

	<div id="subheader"></div>
