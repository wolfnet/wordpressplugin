<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */

// wp_enqueue_style('home',get_bloginfo('template_url') . '/inc/home.css',array('site','orbit'));
// wp_enqueue_style('orbit',get_bloginfo('template_url') . '/inc/orbit.css',array('site'));
// wp_enqueue_script('orbit',get_bloginfo('template_url') . '/inc/orbit.js',array('site','jquery'));

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head profile="http://gmpg.org/xfn/11">
	
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	
	<title><?php wp_title(''); ?></title>

	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

	<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
	
	<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>

	<?php wp_enqueue_style('site',get_bloginfo('stylesheet_url'),array('orbit')) ?>
		
	<?php wp_enqueue_script('jquery') ?>
	<?php wp_enqueue_script('jquery-color') ?>
	<?php wp_enqueue_script('validate',get_bloginfo('template_directory') . '/inc/validate.js',array('jquery'),'1.0') ?>
	<?php wp_enqueue_script('site',get_bloginfo('template_directory') . '/inc/scripts.js',array('jquery','jquery-color','validate'),'1.0') ?>
	<?php wp_enqueue_style('home',get_bloginfo('stylesheet_directory') . '/inc/home.css',array('site','orbit')) ?>
	<?php wp_enqueue_style('orbit',get_bloginfo('stylesheet_directory') . '/inc/foundation.min.css') ?>
	<?php wp_enqueue_script('orbit',get_bloginfo('template_directory') . '/inc/foundation.min.js',array('jquery')) ?>

	
	<?php wp_head(); ?>
	
</head>
<body <?php body_class(); ?>>

<div id="header">
<div id="centerheader">
	<div id="logo">
		<?php site_config('customlogourl',array('<a href="' . get_home_url() . '"><img src="','" alt="" /></a>')) ?>
	</div>
	<ul id="social">
		<?php site_config('fb',array('<li class="fb"><a href="','" target="_blank"><img src="' . get_bloginfo('stylesheet_directory') . '/images/fb.jpg" alt="Facebook" width="30" height="27"></a></li>')) ?>
		<?php site_config('tw',array('<li class="tw"><a href="','" target="_blank"><img src="' . get_bloginfo('stylesheet_directory') . '/images/tw.jpg" alt="Twitter" width="31" height="27"></a></li>')) ?>
		<?php site_config('in',array('<li class="in"><a href="','" target="_blank"><img src="' . get_bloginfo('stylesheet_directory') . '/images/in.jpg" alt="LinkedIn" width="30" height="27"></a></li>')) ?>
		<?php site_config('yt',array('<li class="yt"><a href="','" target="_blank"><img src="' . get_bloginfo('stylesheet_directory') . '/images/yt.jpg" alt="YouTube" width="31" height="27"></a></li>')) ?>
		<?php site_config('rss',array('<li class="rss"><a href="','" target="_blank"><img src="' . get_bloginfo('stylesheet_directory') . '/images/rss.jpg" alt="RSS" width="30" height="27"></a></li>')) ?>
	</ul>
	<div id="callustoday"><?php site_config('main',array('Call Us Today: <div id="callustodaynumber">','</div>')) ?></div>
	<?php site_config('brokerurl',array('<div id="brokerlogo"><a href="' . get_home_url() . '"><img src="','" alt="brokerlogo" /></a></div>')) ?>
	<div id="nav">
		<?php wp_nav_menu(array('theme_location' => 'primary','depth' => 2)); ?>
	</div>

	<div id="featuredimages">
	<div id="featuredimagesslides">
		<div id="featured">
			<?php
			// The Query
			$the_query = new WP_Query( 'post_type=slide&posts_per_page=-1' );
			// The Loop
			while ( $the_query->have_posts() ) :
				//if (has_post_thumbnail()) {
					$the_query->the_post();
					if (!has_post_thumbnail())
						continue;
					echo '<a href="' . esc_attr( get_post_meta( get_the_ID(), '_linkurl',true) ) . '">';
					echo '<div class="slidecontent">';
					//echo '<img src="' . get_the_post_thumbnail( the_ID(), 'thumbnail','src' ) . '" alt="slide image">';
					//get_the_post_thumbnail();
					$img = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),'featuredimage');
					//the_post_thumbnail('featuredimage');
					echo '<img src="' . $img[0] . '" alt="" />';
					echo '<span class="orbit-caption" id="htmlCaption"><div class="slidertext">' . get_the_title() . '</div></span>';
					echo '</div>'; 
					echo '</a>';
				//}
			endwhile;
			// Restore original Query & Post Data
			wp_reset_query();
			wp_reset_postdata();
			?>
		</div>
	</div> 
	<div id="featuredimagesform">
		<div id="homeformheader"><h2>Start Your Home Search</h2></div>
		<div id="quicksearch">
			<p>Select options from the form below and start the search for your dream home now!</p>

			<?php echo do_shortcode('[wnt_search]'); //the_widget('Wolfnet_QuickSearchWidget'); //the_widget('com_wolfnet_wordpress_listing_quickSearchWidget') ?>

			<a class="advanced-search" href="<?php site_config('mapsearchurl') ?>">Advanced Search</a>
		</div> <!-- end of quicksearch -->
	</div>
	</div>

</div>
</div>

<script type="text/javascript">
     $(window).load(function() {
         $('#featured').orbit({
              bullets: true,
              directionalNav: false,
              // startClockOnMouseOut: true,
              captions: true
         });
     });
</script>


<div id="subheader">
	<div id="subheader_title">
		<input type="submit" value="Featured Listings">
	</div>
	<div id="subheader_slides">
		<?php echo do_shortcode(stripslashes(get_site_config('featuredlistings'))) ?>
	</div>
</div>

<div id="torso">
	<div id="centertorso">
		<div id="contenthome">

			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

				<div <?php post_class() ?> id="post-<?php the_ID(); ?>">
					<!-- <h1 class="pagetitle"><?php the_title() ?></h1> -->
					<div class="entry">
						<?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?>
						<?php edit_post_link('Edit this entry.', '<p>', '</p>'); ?>
					</div>
				</div>

			<?php endwhile; endif; ?>

		</div>

		<div id="sidebar" class="sidebarhome">
			<?php
				if (is_active_sidebar('home')) {
					// echo '<div id="sidebar">';
					dynamic_sidebar('home');
					// echo '</div>';
				}
				else if (get_site_config('mapsearchimageurl') != '') {
					echo '<h4 class="widgettitle">Map Search</h4>';

					// site_config('mapsearchurl',array('<div id="mapsearch"><a href="','"></a></div>'));
					echo '<div id="mapsearchcustom">';

					list($maxw,$maxh) = array(292,161);
					$img = get_site_config('mapsearchimageurl');
					$dims = getimagesize($img);
					list($w,$h) = $dims;
					$aspect = $w / $h;
					if ($w > $maxw) {
						$w = $maxw;
						$h = $w / $aspect;
					}
					if ($h < $maxh) {
						$h = $maxh;
						$w = $h * $aspect;
					}

					$w = round($w);
					$h = round($h);

					echo '<div style="width: ' . $maxw . 'px; height: ' . $maxh . 'px; overflow: hidden;"><img src="' . $img . '" alt="" style="width: ' . $w . 'px; height: ' . $h . 'px;" /></div>';
					echo '<a href="' . get_site_config('mapsearchurl') . '"></a>';
					echo '</div>';
					// site_config('mapsearchurl',array('<a href="','"><div id="mapsearch"><img src="' . get_bloginfo('stylesheet_directory') . '/images/map.png" alt="Map Search"></div></a>'));
				}
				else {
					echo '<h4 class="widgettitle">Map Search</h4>';
					site_config('mapsearchurl',array('<a href="','"><div id="mapsearch"><img src="' . get_bloginfo('stylesheet_directory') . '/images/map.png" alt="Map Search"></div></a>'));
				}
				
				//site_config('mapsearchurl',array('<a href="','"><div id="mapsearch"><img src="' . $themapurl . '" alt="Map Search"></div></a>'));
				
				// echo '<a href="';
				// site_config('mapsearchurl');
				// echo '"><div id="mapsearch"><img src="';
				// site_config('mapurl');
				// echo '" alt="Map Search"></div></a>';
			?>
		</div>

		<div class="hrhome"></div>

		<div id="blogfeaturehome">
			<?php echo '<div id="newspic"><img src="' . get_bloginfo('template_directory') . '/images/news.png" alt="latest blog posts"></div>' ?>
			<div id="fromtheblog">
				<h2>Latest from The Blog</h1>
				<ul><?php wp_get_archives( array( 'type' => 'postbypost', 'limit' => 4 ) ); ?></ul>
			</div>
		</div>
		<div id="searchbyareahome">
			<?php echo '<div id="searchpic"><img src="' . get_bloginfo('template_directory') . '/images/magglass.png" alt="search by area"></div>' ?>
			<div id="fromtheblog2">
			<h2>Search by Area</h1>
			<ul>
				<?php
				// The Query
				$the_query_area = new WP_Query( 'post_type=city&orderby=title&order=asc&posts_per_page=15' );
				// The Loop
				while ( $the_query_area->have_posts() ) :
					$the_query_area->the_post();
					echo '<li>';
					echo '<a href="';
					// . esc_attr( get_post_meta( get_the_ID(), '_linkurl',true) ) .
					echo the_permalink();
					echo '">';
					echo get_the_title();
					echo '</a>';
					echo '</li>';
				endwhile;
				// Restore original Query & Post Data
				wp_reset_query();
				wp_reset_postdata();
				?>
			</ul>
			</div>
		</div>

	</div>
</div>	

<?php get_footer(); ?>
