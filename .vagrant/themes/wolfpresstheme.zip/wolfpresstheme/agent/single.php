<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */

get_header(); ?>

<div id="torso">
<div id="centertorso">
<div id="content">

	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

		<div <?php post_class() ?> id="post-<?php the_ID(); ?>" style="margin-top:73px;">
			<?php
			if (has_post_thumbnail()) {
				$img = wp_get_attachment_image_src(get_post_thumbnail_id(),'agentbig');
				echo '<div class="div_image">';
				echo '<img src="' . $img[0] . '" class="featuredimage single_agent_featuredimage" />';
				// echo '<div class="featuredimage">' . the_post_thumbnail('featuredimage') . '</div>';
				// the_post_thumbnail('featuredimage');
				// echo '<h2 class="agent_connect">Connect</h2>';
				// echo '<ul id="social" style="float:left;margin: 30px 0 0 15px;">';
				// 	site_config('fb_agent',array('<li class="fb_agent"><a href="','" target="_blank"><img src="' . get_bloginfo('stylesheet_directory') . '/images/fb.jpg" alt="Facebook" width="30" height="27"></a></li>'));
				// 	site_config('tw_agent',array('<li class="tw_agent"><a href="','" target="_blank"><img src="' . get_bloginfo('stylesheet_directory') . '/images/tw.jpg" alt="Twitter" width="31" height="27"></a></li>'));
				// 	site_config('in_agent',array('<li class="in_agent"><a href="','" target="_blank"><img src="' . get_bloginfo('stylesheet_directory') . '/images/in.jpg" alt="LinkedIn" width="30" height="27"></a></li>'));
				// echo '</ul>';
				echo '<ul id="social" class="info">';
					$info = get_post_meta(get_the_ID(),'_info',true);
					foreach ($info as $item => $url)
						if ($url != '' && ($item == 'facebook' || $item == 'twitter' || $item == 'linkedin' ))
							echo '<li class="' . $item . '"><a href="' . $url . '" target="_blank">' . ucwords($item) . '</a></li>';
				echo '</ul>';
				echo '<div class="actual_agent_info">';
				$info_phone = get_post_meta(get_the_ID(),'_info',true);
					foreach ($info_phone as $item => $url)
						if ($url != '' && $item == 'agentphone')
							echo '<b>Phone:</b><p>' . $url . '</p>';
				$info_listings = get_post_meta(get_the_ID(),'_info',true);
					foreach ($info_listings as $item => $url) {
						if ($url != '' && $item == 'agentlistings')
							echo '<p class="italictranform"><a href="' . $url . '" title="Agent Listings">My Listings</a></p>';
						if ($url != '' && $item == 'agentwebsite')
							echo '<p class="italictranform"><a href="' . $url . '" title="Agent Listings">My Website</a></p>';
					}
				echo '</div>';
				echo '</div>';
			}
			else {
				echo '<div class="div_noimage">';
				// echo '<img src="' . get_bloginfo( 'template_url' ) . '/images/default.jpg" class="featuredimage" />';
				// echo '<div class="nofeaturedimage_agent_page"></div>';
				// echo '<h2 class="agent_connect_no_image">Connect</h2>';				
				echo '<ul id="social" class="info">';
					$info = get_post_meta(get_the_ID(),'_info',true);
					foreach ($info as $item => $url)
						if ($url != '' && ($item == 'facebook' || $item == 'twitter' || $item == 'linkedin' ))
							echo '<li class="' . $item . '"><a href="' . $url . '" target="_blank">' . ucwords($item) . '</a></li>';
				echo '</ul>';
				echo '<div class="actual_agent_info">';
				$info_phone = get_post_meta(get_the_ID(),'_info',true);
					foreach ($info_phone as $item => $url)
						if ($url != '' && $item == 'agentphone')
							echo '<b>Phone:</b><p>' . $url . '</p>';
				$info_listings = get_post_meta(get_the_ID(),'_info',true);
					foreach ($info_listings as $item => $url) {
						if ($url != '' && $item == 'agentlistings')
							echo '<p class="italictranform"><a href="' . $url . '" title="Agent Listings">My Listings</a></p>';
						if ($url != '' && $item == 'agentwebsite')
							echo '<p class="italictranform"><a href="' . $url . '" title="Agent Listings">My Website</a></p>';
					}
				echo '</div>';
				echo '</div>';
			}
			?>

			<h2 class="agent_title"><?php the_title(); ?></h2>
			<?php
				$info_phone = get_post_meta(get_the_ID(),'_info',true);
						foreach ($info_phone as $item => $url)
							if ($url != '' && $item == 'agenttitle')
								echo '<p class="agent_subtitle">' . $url . '</p>';
			?>
			<?php
				$info_email = get_post_meta(get_the_ID(),'_info',true);
					foreach ($info_email as $item => $url)
						if ($url != '' && $item == 'agentemail')
							echo '<p class="agent_email"><b>Email:</b> ' . $url . '</p>';
			?>

			<div class="entry nomarginbottomentry">
				<?php the_content('<p class="serif">Read the rest of this entry &raquo;</p>'); ?>

				<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
				<?php the_tags( '<p>Tags: ', ', ', '</p>'); ?>

			</div>

			<hr>

			<?php $info = get_post_meta(get_the_ID(),'_info',true); ?>
				<?php foreach ($info as $item => $url) ?>
					<?php if ($url != '' && $item == 'featuredlistings') ?>
						<?php echo do_shortcode($url); ?>

		</div>

	<?php endwhile; else: ?>

		<p>Sorry, no posts matched your criteria.</p>

<?php endif; ?>

</div> <!-- end #content div -->

		<div id="sidebar">
			<?php dynamic_sidebar('blog'); ?>
	    </div> <!-- close #sidebar div -->

	    </div> <!-- close #centertorso div -->
		</div> <!-- close #torso div -->

<?php get_footer(); ?>
