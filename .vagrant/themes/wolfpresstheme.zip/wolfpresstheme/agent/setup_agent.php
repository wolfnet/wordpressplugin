<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */

$setup = new setup_agent_post_type;
$setup->init();
unset($setup);

class setup_agent_post_type {

	var $type = 'agent';
	var $single = 'Agent';
	var $plural = 'Agents';
	var $nonce = 'agent';

	function init() {
		add_action('init',array(&$this,'create_post_type'));
		//add_action('init',array(&$this,'create_taxonomy'));
		//add_filter('post_type_link',array(&$this,'filter_post_link'),10,2);

		if (is_admin()) $this->admin_init();
		else $this->public_init();
	}

	function admin_init() {
		// add_action('edit_form_after_title',array(&$this,'add_subtitle'));
		add_action('add_meta_boxes',array(&$this,'meta_boxes'));
		add_action('save_post',array(&$this,'save_post'));
		//add_action("manage_{$this->type}_posts_custom_column", array(&$this,"custom_post_column_values"));
		//add_filter("manage_edit-{$this->type}_columns", array(&$this,"custom_post_column_titles"));
	}

	function public_init() {
		add_action('wp_print_styles',array(&$this,'styles'));
		add_filter('nav_menu_css_class',array(&$this,'special_nav_class'),10,2);
	}
	
	function index() {
		wp_enqueue_style($this->type,get_bloginfo('template_url') . '/' . $this->type . '/style.css');
		add_filter('body_class',array(&$this,'custom_type_body_classes'));
	}
	
	function custom_type_body_classes($classes) {
		if (!is_tax() && !is_category() && !is_archive())
			$classes[] = $this->type . '-index';
		return $classes;
	}

	function special_nav_class($classes, $item) {
		global $wp_query;
		if (isset($wp_query->post) && $wp_query->posts[0]->post_type == $this->type)
			if ($item->title == $this->plural)
				$classes[] = 'current-menu-item';
		return $classes;
	}

	function create_post_type() {
		register_post_type($this->type, array(
			'label' => $this->plural,
			'description' => '',
			'public' => true,
			'show_ui' => true,
			'show_in_menu' => true,
			'show_in_nav_menu' => false,
			'capability_type' => 'post',
			'hierarchical' => false,
			'rewrite' => array('slug' => ''),
			'query_var' => true,
			'supports' => array('title','editor','excerpt','trackbacks','custom-fields','comments','revisions','thumbnail','author','page-attributes',),
			'labels' => array (
				'name' => $this->plural,
				'singular_name' => $this->single,
				'menu_name' => $this->plural,
				'add_new' => 'Add '.$this->single,
				'add_new_item' => 'Add New '.$this->single,
				'edit' => 'Edit',
				'edit_item' => 'Edit '.$this->single,
				'new_item' => 'New '.$this->single,
				'view' => 'View '.$this->single,
				'view_item' => 'View '.$this->single,
				'search_items' => 'Search '.$this->plural,
				'not_found' => 'No '.$this->plural.' Found',
				'not_found_in_trash' => 'No '.$this->plural.' Found in Trash',
				'parent' => 'Parent '.$this->single,
			),
		) );
	}

	// function add_subtitle() {
	// 	global $post;
	// 	if ($post->post_type != $this->type)
	// 		return;

	// 	if (!$subtitle = stripslashes(get_post_meta($post->ID,'_subtitle',true)))
	// 		$subtitle = '';

	// 	echo '<label id="subtitle-prompt-text" for="subtitle">Enter subtitle here</label><input type="text" name="post_subtitle" size="30" id="subtitle" autocomplete="off" value="' . $subtitle . '" /><br /><br />';
	// 	echo '<input type="hidden" name="' . $this->nonce . '_noncename" id="' . $this->nonce . '_noncename" value="' . wp_create_nonce( __FILE__ ) . '" />';
	// }

	function meta_boxes() {
		$positions = array('normal','side','advanced');
		add_meta_box('info','Information',array(&$this,'create_meta_box'),$this->type,$positions[1]);
	}

		function create_meta_box() {
			global $post;
			$info = wp_parse_args(get_post_meta($post->ID,'_info',true),array('agenttitle' =>'','agentphone' =>'','agentemail' =>'','agentlistings' =>'','agentwebsite' =>'','facebook' => '','twitter' => '','linkedin' => '','featuredlistings' => ''));
			extract($info);

			echo '<input type="hidden" name="' . $this->nonce . '_noncename" id="' . $this->nonce . '_noncename" value="' . wp_create_nonce( __FILE__ ) . '" />';

			echo '<p><strong>Agent Title</strong><br />';
			echo '<input type="text" name="info[agenttitle]" value="' . $agenttitle . '" style="width: 100%;" /></p>';

			echo '<p><strong>Agent Phone Number</strong><br />';
			echo '<input type="text" name="info[agentphone]" value="' . $agentphone . '" style="width: 100%;" /></p>';

			echo '<p><strong>Agent Email Address</strong><br />';
			echo '<input type="text" name="info[agentemail]" value="' . $agentemail . '" style="width: 100%;" /></p>';

			echo '<p><strong>Agent Listings (URL)</strong><br />';
			echo '<input type="text" name="info[agentlistings]" value="' . $agentlistings . '" style="width: 100%;" /></p>';

			echo '<p><strong>Agent Website (URL)</strong><br />';
			echo '<input type="text" name="info[agentwebsite]" value="' . $agentwebsite . '" style="width: 100%;" /></p>';

			echo '<p><strong>Facebook (URL)</strong><br />';
			echo '<input type="text" class="code" name="info[facebook]" value="' . $facebook . '" style="width: 100%;" /></p>';

			echo '<p><strong>Twitter (URL)</strong><br />';
			echo '<input type="text" class="code" name="info[twitter]" value="' . $twitter . '" style="width: 100%;" /></p>';

			echo '<p><strong>LinkedIn (URL)</strong><br />';
			echo '<input type="text" class="code" name="info[linkedin]" value="' . $linkedin . '" style="width: 100%;" /></p>';

			echo '<p><strong>Agent Featured Listings Code</strong><br />';
			echo '<textarea class="code" name="info[featuredlistings]" style="width: 100%;" />' . $featuredlistings . '</textarea><br /><span style="font-size: 10px; font-style: italic;">Get this from ther WNT WP Plugin</span></p>';
		}

	function save_post($post_id) {
		$post = get_post($post_id);
		if (!is_admin() || $post->post_type != $this->type)
			return;
		
		if ( !array_key_exists($this->nonce . '_noncename',$_POST) || !wp_verify_nonce( $_POST[$this->nonce . '_noncename'], __FILE__ ))
			return $post_id;
		
		if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE )
			return $post_id;
			
		if (!current_user_can('edit_post',$post_id))
			return $post_id;

		// update_post_meta($post_id,'_subtitle',$_POST['post_subtitle']);
		update_post_meta($post_id,'_info',$_POST['info']);
	}

	function custom_post_column_titles($columns) {
		global $post;
		if ($post->post_type == $this->type)
			$columns = array(
				"cb" => "<input type=\"checkbox\" />",
				"title" => "Title",
				"custom" => "custom",
			);
		return $columns;
	}
	
	function custom_post_column_values($column) {
		global $post;
		if ($post->post_type == $this->type) {
			if ("ID" == $column) echo $post->ID;
			elseif ("custom" == $column) {}
		}
	}

	function styles() {
		global $wp;

		if (!array_key_exists('post_type',$wp->query_vars) || $wp->query_vars["post_type"] != $this->type)
			return;
		
		$path = TEMPLATEPATH . '/' . $this->type . '/style.css';
		$url = get_bloginfo('template_directory') . '/' . $this->type . '/style.css';
		if (file_exists($path))
			wp_enqueue_style($this->type.'-style',$url);
	}

}

?>
