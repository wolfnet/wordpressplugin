<?php
define('WP_USE_THEMES', false);
echo '<container>';
require('../../../wp-blog-header.php');



echo '</container>';
?>

