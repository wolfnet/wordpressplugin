<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */

get_header(); ?>

	<div id="torso">
	<div id="centertorso">

	<div id="content">

	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

		<div <?php post_class() ?> id="post-<?php the_ID(); ?>">
			<?php
			if (has_post_thumbnail()) {
				$img = wp_get_attachment_image_src(get_post_thumbnail_id(),'content');
				echo '<img src="' . $img[0] . '" class="featuredimage" />';
				// echo '<div class="featuredimage">' . the_post_thumbnail('featuredimage') . '</div>';
				// the_post_thumbnail('featuredimage');
			}
			else {
				// echo '<img src="' . get_bloginfo( 'template_url' ) . '/images/default.jpg" class="featuredimage" />';
				echo '<div class="nofeaturedimage"></div>';
			}
			?>

			<h2 class="posttitle"><?php the_title(); ?></h2>

			<div class="entry">
				<?php the_content('<p class="serif">Read the rest of this entry &raquo;</p>'); ?>
			</div>
		</div>

	<?php endwhile; else: ?>

		<p>Sorry, no posts matched your criteria.</p>

<?php endif; ?>
</div>

<div id="sidebar">
	<?php dynamic_sidebar('Default') ?>
</div>

</div>
</div>

<?php get_footer(); ?>
