<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */


add_theme_support('post-thumbnails');

if ( function_exists( 'register_nav_menu' ) ) {
	register_nav_menu('primary','Primary Navigation');
	register_nav_menu('footer','Footer Navigation');
}

require_once('slide/setup_slide.php');
require_once('city/setup_cities.php');
require_once('agent/setup_agent.php');

add_action('bco_config_fields','theme_config_fields');
function theme_config_fields($config) {
	$config->add_group('social',array('class' => 'code','switch' => true,'default' => 'http://'));
	$config->add_field('fb',array('label' => 'Facebook','default' => 'http://www.facebook.com'));
	$config->add_field('tw','Twitter');
    //$config->add_field('gp','Google+');
    $config->add_field('in','LinkedIn');
    $config->add_field('yt','YouTube');
	$config->add_field('rss',array('label' => 'RSS','default' => get_bloginfo('rss2_url'),'readonly' => true));

    $config->add_group('address');
    $config->add_field('name','Name','Name shows up on the contact page');
    $config->add_field('address1','Address1','Address Line 1 shows up on the contact page');
    $config->add_field('address2','Address2','Address Line 2 shows up on the contact page');
    // $config->add_field('city');
    // $config->add_field('state');
    // $config->add_field('zip',array('class' => 'short','type' => 'number'));

	$config->add_group('phones',array('type' => 'tel'));
	$config->add_field('main', array('label' => 'Phone (top)','desc' => 'Shows up at the top of all pages'));
	$config->add_field('contactphone', array('label' => 'Phone (contact)','desc' => 'Shows up on the contact page'));
	$config->add_field('contactfax', array('label' => 'Fax (contact)','desc' => 'Shows up on the contact page'));
    $config->add_field('contactemail', array('label' => 'Email (contact)','desc' => 'Shows up on the contact page'));

    $config->add_group('photos','Logos and Images');
    $config->add_field('customlogourl',array('type' => 'media','label' => 'Logo Image','desc' => 'PNG Image with a width of 232px and a height between 63px and 90px'));
    $config->add_field('brokerurl',array('type' => 'media','label' => 'Broker Image','desc' => 'OPTIONAL Image with a height of 134px'));
    $config->add_field('mapsearchimageurl',array('type' => 'media','label' => 'Map Search Image','desc' => 'An Image with the dimensions 292px x 161px'));
    $config->add_field('mapsearchurl','Advanced and Map URL');
    // $config->add_field('mymedia',array('type' => 'media'));
    
    $config->add_group('shortcodes','Shortcodes');
    $config->add_field('featuredlistings',array('type' => 'textarea','label' => 'Featured Listings Shortcode for Homepage','desc' => 'DEFAULT: [wnt_featured autoplay="true" direction="left" speed="50" ownertype="agent_broker" /]','default' => '[wnt_featured autoplay="true" direction="left" speed="50" ownertype="agent_broker" /]'));
}

require_once('functions_config.php');
require_once('functions_widgets.php');

$is_login = (strpos($_SERVER['PHP_SELF'],'wp-login.php') ? true : false);

if (is_admin() || $is_login)
	require_once('functions_admin.php');
else if (!$is_login)
	require_once('functions_public.php');

/* Adding Page Image Size */
add_image_size( 'featuredimage', 630, 255, true );
add_image_size( 'content', 615, 315, true );
// add_image_size( 'mapimage', 292, 161, true );
// add_image_size( 'slideimage', 650, 325, false );
add_image_size( 'agent', 85, 110, true );
add_image_size( 'agentbig', 105, 136, true );
add_image_size( 'fullwidthfeaturedimage', 950, 300, true );

/**
 * Add Areas Custom Post Type
 */
// function create_post_type() {
// 	register_post_type( 'Areas',
// 		array(
// 			'labels' => array(
// 				'name' => __( 'Areas' ),
// 				'singular_name' => __( 'Area' ),
// 				'add_new' => _x( 'Add New', 'area' ),
// 		        'add_new_item' => __( 'Add New Area' ),
// 		        'edit_item' => __( 'Edit Area' ),
// 		        'new_item' => __( 'New Area' ),
// 		        'all_items' => __( 'All Areas' ),
// 		        'view_item' => __( 'View Area' ),
// 		        'search_items' => __( 'Search Areas' ),
// 		        'not_found' => __( 'No Areas found' ),
// 		        'not_found_in_trash' => __( 'No Areas found in the Trash' ),
// 		        'parent_item_colon' => '',
//         		'menu_name' => 'Areas'
// 			),
// 			'public' => true,
// 			'has_archive' => true,
// 			'rewrite' => array('slug' => 'area'),
// 			'supports' => array( 'title', 'editor' ),
// 			'description' => 'Search by Area',
// 		)
// 	);
// }
// add_action( 'init', 'create_post_type' );

// *
//  * Add Slider Custom Post Type
 
// function create_post_type2() {
// 	register_post_type( 'Slider',
// 		array(
// 			'labels' => array(
// 				'name' => __( 'Slider' ),
// 				'singular_name' => __( 'Slider' ),
// 				'add_new' => _x( 'Add New', 'slide' ),
// 		        'add_new_item' => __( 'Add New Slide' ),
// 		        'edit_item' => __( 'Edit Slide' ),
// 		        'new_item' => __( 'New Slide' ),
// 		        'all_items' => __( 'All Slides' ),
// 		        'view_item' => __( 'View Slide' ),
// 		        'search_items' => __( 'Search Slidesd' ),
// 		        'not_found' => __( 'No Slides found' ),
// 		        'not_found_in_trash' => __( 'No Slides found in the Trash' ),
// 		        'parent_item_colon' => '',
//         		'menu_name' => 'Slider'
// 			),
// 			'public' => true,
// 			'has_archive' => true,
// 			'rewrite' => array('slug' => 'slider'),
// 			'supports' => array( 'title', 'editor' ),
// 			'description' => 'Search by Slider',
// 		)
// 	);
// }
// add_action( 'init', 'create_post_type2' );

?>
