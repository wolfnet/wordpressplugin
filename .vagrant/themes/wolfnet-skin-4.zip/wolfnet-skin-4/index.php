<?php
/**
 * Index.php
 * @package brandco
 */

$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;

$blogfeedargs = array(
	'post_type' => array( 'post', 'city_post' ),
	'paged' => $paged,
);
$blogpostsfour = new WP_Query( $blogfeedargs );

get_header(); ?>
	<main id="site-main" role="main">

		<header class="page-header">
			<div class="main-container">
				<div class="page-header-container">
					<?php echo sprintf( '<h1 class="archive-title">%s</h1>', bco_archive_title() ); ?>
				</div>
			</div>
		</header>

		<section id="page-main" class="main-section page-has-aside homepage--section">
			<div class="main-container">
				<div class="column-primary article-list">
					<?php while ( $blogpostsfour->have_posts() ) : $blogpostsfour->the_post(); ?>
						<?php get_template_part('_partials/archive-default'); ?>
					<?php endwhile; ?>
					<?php brandco_archive_pages(); ?>
				</div>
				<div class="column-aside">
					<?php
						dynamic_sidebar('blog');
					?>
				</div>
			</div>
		</section>
	</main>
<?php get_footer(); ?>
