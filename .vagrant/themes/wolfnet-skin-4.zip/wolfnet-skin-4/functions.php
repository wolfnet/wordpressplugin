<?php
/**
 * @package brandco
 */

require get_template_directory() . '/_setup/init.php';

add_action('wp_head', 'bcore_css');
function bcore_css() {
	?>
		<style>
			.page .has-post-thumbnail .page-header:after {
				display: none;
			}
			.gfield_required {
				color: red;
			}
		</style>
	<?php	
}