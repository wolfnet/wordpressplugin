<?php 
/**
 * Default Page Template
 * @package brandco
 */
get_header(); ?>
	<?php while ( have_posts() ) : the_post(); ?>
		<?php get_template_part('_partials/single', 'default'); ?>
		<?php brandco_post_navigation(); ?>
	<?php endwhile; ?>
<?php get_footer(); ?>
