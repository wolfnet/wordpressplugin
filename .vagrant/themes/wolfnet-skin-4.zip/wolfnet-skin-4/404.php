<?php 
/**
 * 404
 * @package brandco
 */
get_header(); ?>
	<main id="site-main" role="main">

		<header class="page-header">
			<div class="main-container">
				<div class="page-header-container">
					<?php echo sprintf( '<h1 class="page-title">%s</h1>', 'Oops... Page Not Found' ); ?>
				</div>
			</div>
		</header>

		<section id="page-main" class="main-section page-has-aside homepage--section">
			<div class="main-container">
				<div class="column-primary"> 
					<div class="entry-content" itemprop="mainContentOfPage">
						<p>We're sorry, the page you are looking for does not exists.</p>
						<?php if ( has_nav_menu('primary') ): ?>
							<ul>
								<?php wp_nav_menu( array( 
									'theme_location' => 'primary',
									'container' => '',
									'items_wrap' => '%3$s'
								) ); ?>
							</ul>
						<?php endif ?>
					</div>
				</div>
				<div class="column-aside">
					<?php dynamic_sidebar('sidebar-1'); ?>
				</div>
			</div>
		</section>

	</main>

<?php get_footer(); ?>
