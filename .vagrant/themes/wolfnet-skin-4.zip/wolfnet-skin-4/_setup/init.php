<?php

# Setup
require get_template_directory() . '/_setup/structure/setup.php';
require get_template_directory() . '/_setup/structure/scripts-styles.php';
// require get_template_directory() . '/_setup/structure/customizer.php';
require get_template_directory() . '/_setup/structure/schema.php';
require get_template_directory() . '/_setup/structure/cleanup.php';
require get_template_directory() . '/_setup/structure/functions.php';
require get_template_directory() . '/_setup/structure/actions.php';
require get_template_directory() . '/_setup/structure/theme-functions.php';
require get_template_directory() . '/_setup/structure/wnt-community-widget.php';
require get_template_directory() . '/_setup/structure/wnt-contactus-widget.php';
require get_template_directory() . '/_setup/structure/wnt-recentnews-widget.php';

// require get_template_directory() . '/_setup/gform-validation/gravityforms-html5-validation.php';



// require get_template_directory() . '/_setup/structure/subtitle.php';

# Post types
// require get_template_directory() . '/_setup/post-types/communities.php';
// require get_template_directory() . '/_setup/post-types/community-posts.php';


add_action( 'init', 'codex_community_init' );
/**
 * Register a community/area/city post type.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_post_type
 */
function codex_community_init() {
	$labels = array(
		'name'               => _x( 'Communities', 'post type general name', 'your-plugin-textdomain' ),
		'singular_name'      => _x( 'Community', 'post type singular name', 'your-plugin-textdomain' ),
		'menu_name'          => _x( 'Communities', 'admin menu', 'your-plugin-textdomain' ),
		'name_admin_bar'     => _x( 'Community', 'add new on admin bar', 'your-plugin-textdomain' ),
		'add_new'            => _x( 'Add New', 'book', 'your-plugin-textdomain' ),
		'add_new_item'       => __( 'Add New Community', 'your-plugin-textdomain' ),
		'new_item'           => __( 'New Community', 'your-plugin-textdomain' ),
		'edit_item'          => __( 'Edit Community', 'your-plugin-textdomain' ),
		'view_item'          => __( 'View Community', 'your-plugin-textdomain' ),
		'all_items'          => __( 'All Communities', 'your-plugin-textdomain' ),
		'search_items'       => __( 'Search Communities', 'your-plugin-textdomain' ),
		'parent_item_colon'  => __( 'Parent Communities:', 'your-plugin-textdomain' ),
		'not_found'          => __( 'No community found.', 'your-plugin-textdomain' ),
		'not_found_in_trash' => __( 'No community found in Trash.', 'your-plugin-textdomain' )
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'community' ),
		'capability_type'    => 'post',
		'has_archive'        => 'communities',
		'hierarchical'       => false,
		'menu_position'      => null,
		'menu_icon'          => 'dashicons-location-alt',
		'supports'           => array( 'title', 'editor', 'author', 'thumbnail' ),
		'cptp_permalink_structure'     => '/%postname%/'
	);

	register_post_type( 'city', $args );
}

add_action( 'init', 'codex_agent_init' );
/**
 * Register a agent post type.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_post_type
 */
function codex_agent_init() {
	$labels = array(
		'name'               => _x( 'Agents', 'post type general name', 'your-plugin-textdomain' ),
		'singular_name'      => _x( 'Agent', 'post type singular name', 'your-plugin-textdomain' ),
		'menu_name'          => _x( 'Agents', 'admin menu', 'your-plugin-textdomain' ),
		'name_admin_bar'     => _x( 'Agent', 'add new on admin bar', 'your-plugin-textdomain' ),
		'add_new'            => _x( 'Add New', 'book', 'your-plugin-textdomain' ),
		'add_new_item'       => __( 'Add New Agent', 'your-plugin-textdomain' ),
		'new_item'           => __( 'New Agent', 'your-plugin-textdomain' ),
		'edit_item'          => __( 'Edit Agent', 'your-plugin-textdomain' ),
		'view_item'          => __( 'View Agent', 'your-plugin-textdomain' ),
		'all_items'          => __( 'All Agents', 'your-plugin-textdomain' ),
		'search_items'       => __( 'Search Agents', 'your-plugin-textdomain' ),
		'parent_item_colon'  => __( 'Parent Agents:', 'your-plugin-textdomain' ),
		'not_found'          => __( 'No agent found.', 'your-plugin-textdomain' ),
		'not_found_in_trash' => __( 'No agent found in Trash.', 'your-plugin-textdomain' )
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'agent' ),
		'capability_type'    => 'post',
		'has_archive'        => 'agents',
		'hierarchical'       => false,
		'menu_position'      => null,
		'menu_icon'          => 'dashicons-groups',
		'supports'           => array( 'title', 'editor', 'author', 'thumbnail' ),
		'cptp_permalink_structure'     => '/%postname%/'
	);

	register_post_type( 'agent', $args );
}

/**
 * Adds a box to the main column on the Post and Page edit screens.
 */
// function myplugin_add_meta_box_fullwidth() {

// 	$screens = array( 'post', 'page', 'city', 'agent' );

// 	foreach ( $screens as $screen ) {

// 		add_meta_box(
// 			'myplugin_sectionid_fullwidth',
// 			__( 'Full Width', 'myplugin_textdomain_fullwidth' ),
// 			'myplugin_meta_box_callback_fullwidth',
// 			$screen,
// 			'side'
// 		);
// 	}
// }
// add_action( 'add_meta_boxes', 'myplugin_add_meta_box_fullwidth' );

/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current post/page.
 */
// function myplugin_meta_box_callback_fullwidth( $post ) {

// 	wp_nonce_field( 'myplugin_meta_box', 'myplugin_meta_box_nonce' );

// 	post_meta( $post->ID, '_my_meta_value_key_fw', true );

// 	$prfx_stored_meta_fullwidth = get_post_meta( $post->ID );

// 	echo '<label for="meta-checkbox">';
// 	    echo '<input type="checkbox" name="meta-checkbox" id="meta-checkbox" value="yes"';
// 	    if ( isset ( $prfx_stored_meta_fullwidth['meta-checkbox'] ) ) checked( $prfx_stored_meta_fullwidth['meta-checkbox'][0], 'yes' );
// 	    echo '/>';
// 	    _e( 'Checking this hides the sidebar and makes the content full width', 'prfx-textdomain' );
// 	echo '</label>';
// }

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
// function myplugin_save_meta_box_data_fullwidth( $post_id ) {

// 	if ( ! isset( $_POST['myplugin_meta_box_nonce'] ) ) {
// 		return;
// 	}

// 	if ( ! wp_verify_nonce( $_POST['myplugin_meta_box_nonce'], 'myplugin_meta_box' ) ) {
// 		return;
// 	}

// 	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
// 		return;
// 	}

// 	if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {

// 		if ( ! current_user_can( 'edit_page', $post_id ) ) {
// 			return;
// 		}

// 	} else {

// 		if ( ! current_user_can( 'edit_post', $post_id ) ) {
// 			return;
// 		}
// 	}

// 	if ( ! isset( $_POST['meta-checkbox'] ) ) {
// 		return;
// 	}

// 	$my_data = sanitize_text_field( $_POST['meta-checkbox'] );

// 	if( isset( $_POST[ 'meta-checkbox' ] ) ) {
// 		update_post_meta( $post_id, 'meta-checkbox', 'yes' );
// 	} else {
// 		update_post_meta( $post_id, 'meta-checkbox', '' );
// 	}
// }
// add_action( 'save_post', 'myplugin_save_meta_box_data_fullwidth' );

/**
 * Meta box for agent cpt
 */
function myplugin_add_meta_box_agent() {

	$screens = array( 'agent' );

	foreach ( $screens as $screen ) {

		add_meta_box(
			'myplugin_sectionid_agent',
			__( 'Information', 'myplugin_textdomain_agent' ),
			'myplugin_meta_box_callback_agent',
			$screen
		);
	}
}
add_action( 'add_meta_boxes', 'myplugin_add_meta_box_agent' );

/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current agent.
 */
function myplugin_meta_box_callback_agent( $post ) {

	// Add an nonce field so we can check for it later.
	wp_nonce_field( 'myplugin_meta_box', 'myplugin_meta_box_nonce' );

	/*
	 * Use get_post_meta() to retrieve an existing value
	 * from the database and use the value for the form.
	 */
	// global $post;
	// $info = get_post_meta( $post->ID, '_info', true );
	// $info_array = wp_parse_args($info,array('agenttitle' =>'','agentphone' =>'','agentemail' =>'','agentlistings' =>'','agentwebsite' =>'','facebook' => '','twitter' => '','linkedin' => '','featuredlistings' => ''));
	// extract($info_array);

	$value_agenttitle = get_post_meta( $post->ID, '_my_meta_value_key1', true );
	$value_agentphone = get_post_meta( $post->ID, '_my_meta_value_key2', true );
	$value_agentemail = get_post_meta( $post->ID, '_my_meta_value_key3', true );
	$value_agentlistings = get_post_meta( $post->ID, '_my_meta_value_key4', true );
	$value_agentwebsite = get_post_meta( $post->ID, '_my_meta_value_key5', true );
	$value_facebook = get_post_meta( $post->ID, '_my_meta_value_key6', true );
	$value_twitter = get_post_meta( $post->ID, '_my_meta_value_key7', true );
	$value_linkedin = get_post_meta( $post->ID, '_my_meta_value_key8', true );
	$value_featuredlistings = get_post_meta( $post->ID, '_my_meta_value_key9', true );

	echo '<label for="myplugin_new_field1">';
	_e( 'Agent Title', 'myplugin_textdomain1' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field1" name="myplugin_new_field1" value="' . esc_attr( $value_agenttitle ) . '" size="25" />';

	echo '<br />';
	echo '<br />';

	echo '<label for="myplugin_new_field2">';
	_e( 'Agent Phone Number', 'myplugin_textdomain2' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field2" name="myplugin_new_field2" value="' . esc_attr( $value_agentphone ) . '" size="25" />';

	echo '<br />';
	echo '<br />';

	echo '<label for="myplugin_new_field3">';
	_e( 'Agent Email Address', 'myplugin_textdomain3' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field3" name="myplugin_new_field3" value="' . esc_attr( $value_agentemail ) . '" size="25" />';

	echo '<br />';
	echo '<br />';

	echo '<label for="myplugin_new_field4">';
	_e( 'Agent Listings (URL)', 'myplugin_textdomain4' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field4" name="myplugin_new_field4" value="' . esc_attr( $value_agentlistings ) . '" size="25" />';

	echo '<br />';
	echo '<br />';

	echo '<label for="myplugin_new_field5">';
	_e( 'Agent Website (URL)', 'myplugin_textdomain5' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field5" name="myplugin_new_field5" value="' . esc_attr( $value_agentwebsite ) . '" size="25" />';

	echo '<br />';
	echo '<br />';

	echo '<label for="myplugin_new_field6">';
	_e( 'Facebook (URL)', 'myplugin_textdomain6' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field6" name="myplugin_new_field6" value="' . esc_attr( $value_facebook ) . '" size="25" />';

	echo '<br />';
	echo '<br />';

	echo '<label for="myplugin_new_field7">';
	_e( 'Twitter (URL)', 'myplugin_textdomain7' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field7" name="myplugin_new_field7" value="' . esc_attr( $value_twitter ) . '" size="25" />';

	echo '<br />';
	echo '<br />';

	echo '<label for="myplugin_new_field8">';
	_e( 'LinkeIn (URL)', 'myplugin_textdomain8' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field8" name="myplugin_new_field8" value="' . esc_attr( $value_linkedin ) . '" size="25" />';

	echo '<br />';
	echo '<br />';

	echo '<label for="myplugin_new_field9">';
	_e( 'Agent Featured Listings Code', 'myplugin_textdomain9' );
	echo '</label> ';
	echo '<input type="text" id="myplugin_new_field9" name="myplugin_new_field9" value="' . esc_attr( $value_featuredlistings ) . '" size="25" />';

	// global $post;
	// $info = wp_parse_args(get_post_meta($post->ID,'_info',true),array('agenttitle' =>'','agentphone' =>'','agentemail' =>'','agentlistings' =>'','agentwebsite' =>'','facebook' => '','twitter' => '','linkedin' => '','featuredlistings' => ''));
	// extract($info);

	// echo '<input type="hidden" name="' . $this->nonce . '_noncename" id="' . $this->nonce . '_noncename" value="' . wp_create_nonce( __FILE__ ) . '" />';

	// echo '<p><strong>Agent Title</strong><br />';
	// echo '<input type="text" name="info[agenttitle]" value="' . $agenttitle . '" style="width: 100%;" /></p>';

	// echo '<p><strong>Agent Phone Number</strong><br />';
	// echo '<input type="text" name="info[agentphone]" value="' . $agentphone . '" style="width: 100%;" /></p>';

	// echo '<p><strong>Agent Email Address</strong><br />';
	// echo '<input type="text" name="info[agentemail]" value="' . $agentemail . '" style="width: 100%;" /></p>';

	// echo '<p><strong>Agent Listings (URL)</strong><br />';
	// echo '<input type="text" name="info[agentlistings]" value="' . $agentlistings . '" style="width: 100%;" /></p>';

	// echo '<p><strong>Agent Website (URL)</strong><br />';
	// echo '<input type="text" name="info[agentwebsite]" value="' . $agentwebsite . '" style="width: 100%;" /></p>';

	// echo '<p><strong>Facebook (URL)</strong><br />';
	// echo '<input type="text" class="code" name="info[facebook]" value="' . $facebook . '" style="width: 100%;" /></p>';

	// echo '<p><strong>Twitter (URL)</strong><br />';
	// echo '<input type="text" class="code" name="info[twitter]" value="' . $twitter . '" style="width: 100%;" /></p>';

	// echo '<p><strong>LinkedIn (URL)</strong><br />';
	// echo '<input type="text" class="code" name="info[linkedin]" value="' . $linkedin . '" style="width: 100%;" /></p>';

	// echo '<p><strong>Agent Featured Listings Code</strong><br />';
	// echo '<textarea class="code" name="info[featuredlistings]" style="width: 100%;" />' . $featuredlistings . '</textarea><br /><span style="font-size: 10px; font-style: italic;">Get this from ther WNT WP Plugin</span></p>';
}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function myplugin_save_meta_box_data_agent( $post_id ) {

	/*
	 * We need to verify this came from our screen and with proper authorization,
	 * because the save_post action can be triggered at other times.
	 */

	// Check if our nonce is set.
	if ( ! isset( $_POST['myplugin_meta_box_nonce'] ) ) {
		return;
	}

	// Verify that the nonce is valid.
	if ( ! wp_verify_nonce( $_POST['myplugin_meta_box_nonce'], 'myplugin_meta_box' ) ) {
		return;
	}

	// If this is an autosave, our form has not been submitted, so we don't want to do anything.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	// Check the user's permissions.
	if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {

		if ( ! current_user_can( 'edit_page', $post_id ) ) {
			return;
		}

	} else {

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
	}

	/* OK, it's safe for us to save the data now. */

	// Make sure that it is set.
	if ( ! isset( $_POST['myplugin_new_field1'] ) ) {
		return;
	}
	if ( ! isset( $_POST['myplugin_new_field2'] ) ) {
		return;
	}
	if ( ! isset( $_POST['myplugin_new_field3'] ) ) {
		return;
	}
	if ( ! isset( $_POST['myplugin_new_field4'] ) ) {
		return;
	}
	if ( ! isset( $_POST['myplugin_new_field5'] ) ) {
		return;
	}
	if ( ! isset( $_POST['myplugin_new_field6'] ) ) {
		return;
	}
	if ( ! isset( $_POST['myplugin_new_field7'] ) ) {
		return;
	}
	if ( ! isset( $_POST['myplugin_new_field8'] ) ) {
		return;
	}
	if ( ! isset( $_POST['myplugin_new_field9'] ) ) {
		return;
	}

	// Sanitize user input.
	$my_data1 = sanitize_text_field( $_POST['myplugin_new_field1'] );
	$my_data2 = sanitize_text_field( $_POST['myplugin_new_field2'] );
	$my_data3 = sanitize_text_field( $_POST['myplugin_new_field3'] );
	$my_data4 = sanitize_text_field( $_POST['myplugin_new_field4'] );
	$my_data5 = sanitize_text_field( $_POST['myplugin_new_field5'] );
	$my_data6 = sanitize_text_field( $_POST['myplugin_new_field6'] );
	$my_data7 = sanitize_text_field( $_POST['myplugin_new_field7'] );
	$my_data8 = sanitize_text_field( $_POST['myplugin_new_field8'] );
	$my_data9 = sanitize_text_field( $_POST['myplugin_new_field9'] );

	// Update the meta field in the database.
	update_post_meta( $post_id, '_my_meta_value_key1', $my_data1 );
	update_post_meta( $post_id, '_my_meta_value_key2', $my_data2 );
	update_post_meta( $post_id, '_my_meta_value_key3', $my_data3 );
	update_post_meta( $post_id, '_my_meta_value_key4', $my_data4 );
	update_post_meta( $post_id, '_my_meta_value_key5', $my_data5 );
	update_post_meta( $post_id, '_my_meta_value_key6', $my_data6 );
	update_post_meta( $post_id, '_my_meta_value_key7', $my_data7 );
	update_post_meta( $post_id, '_my_meta_value_key8', $my_data8 );
	update_post_meta( $post_id, '_my_meta_value_key9', $my_data9 );

	// update_post_meta($post_id,'_info',$_POST['info']);
}
add_action( 'save_post', 'myplugin_save_meta_box_data_agent' );

/**
 * Adds a box to the main column on the Post and Page edit screens.
 */
function myplugin_add_meta_box_community() {

	$screens = array( 'city' );

	foreach ( $screens as $screen ) {

		add_meta_box(
			'myplugin_sectionid_community',
			__( 'Featured Community Option Foor Footer', 'myplugin_textdomain_community' ),
			'myplugin_meta_box_callback_community',
			$screen,
			'normal',
			'high'
		);
	}
}
add_action( 'add_meta_boxes', 'myplugin_add_meta_box_community' );

/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current post/page.
 */
function myplugin_meta_box_callback_community( $post ) {

	// Add an nonce field so we can check for it later.
	wp_nonce_field( 'myplugin_meta_box', 'myplugin_meta_box_nonce' );

	/*
	 * Use get_post_meta() to retrieve an existing value
	 * from the database and use the value for the form.
	 */
	$prfx_stored_meta = get_post_meta( $post->ID );

	?>
	<p>
	    <span class="prfx-row-title"><?php _e( 'You may select up to twelve communities to be featured in the footer.', 'prfx-textdomain' )?></span>
	    <div class="prfx-row-content">
	        <label for="meta-checkbox">
	            <input type="checkbox" name="meta-checkbox" id="meta-checkbox" value="yes" <?php if ( isset ( $prfx_stored_meta['meta-checkbox'] ) ) checked( $prfx_stored_meta['meta-checkbox'][0], 'yes' ); ?> />
	            <?php _e( 'Featured Community', 'prfx-textdomain' )?>
	        </label>
	    </div>
	    <!-- <div class="prfx-row-content">
	        <label for="meta-checkbox-two">
	            <input type="checkbox" name="meta-checkbox-two" id="meta-checkbox-two" value="yes" <?php if ( isset ( $prfx_stored_meta['meta-checkbox-two'] ) ) checked( $prfx_stored_meta['meta-checkbox-two'][0], 'yes' ); ?> />
	            <?php _e( 'Display this community on phone? Note: Community must also be featured.', 'prfx-textdomain' )?>
	        </label>
	    </div> -->
	</p>
	<?php

}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function myplugin_save_meta_box_data_community( $post_id ) {

	/*
	 * We need to verify this came from our screen and with proper authorization,
	 * because the save_post action can be triggered at other times.
	 */

	// Check if our nonce is set.
	if ( ! isset( $_POST['myplugin_meta_box_nonce'] ) ) {
		return;
	}

	// Verify that the nonce is valid.
	if ( ! wp_verify_nonce( $_POST['myplugin_meta_box_nonce'], 'myplugin_meta_box' ) ) {
		return;
	}

	// If this is an autosave, our form has not been submitted, so we don't want to do anything.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	// Check the user's permissions.
	if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {

		if ( ! current_user_can( 'edit_page', $post_id ) ) {
			return;
		}

	} else {

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
	}

	/* OK, it's safe for us to save the data now. */

	// Checks for input and saves
	if( isset( $_POST[ 'meta-checkbox' ] ) ) {
	    update_post_meta( $post_id, 'meta-checkbox', 'yes' );
	} else {
	    update_post_meta( $post_id, 'meta-checkbox', '' );
	}

	// Checks for input and saves
	if( isset( $_POST[ 'meta-checkbox-two' ] ) ) {
	    update_post_meta( $post_id, 'meta-checkbox-two', 'yes' );
	} else {
	    update_post_meta( $post_id, 'meta-checkbox-two', '' );
	}
}
add_action( 'save_post', 'myplugin_save_meta_box_data_community' );

/**
 * Adds a box to the main column on the Post and Page edit screens.
 */
function myplugin_add_meta_box_pages() {

	$screens = array( 'page' );

	foreach ( $screens as $screen ) {

		add_meta_box(
			'myplugin_sectionid_page',
			__( 'Featured Page (Will Display on Homepage)', 'myplugin_textdomain_community' ),
			'myplugin_meta_box_callback_page',
			$screen,
			'normal',
			'high'
		);
	}
}
// add_action( 'add_meta_boxes', 'myplugin_add_meta_box_pages' );

/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current post/page.
 */
function myplugin_meta_box_callback_page( $post ) {

	// Add an nonce field so we can check for it later.
	wp_nonce_field( 'myplugin_meta_box', 'myplugin_meta_box_nonce' );

	/*
	 * Use get_post_meta() to retrieve an existing value
	 * from the database and use the value for the form.
	 */
	$prfx_stored_meta = get_post_meta( $post->ID );

	?>
	<p>
	    <span class="prfx-row-title"><?php _e( 'Note: Only select 3, 6, 9, 12 featured pages to show up on the homepage. Any additional pages will be hidden.', 'prfx-textdomain' )?></span>
	    <div class="prfx-row-content">
	        <label for="meta-checkbox-homepage">
	            <input type="checkbox" name="meta-checkbox-homepage" id="meta-checkbox-homepage" value="yes" <?php if ( isset ( $prfx_stored_meta['meta-checkbox-homepage'] ) ) checked( $prfx_stored_meta['meta-checkbox-homepage'][0], 'yes' ); ?> />
	            <?php _e( 'Featured Page (Displays this page on the homepage)', 'prfx-textdomain' )?>
	        </label>
	    </div>
	    <div class="prfx-row-content">
	        <label for="meta-checkbox-homepage-two">
	            <input type="checkbox" name="meta-checkbox-homepage-two" id="meta-checkbox-homepage-two" value="yes" <?php if ( isset ( $prfx_stored_meta['meta-checkbox-homepage-two'] ) ) checked( $prfx_stored_meta['meta-checkbox-homepage-two'][0], 'yes' ); ?> />
	            <?php _e( 'Display this page on phone? Note: Page must also be featured.', 'prfx-textdomain' )?>
	        </label>
	    </div>
	</p>
	<?php

}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function myplugin_save_meta_box_data_page( $post_id ) {

	/*
	 * We need to verify this came from our screen and with proper authorization,
	 * because the save_post action can be triggered at other times.
	 */

	// Check if our nonce is set.
	if ( ! isset( $_POST['myplugin_meta_box_nonce'] ) ) {
		return;
	}

	// Verify that the nonce is valid.
	if ( ! wp_verify_nonce( $_POST['myplugin_meta_box_nonce'], 'myplugin_meta_box' ) ) {
		return;
	}

	// If this is an autosave, our form has not been submitted, so we don't want to do anything.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	// Check the user's permissions.
	if ( isset( $_POST['post_type'] ) && 'page' == $_POST['post_type'] ) {

		if ( ! current_user_can( 'edit_page', $post_id ) ) {
			return;
		}

	} else {

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
	}

	/* OK, it's safe for us to save the data now. */

	// Checks for input and saves
	if( isset( $_POST[ 'meta-checkbox-homepage' ] ) ) {
	    update_post_meta( $post_id, 'meta-checkbox-homepage', 'yes' );
	} else {
	    update_post_meta( $post_id, 'meta-checkbox-homepage', '' );
	}

	// Checks for input and saves
	if( isset( $_POST[ 'meta-checkbox-homepage-two' ] ) ) {
	    update_post_meta( $post_id, 'meta-checkbox-homepage-two', 'yes' );
	} else {
	    update_post_meta( $post_id, 'meta-checkbox-homepage-two', '' );
	}
}
add_action( 'save_post', 'myplugin_save_meta_box_data_page' );

/** Start of Remove Date TimeStamp from blog posts */
function remove_post_dates() {

	$classes = get_body_class();
	if ( in_array('single-city', $classes )){
		add_filter('the_time', '__return_false');
		add_filter('get_the_time', '__return_false');
		add_filter('the_modified_time', '__return_false');
		add_filter('get_the_modified_time', '__return_false');
		add_filter('the_date', '__return_false');
		add_filter('get_the_date', '__return_false');
		add_filter('the_modified_date', '__return_false');
		add_filter('get_the_modified_date', '__return_false');
		add_filter('get_comment_date', '__return_false');
		add_filter('get_comment_time', '__return_false');
	}
}
add_action('loop_start', 'remove_post_dates');
/** End of Remove Date TimeStamp from blog posts */

// create city blog post type
if ( ! function_exists('community_posts_custom_post_type') ) {

	// Register Custom Post Type
	function community_posts_custom_post_type() {

		$labels = array(
			'name'                => _x( 'Community Posts', 'Post Type General Name', 'text_domain' ),
			'singular_name'       => _x( 'Community Post', 'Post Type Singular Name', 'text_domain' ),
			'menu_name'           => __( 'Community Posts', 'text_domain' ),
			'name_admin_bar'      => __( 'Community Post', 'text_domain' ),
			'parent_item_colon'   => __( 'Parent Community Post:', 'text_domain' ),
			'all_items'           => __( 'All Community Posts', 'text_domain' ),
			'add_new_item'        => __( 'Add New Community Post', 'text_domain' ),
			'add_new'             => __( 'Add New', 'text_domain' ),
			'new_item'            => __( 'New Community Post', 'text_domain' ),
			'edit_item'           => __( 'Edit Community Post', 'text_domain' ),
			'update_item'         => __( 'Update Community Post', 'text_domain' ),
			'view_item'           => __( 'View Community Post', 'text_domain' ),
			'search_items'        => __( 'Search Community Post', 'text_domain' ),
			'not_found'           => __( 'No Community Post found', 'text_domain' ),
			'not_found_in_trash'  => __( 'No Community Post found in Trash', 'text_domain' ),
		);
		$rewrite = array(
			'slug'                => 'community',
			'with_front'          => true,
			'pages'               => true,
			'feeds'               => true,
		);
		$args = array(
			'label'               => __( 'city_post', 'text_domain' ),
			'description'         => __( 'This section is for writing blog posts about your communities', 'text_domain' ),
			'labels'              => $labels,
			'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', ),
			// 'taxonomies'          => array( 'category', 'post_tag' ),
			'hierarchical'        => false,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'menu_position'       => 5,
			'show_in_admin_bar'   => true,
			'show_in_nav_menus'   => true,
			'can_export'          => true,
			'has_archive'         => true,
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'rewrite'             => $rewrite,
			'capability_type'     => 'post',
			'cptp_permalink_structure'     => '/%communities%/%postname%/',
		);
		register_post_type( 'city_post', $args );

	}

	// Hook into the 'init' action
	add_action( 'init', 'community_posts_custom_post_type', 0 );

}

// communities taxonomy
function create_community_post_tax_wolfnet_instant_sites() {
	register_taxonomy(
		'communities',
		'city_post',
		array(
			'show_in_nav_menus'   => false,
			'label' => __( 'Communities' ),
			'rewrite' => array( 'slug' => 'communities' ),
			'hierarchical' => true,
			'show_admin_column' => true,
			'show_in_quick_edit' => false,
		)
	);
}
add_action( 'init', 'create_community_post_tax_wolfnet_instant_sites' );

// create taxonomy on every page load
function create_categories_based_on_city() {
	$allcityposts = array( 'post_type' => 'city', 'posts_per_page' => -1 );
	$allcitypostslist = get_posts( $allcityposts );
	foreach ( $allcitypostslist as $post ) : setup_postdata( $post ); ?>
		<?php
		$city_parents_wolf_instant_tax = get_post_ancestors( $post->ID );
		if( $city_parents_wolf_instant_tax == null ) {
			wp_insert_term(
				esc_html( $post->post_title ),
				'communities',
				array(
					'description'	=> 'This is a category for linking up community posts with its community.',
					'slug' 		=> basename( get_permalink( $post->ID ) )
				)
			);
		}
		?>
	<?php endforeach;
	wp_reset_postdata();
}
add_action( 'admin_footer', 'create_categories_based_on_city' );

function wolfnet_instantsites_customizer( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	// Images
	$wp_customize->add_section( 'images' , array(
		'title' => __( 'Custom Images', '_s' ),
		'priority' => 29,
		'description' => __( 'Brand your site with custom images.', '_s' )
	));

	$wp_customize->add_setting( 'remove_photo_filter' , array( 'default' => ''));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'remove_photo_filter', array(
		'label' => __( 'Remove Photo Filter', '_s' ),
		'section' => 'images',
		'settings' => 'remove_photo_filter',
		'type' => 'checkbox',
	)));

	// $wp_customize->add_setting( 'headerimage' , array( 'default' => '' ));
	// $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'headerimage', array(
	// 	'label' => __( 'Add header image to the website.', '_s' ),
	// 	'section' => 'images',
	// 	'settings' => 'headerimage',
	// )));

	$wp_customize->add_setting( 'logofavicon' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'logofavicon', array(
		'label' => __( 'Website Favicon (Must be .png or .ico format. Suggested dimentions: 32x32.)', '_s' ),
		'section' => 'images',
		'settings' => 'logofavicon',
		'extensions' => array( 'png', 'ico' )
	)));

	// $wp_customize->add_setting( 'SiteFavicon' , array( 'default' => '', 'type' => 'option' ));
	// $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'SiteFavicon', array(
	// 	'label' => __( 'Site Favicon', '_s' ),
	// 	'section' => 'images',
	// 	'settings' => 'SiteFavicon',
	// )));

	$wp_customize->add_setting( 'logom' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'logom', array(
		'label' => __( 'Main Logo (Suggested dimentions: 354x180)', '_s' ),
		'section' => 'images',
		'settings' => 'logom',
	)));
	// $wp_customize->add_setting( 'logob' , array( 'default' => '' ));
	// $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'logob', array(
	// 	'label' => __( 'Brokerage Logo (Suggested dimentions: 143x40)', '_s' ),
	// 	'section' => 'images',
	// 	'settings' => 'logob',
	// )));
	$wp_customize->add_setting( 'imageheader' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'imageheader', array(
		'label' => __( 'Header Image (Required width of 1920px and height of 624px, otherwise your image will stretch)', '_s' ),
		'section' => 'images',
		'settings' => 'imageheader',
	)));
	$wp_customize->add_setting( 'imageheader2' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'imageheader2', array(
		'label' => __( 'Header Image 2 {optional} (Required width of 1920px and height of 624px, otherwise your image will stretch)', '_s' ),
		'section' => 'images',
		'settings' => 'imageheader2',
	)));
	$wp_customize->add_setting( 'imageheader3' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'imageheader3', array(
		'label' => __( 'Header Image 3 {optional} (Required width of 1920px and height of 624px, otherwise your image will stretch)', '_s' ),
		'section' => 'images',
		'settings' => 'imageheader3',
	)));
	$wp_customize->add_setting( 'secondaryimage' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'secondaryimage', array(
		'label' => __( 'Secondary Image', '_s' ),
		'section' => 'images',
		'settings' => 'secondaryimage',
	)));

	// Social
	$wp_customize->add_section( 'social' , array(
		'title' => __( 'Social Media', '_s' ),
		'priority' => 30,
		'description' => __( 'Please enter the full urls of all your social networks with http:// in the front of each them.', '_s' )
	));

	$wp_customize->add_setting( 'tw' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'tw', array(
		'label' => __( 'Twitter', '_s' ),
		'section' => 'social',
		'settings' => 'tw',
	)));

	$wp_customize->add_setting( 'pin' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'pin', array(
		'label' => __( 'Pinterest', '_s' ),
		'section' => 'social',
		'settings' => 'pin',
	)));

	$wp_customize->add_setting( 'in' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'in', array(
		'label' => __( 'LinkedIn', '_s' ),
		'section' => 'social',
		'settings' => 'in',
	)));

	$wp_customize->add_setting( 'insta' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'insta', array(
		'label' => __( 'Instagram', '_s' ),
		'section' => 'social',
		'settings' => 'insta',
	)));

	$wp_customize->add_setting( 'gp' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'gp', array(
		'label' => __( 'Google+', '_s' ),
		'section' => 'social',
		'settings' => 'gp',
	)));

	$wp_customize->add_setting( 'fb' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'fb', array(
		'label' => __( 'Facebook', '_s' ),
		'section' => 'social',
		'settings' => 'fb',
	)));
	
	$wp_customize->add_setting( 'yt' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'yt', array(
		'label' => __( 'YouTube', '_s' ),
		'section' => 'social',
		'settings' => 'yt',
	)));

	// $wp_customize->add_setting( 'headerimage' , array( 'default' => '' ));
	// $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'headerimage', array(
	// 	'label' => __( 'Main Header Image (We suggest that you use the biggest photo you can find)', '_s' ),
	// 	'section' => 'logo',
	// 	'settings' => 'headerimage',
	// )));

	// Homepage
	$wp_customize->add_section( 'homepage' , array(
		'title' => __( 'Homepage Settings', '_s' ),
		'priority' => 32,
		'description' => __( 'These are the settings for the websites homepage.', '_s' )
	));

	$wp_customize->add_setting( 'smartsearch' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'smartsearch', array(
		'label' => __( 'Use Regular Quick Search?', '_s' ),
		'section' => 'homepage',
		'settings' => 'smartsearch',
		'type' => 'checkbox',
	)));

	$wp_customize->add_setting( 'homequicksearchdisplay' , array( 'default' => ''));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homequicksearchdisplay', array(
		'label' => __( 'Hide Quick Search', '_s' ),
		'section' => 'homepage',
		'settings' => 'homequicksearchdisplay',
		'type' => 'checkbox',
	)));

	$wp_customize->add_setting( 'homeqsshortcode' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homeqsshortcode', array(
		'label' => __( 'Quick Search Shortcode Override', '_s' ),
		'description' => __('You may place a manual shortcode here if you have more than one MLS area key. Please note that placing a shortcode here will invalidate the checkboxes above.'),
		'section' => 'homepage',
		'settings' => 'homeqsshortcode',
	)));

	$wp_customize->add_setting( 'homequicksearchtitle' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homequicksearchtitle', array(
		'label' => __( 'Quick Search Title {optional}', '_s' ),
		'section' => 'homepage',
		'settings' => 'homequicksearchtitle',
	)));



	$wp_customize->add_setting( 'wnt__FeaturedPage01' , array( 'default' => '', 'type' => 'option' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'wnt__FeaturedPage01', array(
		'label' => 'Homepage call to action buttons (3)',
		'description' => 'Select pages to feature. These will display below the quick search.',
		'section' => 'homepage',
		'settings' => 'wnt__FeaturedPage01',
		'type' => 'dropdown-pages'
	)));

	$wp_customize->add_setting( 'wnt__FeaturedPage02' , array( 'default' => '', 'type' => 'option' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'wnt__FeaturedPage02', array(
		'label' => '',
		'description' => '',
		'section' => 'homepage',
		'settings' => 'wnt__FeaturedPage02',
		'type' => 'dropdown-pages'
	)));

	$wp_customize->add_setting( 'wnt__FeaturedPage03' , array( 'default' => '', 'type' => 'option' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'wnt__FeaturedPage03', array(
		'label' => '',
		'description' => '',
		'section' => 'homepage',
		'settings' => 'wnt__FeaturedPage03',
		'type' => 'dropdown-pages'
	)));

	$wp_customize->add_setting( 'wnt_about__title' , array( 'type' => 'option' ));
	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'wnt_about__title',
			array(
				'label' => 'About Section: Title',
				'section' => 'homepage',
				'settings' => 'wnt_about__title',
				'post_type' => 'agent'
			)
		)
	);

	$wp_customize->add_setting( 'wnt_about__subtitle' , array( 'type' => 'option' ));
	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'wnt_about__subtitle',
			array(
				'label' => 'About Section: Subtitle',
				'section' => 'homepage',
				'settings' => 'wnt_about__subtitle',
				'post_type' => 'agent'
			)
		)
	);

	$wp_customize->add_setting( 'wnt_about__description' , array( 'type' => 'option' ));
	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'wnt_about__description',
			array(
				'label' => 'About Section: Short Excerpt',
				'section' => 'homepage',
				'settings' => 'wnt_about__description',
				'type' => 'textarea'
			)
		)
	);

	$wp_customize->add_setting( 'wnt_about__image' , array( 'type' => 'option' ));
	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			'wnt_about__image',
			array(
				'label' => 'About Section: Image',
				'section' => 'homepage',
				'settings' => 'wnt_about__image',
			)
		)
	);

	$wp_customize->add_setting( 'wnt_about__link' , array( 'type' => 'option' ));
	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'wnt_about__link',
			array(
				'label' => 'About Section: Link',
				'section' => 'homepage',
				'settings' => 'wnt_about__link',
			)
		)
	);

	$wp_customize->add_setting( 'homefeatured-title' , array( 'default' => '', 'type' => 'option' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homefeatured-title', array(
		'label' => __( 'Wolfnet Featured Listings: Title', '_s' ),
		'section' => 'homepage',
		'settings' => 'homefeatured-title',
	)));

	$wp_customize->add_setting( 'homefeatured' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homefeatured', array(
		'label' => __( 'Wolfnet Featured Listings: Shortcode', '_s' ),
		'section' => 'homepage',
		'settings' => 'homefeatured',
	)));


	$wp_customize->add_setting( 'homefeatured-readmore' , array( 'default' => '', 'type' => 'option' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homefeatured-readmore', array(
		'label' => __( 'Wolfnet Featured Listings: View More Button Link', '_s' ),
		'section' => 'homepage',
		'settings' => 'homefeatured-readmore',
	)));

	$wp_customize->add_setting( 'wnt_gravity_form_title' , array( 'default' => '', 'type' => 'option' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'wnt_gravity_form_title', array(
		'label' => __( 'Contact Form Title', '_s' ),
		'section' => 'homepage',
		'settings' => 'wnt_gravity_form_title',
	)));

	$wp_customize->add_setting( 'wnt_gravity_form' , array( 'type' => 'option' ));
	$wp_customize->add_control(
	    new WP_Customize_Gravity_Forms(
	        $wp_customize,
	        'wnt_gravity_form',
	        array(
				'label' => __( 'Select A Contact Form', 'mytheme' ),
				'section' => 'homepage',
				'settings' => 'wnt_gravity_form'
	        )
	    )
	);

	$wp_customize->add_setting( 'wnt_gravity_form_2' , array( 'type' => 'option' ));
	$wp_customize->add_control(
	    new WP_Customize_Gravity_Forms(
	        $wp_customize,
	        'wnt_gravity_form_2',
	        array(
				'label' => __( 'Select a Home Value Form', 'mytheme' ),
				'description' => 'Must only be 1 field for Address',
				'section' => 'homepage',
				'settings' => 'wnt_gravity_form_2'
	        )
	    )
	);

	// $wp_customize->add_setting( 'advancedsearchlink' , array( 'default' => '' ));
	// $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'advancedsearchlink', array(
	// 	'label' => __( 'Search By Map Link {optional}', '_s' ),
	// 	'section' => 'homepage',
	// 	'settings' => 'advancedsearchlink',
	// )));

	// $wp_customize->add_setting( 'searchbygallerylink' , array( 'default' => '' ));
	// $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'searchbygallerylink', array(
	// 	'label' => __( 'Search By Gallery Link {optional}', '_s' ),
	// 	'section' => 'homepage',
	// 	'settings' => 'searchbygallerylink',
	// )));

	// $wp_customize->add_setting( 'searchbylistlinks' , array( 'default' => '' ));
	// $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'searchbylistlinks', array(
	// 	'label' => __( 'Search By List Link {optional}', '_s' ),
	// 	'section' => 'homepage',
	// 	'settings' => 'searchbylistlinks',
	// )));



	// $wp_customize->add_setting( 'wnt__HomeQuickSearchCode' , array( 'default' => '', 'type' => 'option' ));
	// $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'wnt__HomeQuickSearchCode', array(
	// 	'label' => __( 'Wolfnet Quick Search Shortcode', '_s' ),
	// 	'section' => 'homepage',
	// 	'settings' => 'wnt__HomeQuickSearchCode',
	// )));

	// $wp_customize->add_setting( 'homefeatured2' , array( 'default' => '' ));
	// $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homefeatured2', array(
	// 	'label' => __( 'Featured Properties Section 2 {optional} (Please enter your custom WolfNet Featured Listings shortcode)', '_s' ),
	// 	'section' => 'homepage',
	// 	'settings' => 'homefeatured2',
	// )));
	// $wp_customize->add_setting( 'homefeatured2_title' , array( 'default' => '' ));
	// $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homefeatured2_title', array(
	// 	'label' => __( 'Featured Properties Section 2 Title {optional}', '_s' ),
	// 	'section' => 'homepage',
	// 	'settings' => 'homefeatured2_title',
	// )));

	// $wp_customize->add_setting( 'homefeaturedtitle' , array( 'default' => '' ));
	// $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homefeaturedtitle', array(
	// 	'label' => __( 'Featured Properties Title', '_s' ),
	// 	'section' => 'homepage',
	// 	'settings' => 'homefeaturedtitle',
	// )));

	// $wp_customize->add_setting( 'homegravityform' , array( 'default' => '' ));
	// $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'homegravityform', array(
	// 	'label' => __( 'Paste Gravity Forms Shortcode', '_s' ),
	// 	'section' => 'homepage',
	// 	'settings' => 'homegravityform',
	// )));

	//Communities
	$wp_customize->add_section( 'communities' , array(
		'title' => __( 'Communities Settings', '_s' ),
		'priority' => 33,
		'description' => __( 'These are the settings for the communities pages.', '_s' )
	));

	$wp_customize->add_setting( 'communitiesfull' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'communitiesfull', array(
		'label' => __( 'Full width property view (off or on).', '_s' ),
		'section' => 'communities',
		'settings' => 'communitiesfull',
		'type' => 'checkbox',
	)));
	$wp_customize->add_setting( 'communitiestitle' , array( 'default' => '' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'communitiestitle', array(
		'label' => __( 'Communities Title', '_s' ),
		'section' => 'communities',
		'settings' => 'communitiestitle',
	)));

	// footer
	$wp_customize->add_section( 'footer' , array(
		'title' => __( 'Header/Footer', '_s' ),
		'priority' => 34,
		'description' => __( '', '_s' )
	));

	// $wp_customize->add_setting( 'fname' , array( 'default' => '' ));
	// $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'fname', array(
	// 	'label' => __( 'Your Name', '_s' ),
	// 	'section' => 'footer',
	// 	'settings' => 'fname',
	// )));

	// $wp_customize->add_setting( 'frname' , array( 'default' => '' ));
	// $wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'frname', array(
	// 	'label' => __( 'Realty Name', '_s' ),
	// 	'section' => 'footer',
	// 	'settings' => 'frname',
	// )));

	$wp_customize->add_setting( 'fphoned' , array( 'default' => '', 'type' => 'option' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'fphoned', array(
		'label' => __( 'Phone Number', '_s' ),
		'section' => 'footer',
		'settings' => 'fphoned',
	)));

	$wp_customize->add_setting( 'femail' , array( 'default' => '', 'type' => 'option' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'femail', array(
		'label' => __( 'Email Address', '_s' ),
		'section' => 'footer',
		'settings' => 'femail',
	)));

	$wp_customize->add_setting( 'wlf__officeAddress' , array( 'default' => '', 'type' => 'option' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'wlf__officeAddress', array(
		'label' => __( 'Office Address', '_s' ),
		'section' => 'footer',
		'settings' => 'wlf__officeAddress',
	)));

	$wp_customize->add_setting( 'wlf__Login' , array( 'default' => '', 'type' => 'option' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'wlf__Login', array(
		'label' => __( 'Login Link', '_s' ),
		'section' => 'footer',
		'settings' => 'wlf__Login',
	)));

	$wp_customize->add_setting( 'wlf__Register' , array( 'default' => '', 'type' => 'option' ));
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'wlf__Register', array(
		'label' => __( 'Register Link', '_s' ),
		'section' => 'footer',
		'settings' => 'wlf__Register',
	)));

	// Color Scheme
	// $wp_customize->add_section( 'color' , array(
	// 	'title' => __( 'Color Scheme', '_s' ),
	// 	'priority' => 34,
	// 	'description' => __( 'Choose a primary and secondary color for your site to give it a custom feel.', '_s' )
	// ));

	$wp_customize->add_setting( 'cprimary' , array( 'default' => '0380cd' ));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cprimary', array(
		'label' => __( 'Theme Color', '_s' ),
		'section' => 'colors',
		'settings' => 'cprimary',
	)));

	$wp_customize->add_setting( 'button_color' , array( 'default' => 'CC7300' ));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'button_color', array(
		'label' => __( 'Button Color', '_s' ),
		'section' => 'colors',
		'settings' => 'button_color',
	)));

		$wp_customize->add_setting( 'cta_button' , array( 'default' => '0380cd' ));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cta_button', array(
		'label' => __( 'Circle Colors', '_s' ),
		'section' => 'colors',
		'settings' => 'cta_button',
	)));

	// $wp_customize->add_setting( 'cprimary_text' , array( 'default' => 'FFFFFF' ));
	// $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cprimary_text', array(
	// 	'label' => __( 'Header Text Color', '_s' ),
	// 	'section' => 'colors',
	// 	'settings' => 'cprimary_text',
	// )));

	$wp_customize->add_setting( 'csecondary_text' , array( 'default' => 'FFFFFF' ));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'csecondary_text', array(
		'label' => __( 'Footer Text Color', '_s' ),
		'section' => 'colors',
		'settings' => 'csecondary_text',
	)));

	$wp_customize->add_setting( 'csecondary' , array( 'default' => '858585' ));
	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'csecondary', array(
		'label' => __( 'Footer Background Color', '_s' ),
		'section' => 'colors',
		'settings' => 'csecondary',
	)));

}
add_action( 'customize_register', 'wolfnet_instantsites_customizer' );


if( class_exists( 'WP_Customize_Control' ) ):
	class WP_Customize_Featured_Agent extends WP_Customize_Control {
		public $type = 'latest_post_dropdown';
		public $post_type = 'agent';

		public function render_content() {

		$latest = new WP_Query( array(
			'post_type'   => $this->post_type,
			'post_status' => 'publish',
			'posts_per_page' => -1,
			'orderby'     => 'date',
			'order'       => 'DESC'
		));

		?>
			<label>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<select <?php $this->link(); ?>>
					<option value="0"> -- Pick one</option>
					<?php
					while( $latest->have_posts() ) {
						$latest->the_post();
						echo "<option " . selected( $this->value(), get_the_ID() ) . " value='" . get_the_ID() . "'>" . the_title( '', '', false ) . "</option>";
					}
					?>
				</select>
			</label>
		<?php
		}
	}
endif;


if ( class_exists('WP_Customize_Control') && class_exists('GFAPI') ) :
	class WP_Customize_Gravity_Forms extends WP_Customize_Control {
		public function render_content() {

			$forms = GFAPI::get_forms();

			?>
				<label>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
					<select <?php $this->link(); ?>>
						<option value="0"> -- Pick one</option>
						<?php
							foreach ( $forms as $form ) {
								echo "<option " . selected( $this->value(), $form['id'] ) . " value='" . $form['id'] . "'>" . $form['title'] . "</option>";
							}
						?>
					</select>
				</label>
			<?php

		}
	}
endif;

function wnt_random_header_image() {
	$images = array();

	if ( get_theme_mod('imageheader') )
		$images[]['image'] = get_theme_mod('imageheader');

	if ( get_theme_mod('imageheader2') )
		$images[]['image'] = get_theme_mod('imageheader2');

	if ( get_theme_mod('imageheader3') )
		$images[]['image'] = get_theme_mod('imageheader3');

	if ($images) {
		$rand = array_rand( $images );
		return $images[$rand]['image'];
	}
}

add_action('wp_footer', 'wnt_header_fixed_background');
function wnt_header_fixed_background() {
	if ( wnt_random_header_image() && !is_front_page() ) {
		?>

		<style>
			.page-header:after {
				content: "";
				background-image: url('<?php echo wnt_random_header_image(); ?>');
				background-attachment: fixed;
				background-size: cover;
				-webkit-background-size: cover;
				-ms-background-size: cover;
				background-position: 50%;
			}
		</style>

		<?php
	}
}

add_action('wp_footer', 'wnt_fixed_background');
function wnt_fixed_background() {

	$image = get_theme_mod('secondaryimage');
	if (is_page() && has_post_thumbnail()) {
		$image = bco_featured_image_url();
	}

	if (is_single() && has_post_thumbnail()) {
		$image = bco_featured_image_url();
	}
	if ( $image ) ?>
		<style>
			html:not([data-bcowolf="true"]) body:after {
				content: "";
				background-image: url('<?php echo $image; ?>');
				background-size: cover;
				-webkit-background-size: cover;
				-ms-background-size: cover;
				background-position: 50%;
				position: fixed;
				top: 0;
				left: 0;
				right: 0;
				bottom: 0;
				z-index: -10;
			}
		</style>
	<?php
}

add_action('wp_head', 'wnt_apply_primary_color');
function wnt_apply_primary_color() {
	$color = get_theme_mod('cprimary');
	$cta_button = get_theme_mod('cta_button');
	$footer_background = get_theme_mod('csecondary');
	$footer_text = get_theme_mod('csecondary_text');
	$buttons = get_theme_mod('button_color');
	$remove_photo_filter = get_theme_mod('remove_photo_filter');

	if ( $buttons ) {
		?>
			<style>
				.paging-container .page-numbers.current,
				.wntPrimaryColor--button,
				.entry-content a:hover,
				#header-links a,
				#masthead #menu-toggle, .mobile-close a {
					color: <?php echo $buttons; ?> !important;
				}

				.wnt-close-btn {
					color: <?php echo $buttons; ?> !important;
				}

				svg path { fill: <?php echo $buttons; ?> !important; }

				#module--agentspotlight .agent-contact-buttons a,
				#header-links .header--contact-item i
				{
					color: #fff !important;
					background-color: <?php echo $buttons; ?> !important;
				}

				input[type=submit],
				.wolfnet_quickSearchForm_submitButton,
				.wolfnet_smartSearchForm_submitButton {
					background-color: <?php echo $buttons; ?> !important;
					border-color: <?php echo $buttons; ?> !important;
				}

				.module--viewmore,
				#masthead #menu-toggle {
					border-color: <?php echo $buttons; ?> !important;
					color: <?php echo $buttons; ?> !important;
				}

				.module--viewmore:hover {
					background-color: <?php echo $buttons; ?> !important;
					color: #fff !important;
				}
			</style>
		<?php
	}

	if ( $footer_background ) {
		?>
			<style>
				#footer--body { background-color: <?php echo $footer_background; ?> !important; }
			</style>
		<?php
	}

	if ( $footer_text ) {
		?>
			<style>
				#footer--body { color: <?php echo $footer_text; ?> !important; }
				#footer--body a { color: <?php echo $footer_text; ?> !important; }
				#footer--body svg path { fill: <?php echo $footer_text; ?> !important; }
			</style>
		<?php
	}

	if ($cta_button) : ?>

		<style>
			#module--quicklinks .quicklink--button{
				background-color: <?php echo $cta_button; ?> !important;
			}
			#colophon .gform_wrapper form .gform_body .gfield_label{
				color: <?php echo $cta_button; ?> !important;
			}
		</style>

	<?php endif;

	if( $remove_photo_filter): ?>
		<style>
			#module--quicksearch, .page-header:before{
				background-color: transparent;
			}
		</style>

	<?php endif;

	if ( $color ) : ?>
		<style>

			.wntPrimaryColor--text,
			#footer--body a:hover,
			.entry-content h1,
			.entry-content h2,
			.entry-content h3,
			.entry-content h4,
			.entry-content h5,
			.entry-content h6,
			.sidebar-widget a:hover,
			.widget-title,
			.article-list>.article-link .single-title,
			.module--title-firstwordjs
			 {
				color: <?php echo $color; ?> !important;
			}

			.bco-landing-pages--box .gform_heading,
			#main-navigation,
			.wntPrimaryColor--background {
				background-color: <?php echo $color; ?> !important;
			}

			@media (min-width: 750px) {
				#module--quicksearch.quicksearch--ToggleActive-L #quicksearch--ToggleL { background-color: <?php echo $color; ?> !important; }
				#module--quicksearch.quicksearch--ToggleActive-R #quicksearch--ToggleR { background-color: <?php echo $color; ?> !important; }
			}

			#module--quicksearch.quicksearch--ToggleActive-R #quicksearch--ToggleR span,
			#module--quicksearch.quicksearch--ToggleActive-L #quicksearch--ToggleL span {
				background-color: <?php echo $color; ?> !important;
				border-color: <?php echo $color; ?> !important;
			}

			#module--featuredlistings .wolfnet_widget.wolfnet_featuredListings .wolfnet_listing .wolfnet_bed_bath+span:after,
			#module--featuredlistings .wolfnet_widget.wolfnet_listingGrid .wolfnet_listing .wolfnet_bed_bath+span:after {
				background-color: <?php echo $color; ?> !important;
			}

		</style>
	<?php endif;
}

add_action('init', 'wnt_disable_gform_css');
function wnt_disable_gform_css() {
	update_option('rg_gforms_disable_css', 1);
	update_option('rg_gforms_enable_html5', 1);
}

add_filter( 'wpseo_metabox_prio', function() { return 'low';});
add_filter("gform_confirmation_anchor", create_function("","return false;"));

/**
 * Add "first" and "last" CSS classes to dynamic sidebar widgets. Also adds numeric index class for each widget (widget-1, widget-2, etc.)
 */
function widget_first_last_classes($params) {

	global $my_widget_num; // Global a counter array
	$this_id = $params[0]['id']; // Get the id for the current sidebar we're processing
	$arr_registered_widgets = wp_get_sidebars_widgets(); // Get an array of ALL registered widgets

	if(!$my_widget_num) {// If the counter array doesn't exist, create it
		$my_widget_num = array();
	}

	if(!isset($arr_registered_widgets[$this_id]) || !is_array($arr_registered_widgets[$this_id])) { // Check if the current sidebar has no widgets
		return $params; // No widgets in this sidebar... bail early.
	}

	if(isset($my_widget_num[$this_id])) { // See if the counter array has an entry for this sidebar
		$my_widget_num[$this_id] ++;
	} else { // If not, create it starting with 1
		$my_widget_num[$this_id] = 1;
	}

	if ( $this_id = 'footer-widgets-bcore' ) {
		$class = 'class="footer-widget--' . $my_widget_num[$this_id] . '_' . count($arr_registered_widgets[$this_id]) . ' '; // Add a widget number class for additional styling options
	}
	else{
		$class = 'class="widget--' . $my_widget_num[$this_id] . '_' . count($arr_registered_widgets[$this_id]) . ' '; // Add a widget number class for additional styling options
	}


	if($my_widget_num[$this_id] == 1) { // If this is the first widget
		$class .= 'widget-first ';
	} elseif($my_widget_num[$this_id] == count($arr_registered_widgets[$this_id])) { // If this is the last widget
		$class .= 'widget-last ';
	}

	$params[0]['before_widget'] = str_replace('class="', $class, $params[0]['before_widget']); // Insert our new classes into "before widget"

	return $params;

}
add_filter('dynamic_sidebar_params','widget_first_last_classes');

if( function_exists('acf_add_local_field_group') ):

acf_add_local_field_group(array (
	'key' => 'group_577b1660cf12f',
	'title' => 'Communities',
	'fields' => array (
		array (
			'key' => 'field_577b167f02976',
			'label' => 'Featured?',
			'name' => 'featured',
			'type' => 'checkbox',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array (
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'choices' => array (
			),
			'default_value' => array (
			),
			'layout' => 'vertical',
			'toggle' => 0,
		),
	),
	'location' => array (
		array (
			array (
				'param' => 'post_type',
				'operator' => '==',
				'value' => 'community',
			),
		),
	),
	'menu_order' => 1000,
	'position' => 'normal',
	'style' => 'default',
	'label_placement' => 'top',
	'instruction_placement' => 'label',
	'hide_on_screen' => '',
	'active' => 1,
	'description' => '',
));

endif;

add_filter('wpseo_enable_xml_sitemap_transient_caching', '__return_false');
