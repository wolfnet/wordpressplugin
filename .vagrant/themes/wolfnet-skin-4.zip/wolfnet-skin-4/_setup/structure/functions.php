<?php
/**
 * @package brandco
 */

# Get page title
// function bco_page_title() {
// 	return get_the_title();
// }

/**
 * Trim the_content() and add permalink with '... Read More'
 * @global <?php the_trimmed_content($wordcount, $readmoretext); ?>
*/
function the_trimmed_content( $wordcount = 30, $readmoretext = 'Read More') {
	$content = get_the_content();
	$trimmed_content = wp_trim_words( $content, $wordcount, '... <a href="'. get_permalink() .'" class="tc-read-more">' . $readmoretext . '</a>' );
	echo wpautop($trimmed_content);
}

/**
 * Trim the_content() and add permalink with '... Read More'
 * @global <?php the_trimmed_content($wordcount, $readmoretext); ?>
*/
function get_content_by_length( $wordcount = 30, $readmoretext = 'Read More') {
	$content = strip_shortcodes( get_the_content() );
	$trimmed_content = wp_trim_words( $content, $wordcount, '... <span class="read-more-text">Read More</span>' );
	return $trimmed_content;
}

# Get archive title
function bco_archive_title() {
	if ( is_home() ) {
		if ( get_option('page_for_posts', true) ) {
			return get_the_title( get_option( 'page_for_posts', true ) );
		} else {
			return 'Latest Posts';
		}
	} elseif ( is_post_type_archive() ) {
		if ( get_theme_mod( 'page_for_' . get_post_type() ) ) {
			return get_the_title( get_theme_mod( 'page_for_' . get_post_type() ) );
		} else {
			return get_the_archive_title();
		}
	} else {
		return get_the_archive_title();
	}
}

# From single page, get it's post type's title
function get_single_post_type_title() {
	if ( get_theme_mod('page_for_' . get_post_type() ) ) {
		$title = get_the_title( get_theme_mod('page_for_' . get_post_type() ) );
	} else {
		$obj = get_post_type_object( get_post_type() );
		$title = $obj->labels->name;
	}
	return $title;
}

# Get single title
// function bco_single_title() {
// 	return get_the_title();
// }

# Take images in the_content out of p tags
add_filter('the_content', 'brandco_filter_ptags_on_images');
function brandco_filter_ptags_on_images( $content ) {
	return preg_replace('/<p>\s*(<a .*>)?\s*(<img .* \/>)\s*(<\/a>)?\s*<\/p>/iU', '\1\2\3', $content);
}

# Get logo src from customizer
add_action('after_setup_theme', 'brandco_get_logo');
function brandco_get_logo() {
	return get_theme_mod('company_logo');
}

# Get featured image url
function bco_featured_image_url() {
	if ( has_post_thumbnail() ) {
		$url = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) );
		return $url;
	}
}

# Get featured image url
function bco_featured_image_url_by_id( $id ) {
	if ( has_post_thumbnail( $id ) ) {
		$url = wp_get_attachment_url( get_post_thumbnail_id( $id ) );
		return $url;
	}
}

# Finds the src of the first image in the post content
function bco_first_img_src() {
	$html = get_the_content();
	$dom = new domDocument;
	$dom->loadHTML($html);
	$dom->preserveWhiteSpace = false;
	$images = $dom->getElementsByTagName('img');
	$i = 0;
	foreach ( $images as $image ) {
		if ( $i != 0 ) {
			break;
		}
		return $image->getAttribute('src');
		$i++;
	}
}

# Set menu_order default value to make it easier to sort later (since default is 0)
add_filter( 'wp_insert_post_data', 'brandco_default_menu_order' );
function brandco_default_menu_order( $data ) {
	if ( $data['post_status'] == 'auto-draft' ) {
		$data['menu_order'] = 999;
	}
	return $data;
}

# Use this function when registering post types - to sort by menu_order
function add_menu_order_column( $columns ) {
	$columns['menu_order'] = __( 'Order', 'bcore' );
	return $columns;
}

# Use this function when registering post types - to sort by menu_order
function show_menu_order_column( $name ) {
	global $post;
	switch ($name) {
		case 'menu_order':
		$order = $post->menu_order;
		echo $order;
		break;
		default:
		break;
	}
}

# Use this function when registering post types - to sort by menu_order
function menu_order_column_register_sortable( $columns ){
	$columns['menu_order'] = 'menu_order';
	return $columns;
}

# Post type archive page labels
# If a Page is chosen in the Customizer,
# this adds a label on the Page's admin page
add_filter( 'display_post_states', 'custom_post_type_state' );
function custom_post_type_state( $states ) {
	global $post;
	$custom_post_types = get_post_types( array( '_builtin' => false ) );
	foreach ( $custom_post_types as $type ) {
		$details = get_post_type_object( $type );
		$label = $details->label;

		if ( $post->ID == get_theme_mod( 'page_for_' . $type ) ) {
			return array(  $label . ' Page' );
		}
	}
	return $states;
}

# Post navigation
function brandco_post_navigation() {
	echo '<div id="brandco-post-navigation">';
	echo next_post_link( "%link", "<span>Read next: </span> %title <i class=\"fa fa-long-arrow-right \"></i>" );
	echo previous_post_link( "%link", "<i class=\"fa fa-long-arrow-left \"></i> <span>Read previous: </span> %title" );
	echo '</div>';
}

# Login page stuff
add_filter( 'login_headerurl', 'brandco_login_logo_link' );
add_action( 'login_enqueue_scripts', 'brandco_login_logo' );

function brandco_login_logo_link() {
    return home_url();
}

function brandco_login_logo() {
	if ( brandco_get_logo() ) :
	?>
		<style type="text/css">
			.login h1 a {
				background-image: url('<?php echo brandco_get_logo(); ?>');
				padding-bottom: 30px;
				background-size: auto 100%;
				margin: 0;
				width: 100%;
			}
	    </style>
	<?php endif;
	return true;
}

# Open graph meta
add_action('wp_head', 'brandco_og_meta');
function brandco_og_meta() {
	$output = '';
	$output .= '<meta property="og:site_name" content="' . get_bloginfo('title') . '"/>';
	if ( has_post_thumbnail() ) {
		$output .= '<meta property="og:image" content="' . bco_featured_image_url() . '"/>';
	}
	if ( brandco_get_logo() ) {
		echo '<meta property="og:image" content="' . brandco_get_logo() . '"/>';
	}
	if ( is_front_page() ) {
		$output .= '<meta property="og:title" content="' . get_bloginfo('title') . '"/>';
		$output .= '<meta property="og:description" content="' . get_bloginfo('description') . '"/>';
	} elseif ( is_page() || is_single() ) {
		$output .= '<meta property="og:title" content="' . get_the_title() . '"/>';
	} elseif ( is_home() || is_archive() ) {
		$output .= '<meta property="og:title" content="' . bco_archive_title() . '"/>';
	}
	echo $output;
}

# Social media array
function brandco_social_media() {
	$fb = get_theme_mod('social_media_facebook');
	$tw = get_theme_mod('social_media_twitter');
	$gp = get_theme_mod('social_media_googleplus');
	$li = get_theme_mod('social_media_linkedin');
	$pn = get_theme_mod('social_media_pinterest');
	$ig = get_theme_mod('social_media_instagram');

	$links = array();

	if ( $fb ) { $links[] = array( $fb, 'fa-facebook', 'Facebook' ); }
	if ( $tw ) { $links[] = array( $tw, 'fa-twitter', 'Twitter' ); }
	if ( $gp ) { $links[] = array( $gp, 'fa-google-plus', 'Google Plus' ); }
	if ( $li ) { $links[] = array( $li, 'fa-linkedin', 'LinkedIn' ); }
	if ( $pn ) { $links[] = array( $pn, 'fa-pinterest', 'Pinterest' ); }
	if ( $ig ) { $links[] = array( $ig, 'fa-instagram', 'Instagram' ); }

	foreach ( $links as $link ) {
		echo '<a href="' . $link[0] . '" target="_blank" class="social-media-link"><i class="fa ' . $link[1] . '"></i><span class="screen-reader-text">Click to find us on ' . $link[2] . '</span></a>';
	}
}

# Gallery settings
add_filter( 'shortcode_atts_gallery',
	function( $out ){
		$out['link'] = 'file';
		$out['size'] = 'large';
		return $out;
	}
);

# Get content from selected archive page
function brandco_archive_content() {
	$page_id = get_theme_mod('page_for_' . get_post_type() );
	$page_content = get_post_field( 'post_content', $page_id );
	echo apply_filters( 'the_content', $page_content );
}
function brandco_has_archive_content() {
	$page_id = get_theme_mod('page_for_' . get_post_type() );
	$page_content = get_post_field( 'post_content', $page_id );
	if ( $page_content ) {
		return true;
	} else {
		return false;
	}
}

# Get image from selected archive page
# Use:
/**
*	<?php if ( brandco_has_archive_image() ): ?>
*		<img src="<?php brandco_archive_image(); ?>" alt="<?php echo bco_archive_title(); ?> Archive">
*	<?php endif ?>
*/
function brandco_archive_image() {
	if ( is_home() ) {
		$page_id = get_option( 'page_for_posts' );
		$image = bco_featured_image_url_by_id( $page_id );
		echo $image;
	} else {
		$page_id = get_theme_mod( 'page_for_' . get_post_type() );
		$image = bco_featured_image_url_by_id( $page_id );
		echo $image;
	}
}

function brandco_has_archive_image() {
	if ( is_home() ) {
		$page_id = get_option( 'page_for_posts' );
		$image = bco_featured_image_url_by_id( $page_id );
		if ( $image ) {
			return true;
		} else {
			return false;
		}
	} else {
		$page_id = get_theme_mod('page_for_' . get_post_type() );
		$image = bco_featured_image_url_by_id( $page_id );
		if ( $image ) {
			return true;
		} else {
			return false;
		}
	}
}


function bco_category_list( $sep = '' ) {
	$list = get_the_category();
	foreach ( $list as $category ) {
		if ( $category === end($list) ) {
			echo '<span>' . $category->name . '</span>';
		} else {
			echo '<span>' . $category->name . $sep . '</span>';
		}
	}
}

add_action('wp_footer', 'brandco_google_analytics');
function brandco_google_analytics() {
	$id = get_theme_mod('google_analytics');
	if ( $id ) :
	echo "
		<script>
			(function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
			function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
			e=o.createElement(i);r=o.getElementsByTagName(i)[0];
			e.src='https://www.google-analytics.com/analytics.js';
			r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
			ga('create','" . $id . "','auto');ga('send','pageview');
		</script>
 	";
 	endif;
}

function brandco_archive_pages() {
	global $wp_query;
	$big = 999999999;
	$translated = __( 'Page', 'brandco' );
	echo '<div class="paging-container">';
	echo paginate_links( array(
		'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
		'format' => '?paged=%#%',
		'current' => max( 1, get_query_var('paged') ),
		'total' => $wp_query->max_num_pages,
			'before_page_number' => '<span class="screen-reader-text">'.$translated.' </span>'
	) );
	echo '</div>';
}

/**
 * Parallax
 */
function place_parallax_data() {
	echo 'data-bottom-top="transform: translateY(-350px);" data-top-bottom="transform: translateY(0px);"';
}
