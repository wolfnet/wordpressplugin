<?php 
/**
 * @package brandco
 */ 

add_action( 'customize_register', 'brandco_customizer' );
function brandco_customizer( $wp_customize ) {

	# Settings
	$wp_customize->add_setting( 'company_logo' );
	$wp_customize->add_setting( 'company_address' );
	$wp_customize->add_setting( 'company_location' );
	$wp_customize->add_setting( 'company_phone' );
	$wp_customize->add_setting( 'company_email' );
	$wp_customize->add_setting( 'social_media_facebook' );
	$wp_customize->add_setting( 'social_media_twitter' );
	$wp_customize->add_setting( 'social_media_googleplus' );
	$wp_customize->add_setting( 'social_media_linkedin' );
	$wp_customize->add_setting( 'social_media_pinterest' );
	$wp_customize->add_setting( 'social_media_instagram' );
	$wp_customize->add_setting( 'google_analytics' );

	# Controls
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'company_logo', array(
		'label' => __( 'Upload Company Logo', 'brandco' ),
		'section' => 'title_tagline',
		'settings' => 'company_logo',
		'description' => 'Your logo will be placed in the header of the website.'
	))); 
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'company_address', array(
		'label' => __( 'Company Address', 'brandco' ),
		'section' => 'company_info',
		'settings' => 'company_address'
	))); 
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'company_location', array(
		'label' => __( 'Company Location', 'brandco' ),
		'section' => 'company_info',
		'settings' => 'company_location'
	))); 
	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'company_phone', array(
		'label' => __( 'Company Phone Number', 'brandco' ),
		'section' => 'company_info',
		'settings' => 'company_phone'
	))); 

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'company_email', array(
		'label' => __( 'Company Email Address', 'brandco' ),
		'section' => 'company_info',
		'settings' => 'company_email'
	))); 

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'social_media_facebook', array(
		'label' => __( 'Facebook Link', 'brandco' ),
		'section' => 'social_media',
		'settings' => 'social_media_facebook'
	))); 

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'social_media_twitter', array(
		'label' => __( 'Twitter Link', 'brandco' ),
		'section' => 'social_media',
		'settings' => 'social_media_twitter'
	))); 

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'social_media_googleplus', array(
		'label' => __( 'Google Plus Link', 'brandco' ),
		'section' => 'social_media',
		'settings' => 'social_media_googleplus'
	))); 

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'social_media_linkedin', array(
		'label' => __( 'LinkedIn Link', 'brandco' ),
		'section' => 'social_media',
		'settings' => 'social_media_linkedin'
	))); 

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'social_media_pinterest', array(
		'label' => __( 'Pinterest Link', 'brandco' ),
		'section' => 'social_media',
		'settings' => 'social_media_pinterest'
	))); 

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'social_media_instagram', array(
		'label' => __( 'Instagram Link', 'brandco' ),
		'section' => 'social_media',
		'settings' => 'social_media_instagram'
	))); 

	$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'google_analytics', array(
		'label' => __( 'Google Analytics UA-XXXXX-X ID', 'brandco' ),
		'section' => 'website_setup',
		'settings' => 'google_analytics'
	))); 

	# Sections
	$wp_customize->add_section( 'company_info' , array(
		'title' => __( 'Company Details', 'brandco' ),
		'priority' => 30
	));

	$wp_customize->add_section( 'social_media' , array(
		'title' => __( 'Social Media', 'brandco' ),
		'priority' => 30
	));

	# Sections
	$wp_customize->add_section( 'website_setup' , array(
		'title' => __( 'Website Setup Options', 'brandco' ),
		'priority' => 30
	));

	# For each regsitered post type (not builtin), add a setting to pick a page
	# Refresh permalinks when a page is selected to set that post type archive slug as the chosen page.
	# The archive slug will override the page slug, so the archive will display instead of that page.
	$custom_post_types = get_post_types( array( '_builtin' => false, 'public' => true ) );
	foreach ( $custom_post_types as $type ) {
		$details = get_post_type_object( $type );
		$label = $details->label;
		$wp_customize->add_setting( 'page_for_' . $type );
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'page_for_' . $type, array(
			'label' => __( $label . ' Archive Page', 'bcore' ),
			'section' => 'static_front_page',
			'settings' => 'page_for_' . $type,
			'type' => 'dropdown-pages'
		))); 
	}

}




