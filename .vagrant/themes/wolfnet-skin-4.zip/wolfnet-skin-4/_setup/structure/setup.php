<?php
/**
 * @package brandco
 */

if ( ! function_exists( 'brandco_theme_setup' ) ) :
	add_action( 'after_setup_theme', 'brandco_theme_setup' );
	function brandco_theme_setup() {
		$content_width = 960;
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );
		register_nav_menus( array(
			'primary' => esc_html__( 'Main Navigation', 'brandco' ),
			'mobile' => esc_html__( 'Mobile Navigation', 'brandco' ),
			// 'footer' => esc_html__( 'Footer Links', 'brandco' )
		) );
	}
endif;

function brandco_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Default Sidebar', 'bcore' ),
		'id'            => 'sidebar-1',
		'before_widget' => '<div id="%1$s" class="sidebar-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h1 class="widget-title module--title-firstwordjs">',
		'after_title'   => '</h1>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widgets', 'bcore' ),
		'id'            => 'footer-widgets-bcore',
		'before_widget' => '<div id="footer-widget--%1$s" class="footer-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 class="footer-widget--title">',
		'after_title'   => '</h2>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Communities Sidebar', 'bcore' ),
		'id'            => 'sidebar-2',
		'before_widget' => '<div id="%1$s" class="sidebar-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h1 class="widget-title module--title-firstwordjs">',
		'after_title'   => '</h1>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Blog Sidebar', 'bcore' ),
		'id'            => 'blog',
		'before_widget' => '<div id="%1$s" class="sidebar-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h1 class="widget-title module--title-firstwordjs">',
		'after_title'   => '</h1>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Buyers Sidebar', 'bcore' ),
		'id'            => 'buyers',
		'before_widget' => '<div id="%1$s" class="sidebar-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h1 class="widget-title module--title-firstwordjs">',
		'after_title'   => '</h1>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Sellers Sidebar', 'bcore' ),
		'id'            => 'sellers',
		'before_widget' => '<div id="%1$s" class="sidebar-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h1 class="widget-title module--title-firstwordjs">',
		'after_title'   => '</h1>',
	) );
}
add_action( 'widgets_init', 'brandco_widgets_init' );
