<?php

function register_wnt_recentnews_widget() {
    register_widget( 'WNT_RecentNews_Widget' );
}
add_action( 'widgets_init', 'register_wnt_recentnews_widget' );

class WNT_RecentNews_Widget extends WP_Widget {

	function __construct() {
		parent::__construct(
			'recent',
			'Recent News',
			array(
				'description' => 'Displays your latest blog posts'
			)
		);
	}

	public function widget( $args, $instance ) {

		echo $args['before_widget'];

		echo $args['before_title'] . apply_filters( 'widget_title', 'Recent News' ). $args['after_title'];
		?>
				<?php
          $query__RecentNews = new WP_Query(
      			array(
      				'post_type' => 'post',
      				'post_status' => 'publish',
      				'posts_per_page' => 2
      			)
      		);
          ?>

          <!-- <div id="footer-widget--recentnews" class="footer-widget footer-widget--1_3">
    				<h2 class="footer-widget--title">Recent News</h2> -->
    				<?php while ( $query__RecentNews->have_posts() ) : $query__RecentNews->the_post(); ?>
    					<a href="<?php echo get_permalink(); ?>">
    						<?php echo sprintf( '<h3>%s</h3>', get_the_title() ); ?>
    						<?php echo sprintf( '<p>%s</p>', get_content_by_length(6) ); ?>
    					</a>
    				<?php endwhile; wp_reset_postdata(); ?>
    			<!-- </div> -->

			<?php
		echo $args['after_widget'];
	}

}
