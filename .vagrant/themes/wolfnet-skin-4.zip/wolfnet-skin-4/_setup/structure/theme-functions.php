<?php 
/**
 * @package brandco
 *
 * Functions list 
 * ==============
 * brandco\functions\date()
 * brandco\functions\categories(', ')
 * brandco\functions\headline()
 *
 */ 

namespace brandco\functions;

function date() {
	$default_date = get_the_date();
	$formatted_date = get_the_date("Y-m-d H:i:s");
	$date = "<time datetime='{$formatted_date}' class='article-date published' itemprop='datePublished'>{$default_date}</time>";
	return $date;
}

function categories($sep = null) {
	$list = get_the_category();
	foreach ( $list as $category ) {
		if ( $category === end( $list ) ) {
			echo '<span class="category" itemprop="keywords">' . $category->name . '</span>';
		} else {
			echo '<span class="category" itemprop="keywords">' . $category->name . $sep . '</span>';
		}
	}
}

function headline() {
	global $post;
	$title = $post->post_title;
	return $title;
}
