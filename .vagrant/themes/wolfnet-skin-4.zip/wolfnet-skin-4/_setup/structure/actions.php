<?php
/**
 * @package brandco
 */


/**
 * https://developers.google.com/structured-data/customize/overview
 */
add_action('wp_footer', 'bco_insert_structured_data');
function bco_insert_structured_data() {
	$fb = get_theme_mod('social_media_facebook');
	$tw = get_theme_mod('social_media_twitter');
	$gp = get_theme_mod('social_media_googleplus');
	$li = get_theme_mod('social_media_linkedin');
	$pn = get_theme_mod('social_media_pinterest');
	$ig = get_theme_mod('social_media_instagram');
	$logo = get_theme_mod('company_logo');
	$phone = get_theme_mod('company_phone');
	?>
	<script type="application/ld+json">
		{
			"@context": "http://schema.org",
			"@type": "Organization",
			"url": "<?php bloginfo('url'); ?>",
			<?php if ( $logo ) : ?>
			"logo": "<?php echo $logo; ?>", 
			<?php endif; ?>
			<?php if ( $phone ) : ?>
			"contactPoint" : [{
				"@type" : "ContactPoint",
				"telephone" : "<?php echo $phone; ?>",
				"contactType" : "customer service"
			}],
			<?php endif; ?>
			"sameAs" : [
				<?php 
					if ( $fb ) { echo '"' . $fb . '", '; }
					if ( $tw ) { echo '"' . $tw . '", '; }
					if ( $gp ) { echo '"' . $gp . '", '; }
					if ( $li ) { echo '"' . $li . '", '; }
					if ( $pn ) { echo '"' . $pn . '", '; }
					if ( $ig ) { echo '"' . $ig . '", '; }

				?>
			]
		},
		{
			"@context" : "http://schema.org",
			"@type" : "WebSite",
			"name" : "<?php bloginfo('title'); ?>",
			"alternateName" : "<?php bloginfo('description'); ?>",
			"url" : "<?php bloginfo('url'); ?>"
		}
	</script>
	<?php
}
