<?php 
/**
 * @package brandco
 */

function brandco_schema_tag() {
	$schema = 'http://schema.org/';
	$type = 'WebPage';
	if ( is_singular( 'post' ) ) {
		$type 	= 'Article';
	}
	elseif ( is_author() ) {
		$type 	= 'ProfilePage';
	}
	elseif ( is_search() ) {
		$type 	= 'SearchResultsPage';
	}
	echo 'itemscope="itemscope" itemtype="' . esc_attr( $schema ) . esc_attr( $type ) . '"';
}
