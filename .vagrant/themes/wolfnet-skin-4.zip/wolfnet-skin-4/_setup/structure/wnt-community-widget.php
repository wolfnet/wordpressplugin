<?php

function register_wnt_communities_widget() {
    register_widget( 'WNT_Communities_Widget' );
}
add_action( 'widgets_init', 'register_wnt_communities_widget' );

class WNT_Communities_Widget extends WP_Widget {

	function __construct() {
		parent::__construct(
			'wnt_communities_widget',
			'List of Communities',
			array(
				'description' => 'Displays a list of communities.'
			)
		);
	}

	public function widget( $args, $instance ) {

		// function custom_excerpt_length( $length ) {
		// 	return 33;
		// }
		// add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );
    //
		// function new_excerpt_more( $more ) {
		// 	return ' <a class="read-more" href="' . get_permalink( get_the_ID() ) . '">' . 'Read More' . '</a>';
		// }
		// add_filter( 'excerpt_more', 'new_excerpt_more' );

		echo $args['before_widget'];

		echo $args['before_title'] . apply_filters( 'widget_title', 'Our Communities' ). $args['after_title'];


		$query__Communities = new WP_Query(
			array(
				'post_type' => 'city',
				'post_status' => 'publish',
				'posts_per_page' => 12
			)
		);
		// echo '<ul>';
		// while ( $recent_posts->have_posts() ) :
		// $recent_posts->the_post();
		?>

  </h2>
  <?php while ( $query__Communities->have_posts() ) : $query__Communities->the_post(); ?>
    <a href="<?php echo get_permalink(); ?>"><?php echo get_the_title(); ?></a>
    <?php endwhile; wp_reset_postdata(); ?>
			<!-- <li class="posts-widget--single">
				<a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a>
			</li> -->
		<?php
		// endwhile;
		// wp_reset_postdata();
		// echo '</ul>';
		echo $args['after_widget'];
	}

}
