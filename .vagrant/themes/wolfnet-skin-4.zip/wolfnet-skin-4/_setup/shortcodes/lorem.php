<?php 
/**
 * @package larryjohnson
 */

if ( ! function_exists('larryjohnson_lorem_shortcode') ) {
	add_shortcode( 'lj_lorem', 'larryjohnson_lorem_shortcode' );
	function larryjohnson_lorem_shortcode( $atts ) {
		echo <<<EOT
			<p>Larry Demetric Johnson (born March 14, 1969) is a retired American basketball player who spent his professional career in the National Basketball Association (NBA) with the Charlotte Hornets and New York Knicks. He played the power forward position due to his strength.</p>
			<h2>Early career</h2>
			<p>In his senior year of high school Johnson was a member of the 1987 McDonald's High School All-American Team that also included future NCAA and NBA stars like Marcus Liberty, Elliot Perry, Mark Macon, Rodney Monroe, Dennis Scott, Elmore Spencer, Chris Corchiani, and fellow Texas prep star LaBradford Smith. Johnson originally made a verbal commitment to Southern Methodist University, but began his collegiate career at Odessa College in Texas. He played in the 1987–88 and 1988–89 seasons where he averaged 22.3 points per game as a freshman and over 29 points per game his sophomore year, and became the first—and to this day, only—player ever to win the National Junior College Athletic Association Division 1 Player of the Year award both years he played. There were even some basketball analysts who believed Johnson could have been a first round selection in the 1989 NBA Draft (even a possible NBA lottery selection) if he had declared for early entry.[1]</p>
			<h2>Professional career</h2>
			<h3>Charlotte Hornets</h3>
			<p>Johnson was selected first overall in the 1991 NBA Draft by the Charlotte Hornets, and won the NBA Rookie of the Year Award in his first season. He also competed in the 1992 Slam Dunk Contest at the NBA All-Star Weekend in Orlando, finishing second to Cedric Ceballos of the Phoenix Suns.</p>
			<p>In 1993, Johnson was voted to start in that year's All-Star Game, making him the first Hornet in franchise history to receive that honor; he enjoyed his best statistical season with averages of 22.1 points per game and 10.5 rebounds per game in 82 games, which earned him All-NBA second team honors. Along with Alonzo Mourning, Muggsy Bogues and Dell Curry, Johnson played with the Hornets at the height of their popularity in the early to mid-1990s. During this time, Johnson, who went by his initialism "LJ" and the nickname "Grandmama" (because of a popular series of commercials for Converse, who signed Johnson to an endorsement contract following his entry into the NBA), was featured on the cover of the premiere issue of SLAM Magazine.</p>
			<h3>New York Knicks</h3>
			<p>Johnson averaged 12.8 points, a career-low, in his first season as a Knick, and although he would never return to his former All-Star form, he was a key member of the Knicks' 1999 Eastern Conference championship team.<p>
			<p>During Game 3 of the Eastern Conference Finals, he was involved in a critical play in which he was fouled by Antonio Davis of the Indiana Pacers. Standing outside the three-point line with 11.9 seconds left, Johnson held the ball, and then began to dribble. He leaned into defender Davis before jumping up. The referee called the foul about a half-second before Johnson released the ball, but it was counted as a continuation shooting foul. Johnson made the shot and converted the free throw following the basket for a four-point play, which turned out to be the winning margin in a 92-91 Knicks victory.</p>
			<p>During the 1999 NBA Finals, Johnson characterized the Knicks as a band of "rebellious slaves." Bill Walton later called Johnson and his performance a "disgrace." When Johnson was asked about the play of San Antonio Spurs point guard Avery Johnson in Game 4, Johnson again shifted the topic to slavery: "Ave, man, we're from the same plantation. You tell Bill Walton that. We from Massa Johnson's plantation."[7] He went on to say, "Here's the NBA, full of blacks, great opportunities, they made beautiful strides. But what's the sense of that ... when I go back to my neighborhood and see the same thing? I'm the only one who came out of my neighborhood. Everybody ended up dead, in jail, on drugs, selling drugs. So I'm supposed to be honored and happy or whatever by my success. Yes, I am. But I can't deny the fact of what has happened to us over years and years and years and we're still at the bottom of the totem pole."[7]</p>
			<p>On October 10, 2001, Johnson announced his early retirement from basketball due to chronic back problems that had plagued him for several years, after his point production had decreased for three straight years.[8]</p>
EOT;
	}
}


