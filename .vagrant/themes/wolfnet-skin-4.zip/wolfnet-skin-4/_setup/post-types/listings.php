<?php 
/**
 * @package brandco
 */

add_action( 'init', 'register_post_type_listings' );
function register_post_type_listings() {

	$menu_name = 'Listings';
	$regular_name = 'Listings';
	$singular_name = 'Listing';
	$register_name = 'listings';
	$icon = 'dashicons-location-alt';

	$labels = array(
		'name'               => _x( $regular_name, 'post type general name', 'brandco' ),
		'singular_name'      => _x( $singular_name, 'post type singular name', 'brandco' ),
		'menu_name'          => _x( $menu_name, 'admin menu', 'brandco' ),
		'name_admin_bar'     => _x( $singular_name, 'add new on admin bar', 'brandco' ),
		'add_new'            => _x( 'Add New', $register_name, 'brandco' ),
		'add_new_item'       => __( 'Add New ' . $singular_name, 'brandco' ),
		'new_item'           => __( 'New ' . $singular_name, 'brandco' ),
		'edit_item'          => __( 'Edit ' . $singular_name, 'brandco' ),
		'view_item'          => __( 'View ' . $singular_name, 'brandco' ),
		'all_items'          => __( 'All ' . $regular_name, 'brandco' ),
		'search_items'       => __( 'Search ' . $regular_name, 'brandco' ),
		'parent_item_colon'  => __( 'Parent ' . $regular_name . ':', 'brandco' ),
		'not_found'          => __( 'No ' . $regular_name . ' found.', 'brandco' ),
		'not_found_in_trash' => __( 'No ' . $regular_name . ' found in Trash.', 'brandco' )
	);

	# There is a customizer option to choose a Page. 
	# If a Page is chosen, refresh the permalinks to 
	# use that page's slug for this custom post type
	$theme_mod_id = get_theme_mod( 'page_for_' . $register_name );
	if ( $theme_mod_id ) {
		global $post;
		$slug_by_id = get_post( $theme_mod_id )->post_name;
		$slug = array( 'slug' => $slug_by_id );
	} else {
		$slug = array( 'slug' => $register_name );
	}

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => $slug,
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'menu_icon'			 => $icon,
		'supports'           => array( 'title', 'editor', 'page-attributes', 'thumbnail'  )
	);
	register_post_type( $register_name, $args );
}

add_filter( 'pre_get_posts', 'pre_get_posts_listings' );
function pre_get_posts_listings( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) return;
	if ( is_post_type_archive( 'listings' ) ) {
		$query->set( 'orderby', 'menu_order' );
		$query->set( 'order', 'ASC' );
		return $query;
	}
}

/** 
 * Add column for menu order in backend
 * To extend:  manage_edit-posttype_ ...
 */ 
add_filter('manage_edit-listings_columns', 'add_menu_order_column');
add_filter('manage_edit-listings_sortable_columns','menu_order_column_register_sortable');	
add_action('manage_listings_posts_custom_column','show_menu_order_column');









