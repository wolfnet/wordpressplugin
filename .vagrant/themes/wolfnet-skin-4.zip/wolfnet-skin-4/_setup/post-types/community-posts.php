<?php 
/**
 * @package brandco
 */




add_action( 'init', 'register_city_post_taxonomy', 0 );
function register_city_post_taxonomy() {
	register_taxonomy(
		'communities', 
		'city_post', 
		array(
			'labels' => array(
				'name'          => 'Communities',	
				'singular_name' => 'Community News',	
				'search_items'  => 'Search Communities',	
				'edit_item'     => 'Edit Community',	
				'add_new_item'  => 'Add New Community'
			),	
			'hierarchical' => true,
			'show_ui' => true,
			'show_admin_column' => true,
			'query_var' => true,	
			'rewrite' => array(
				'slug' => 'community/communities', 
				'with_front' => false
			)
		)
	); 
}

add_action( 'init', 'register_post_type_city_post' );
function register_post_type_city_post() {

	$menu_name = 'Community Posts';
	$regular_name = 'Community Posts';
	$singular_name = 'Community Post';
	$register_name = 'city_post';
	$icon = 'dashicons-format-status';

	$labels = array(
		'name'               => _x( $regular_name, 'post type general name', 'brandco' ),
		'singular_name'      => _x( $singular_name, 'post type singular name', 'brandco' ),
		'menu_name'          => _x( $menu_name, 'admin menu', 'brandco' ),
		'name_admin_bar'     => _x( $singular_name, 'add new on admin bar', 'brandco' ),
		'add_new'            => _x( 'Add New', $register_name, 'brandco' ),
		'add_new_item'       => __( 'Add New ' . $singular_name, 'brandco' ),
		'new_item'           => __( 'New ' . $singular_name, 'brandco' ),
		'edit_item'          => __( 'Edit ' . $singular_name, 'brandco' ),
		'view_item'          => __( 'View ' . $singular_name, 'brandco' ),
		'all_items'          => __( 'All ' . $regular_name, 'brandco' ),
		'search_items'       => __( 'Search ' . $regular_name, 'brandco' ),
		'parent_item_colon'  => __( 'Parent ' . $regular_name . ':', 'brandco' ),
		'not_found'          => __( 'No ' . $regular_name . ' found.', 'brandco' ),
		'not_found_in_trash' => __( 'No ' . $regular_name . ' found in Trash.', 'brandco' )
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite' => array( 
			'slug' => 'community/%communities%',
			'with_front' => false
		),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => true,
		'menu_position'      => null,
		'menu_icon'			 => $icon,
		'supports'           => array( 'title', 'editor', 'page-attributes', 'thumbnail'  )
	);
	register_post_type( $register_name, $args );
}

add_filter('post_link', 'community_posts_type_permalink', 1, 3);
add_filter('post_type_link', 'community_posts_type_permalink', 1, 3);

function community_posts_type_permalink( $permalink, $post_id, $leavename ) {

	$post = get_post( $post_id );

	if ( strpos( $permalink, '%communities%' ) === FALSE || 'city_post' != get_post_type( $post ) ) {
		return $permalink; 
	}

	if ( ! $post ) {
		return $permalink;
	}

	$terms = wp_get_object_terms( $post->ID, 'communities' );

	if ( ! is_wp_error( $terms ) && ! empty( $terms ) && is_object( $terms[0] ) ) {
		$taxonomy_slug = $terms[0]->slug;
	} else {
		$taxonomy_slug = 'no-community';
	}

    return str_replace( '%communities%', $taxonomy_slug, $permalink );
}






