<a href="<?php echo get_permalink(); ?>" id="link-<?php the_ID(); ?>" <?php post_class( 'article-link' ); ?>>
	<?php echo sprintf( '<h2 class="single-title" itemprop="headline">%s</h2>', brandco\functions\headline() ); ?>
	<?php if ( is_home() ) : ?>
		<p class="article-details">
			<?php echo brandco\functions\date(); ?>
			<?php brandco\functions\categories(', '); ?>
		</p>
		<?php echo sprintf( '<p class="single-excerpt entry-summary">%s</p>', get_the_excerpt() ); ?>
	<?php endif; ?>
</a>
