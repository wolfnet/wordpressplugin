<?php
/**
 * Template Part: Default Single
 * http://microformats.org/wiki/class-names
 * @package brandco
 */
?>
<?php
$post_for_query = get_post($post_id);
$query_tax_slug = $post_for_query->post_name;

$citypostsargs = array(
	'post_type' => 'city_post',
	'posts_per_page' => -1,
	'tax_query' => array(
		array(
			'taxonomy' => 'communities',
			'field'    => 'slug',
			'terms'    => $query_tax_slug,
		),
	),
);
$cityposts = new WP_Query( $citypostsargs ); ?>

<main id="site-main" role="main">
	<article id="page-<?php the_ID(); ?>" <?php post_class(); ?>>
		<header class="page-header">
			<div class="main-container">
				<div class="page-header-container">
					<?php echo sprintf( '<h1 class="page-title entry-title module--title-firstwordjs" itemprop="headline">%s</h1>', brandco\functions\headline() ); ?>
				</div>
			</div>
		</header>

		<section id="page-main" class="main-section page-has-aside homepage--section">
			<div class="main-container">
				<div <?php if ( is_singular('city') && get_theme_mod('communitiesfull') > 0 ) : ?>class="column-full"<?php else : ?>class="column-primary"<?php endif; ?>>

					<div class="entry-content" itemprop="mainContentOfPage">

						<?php if ( is_singular('agent') ) : ?>
							<div class="agent-single--details">
								<?php if ( has_post_thumbnail() ) : ?>
									<a href="<?php echo get_permalink(); ?>" class="agent-single--image">
										<?php the_post_thumbnail('medium'); ?>
									</a>
								<?php endif; ?>

								<?php echo sprintf( '<h4 class="page-title entry-title module--title-firstwordjs" itemprop="headline">%s</h4>', brandco\functions\headline() ); ?>

								<div class="agent-single--contact">
									<?php
										$agent_phone = get_post_meta( get_the_ID(), '_my_meta_value_key2', true );
										$agent_email = get_post_meta( get_the_ID(), '_my_meta_value_key3', true );

										if ( $agent_phone )
											echo '<a href="tel:' . $agent_phone . '" class="agent-contact--tel"><i class="fa fa-phone"></i> <span>' . $agent_phone . '</span></a>';

										if ( $agent_email )
											echo '<a href="mailto:' . antispambot($agent_email) . '" class="agent-contact--mail"><i class="fa fa-envelope"></i> <span>Email</span></a>';

									?>
								</div>
							</div>
						<?php endif; ?>

						<?php
							the_content();

							wp_link_pages( array(
								'before' => '<div class="post-links">' . __( 'Pages:', 'brandco' ),
								'after'  => '</div>',
							) );

							if ( comments_open() || get_comments_number() ) :
								comments_template();
							endif;
						?>


					</div>
				</div>

				<div class="column-aside">
					<?php
						if ( is_singular('city') ) {
							dynamic_sidebar('sidebar-2');
						}

						else if ( is_singular('post') )
							dynamic_sidebar('blog');

						else
							dynamic_sidebar('sidebar-1');
					?>
				</div>

				<?php //if ( is_singular('city') && get_theme_mod('communitiesfull') == 1 ) : ?>
				<?php if ( is_singular('city')) : ?>
					<style>
				@media (max-width: 850px) {
					.community-single-nf {
						width: 50% !important;
					}
				}
				@media (max-width: 600px) {
					.community-single-nf {
						width: 100% !important;
					}
				}
			</style>
				<?php
							// Dispaly Community Posts
							if ( $cityposts->have_posts() ) {
								echo '<h1 style="text-transform: uppercase;">' . get_the_title() . ' News Feed</h1>';
								echo '<ul style="list-style:none;margin:0;">';
								while ( $cityposts->have_posts() ) {
									$cityposts->the_post();
									echo '<li class="community-single-nf" style="width:33.33%;float:left;padding-right:30px;margin-top:35px;margin-bottom:50px;">';
										echo '<h2 style="text-transform: uppercase;"><a href="' . get_the_permalink( $cityposts->post->ID ) . '">' . get_the_title( $cityposts->post->ID ) . '</a></h2>';
										echo get_the_excerpt();
									echo '</li>';
								}
								echo '</ul>';
							}
							// Restore original Post Data
							wp_reset_postdata();
							?>
				<?php endif; ?>

			</div>
		</section>
	</article>
</main>
