<header id="masthead" role="banner">

	<div id="header--top">
		<div class="header-container">
			<?php
				$logo = get_theme_mod('logom');
				$phone = get_option('fphoned');
				$email = get_option('femail');
				$login = get_option('wlf__Login');
				$register = get_option('wlf__Register');

				$social_links = array();

				if ( get_theme_mod('fb') ) 
					$social_links[] = array( 'link' => get_theme_mod('fb'), 'name' => 'Facebook', 'icon' => '<svg style="height: 15px; width: 18px; " width="1792" height="1792" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path fill="#ffffff" d="M1343 12v264h-157q-86 0-116 36t-30 108v189h293l-39 296h-254v759h-306v-759h-255v-296h255v-218q0-186 104-288.5t277-102.5q147 0 228 12z"/></svg>' );

				if ( get_theme_mod('tw') ) 
					$social_links[] = array( 'link' => get_theme_mod('tw'), 'name' => 'Twitter', 'icon' => '<svg style="height: 15px; width: 18px; " width="1792" height="1792" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path fill="#ffffff" d="M1684 408q-67 98-162 167 1 14 1 42 0 130-38 259.5t-115.5 248.5-184.5 210.5-258 146-323 54.5q-271 0-496-145 35 4 78 4 225 0 401-138-105-2-188-64.5t-114-159.5q33 5 61 5 43 0 85-11-112-23-185.5-111.5t-73.5-205.5v-4q68 38 146 41-66-44-105-115t-39-154q0-88 44-163 121 149 294.5 238.5t371.5 99.5q-8-38-8-74 0-134 94.5-228.5t228.5-94.5q140 0 236 102 109-21 205-78-37 115-142 178 93-10 186-50z"/></svg>' );

				if ( get_theme_mod('gp') ) 
					$social_links[] = array( 'link' => get_theme_mod('gp'), 'name' => 'Google Plus', 'icon' => '<svg style="height: 15px; width: 18px; " width="1792" height="1792" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path fill="#ffffff" d="M1181 913q0 208-87 370.5t-248 254-369 91.5q-149 0-285-58t-234-156-156-234-58-285 58-285 156-234 234-156 285-58q286 0 491 192l-199 191q-117-113-292-113-123 0-227.5 62t-165.5 168.5-61 232.5 61 232.5 165.5 168.5 227.5 62q83 0 152.5-23t114.5-57.5 78.5-78.5 49-83 21.5-74h-416v-252h692q12 63 12 122zm867-122v210h-209v209h-210v-209h-209v-210h209v-209h210v209h209z"/></svg>' );

				if ( get_theme_mod('in') ) 
					$social_links[] = array( 'link' => get_theme_mod('in'), 'name' => 'LinkedIn', 'icon' => '<svg style="height: 15px; width: 18px; " width="1792" height="1792" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path fill="#ffffff" d="M477 625v991h-330v-991h330zm21-306q1 73-50.5 122t-135.5 49h-2q-82 0-132-49t-50-122q0-74 51.5-122.5t134.5-48.5 133 48.5 51 122.5zm1166 729v568h-329v-530q0-105-40.5-164.5t-126.5-59.5q-63 0-105.5 34.5t-63.5 85.5q-11 30-11 81v553h-329q2-399 2-647t-1-296l-1-48h329v144h-2q20-32 41-56t56.5-52 87-43.5 114.5-15.5q171 0 275 113.5t104 332.5z"/></svg>' );

				if ( get_theme_mod('insta') ) 
					$social_links[] = array( 'link' => get_theme_mod('insta'), 'name' => 'Instagram', 'icon' => '<svg style="height: 15px; width: 18px; " width="1792" height="1792" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path fill="#ffffff" d="M1490 1426v-648h-135q20 63 20 131 0 126-64 232.5t-174 168.5-240 62q-197 0-337-135.5t-140-327.5q0-68 20-131h-141v648q0 26 17.5 43.5t43.5 17.5h1069q25 0 43-17.5t18-43.5zm-284-533q0-124-90.5-211.5t-218.5-87.5q-127 0-217.5 87.5t-90.5 211.5 90.5 211.5 217.5 87.5q128 0 218.5-87.5t90.5-211.5zm284-360v-165q0-28-20-48.5t-49-20.5h-174q-29 0-49 20.5t-20 48.5v165q0 29 20 49t49 20h174q29 0 49-20t20-49zm174-208v1142q0 81-58 139t-139 58h-1142q-81 0-139-58t-58-139v-1142q0-81 58-139t139-58h1142q81 0 139 58t58 139z"/></svg>' );

				if ( get_theme_mod('pin') ) 
					$social_links[] = array( 'link' => get_theme_mod('pin'), 'name' => 'Pinterest', 'icon' => '<svg style="height: 15px; width: 18px; " width="1792" height="1792" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path fill="#ffffff" d="M1664 896q0 209-103 385.5t-279.5 279.5-385.5 103q-111 0-218-32 59-93 78-164 9-34 54-211 20 39 73 67.5t114 28.5q121 0 216-68.5t147-188.5 52-270q0-114-59.5-214t-172.5-163-255-63q-105 0-196 29t-154.5 77-109 110.5-67 129.5-21.5 134q0 104 40 183t117 111q30 12 38-20 2-7 8-31t8-30q6-23-11-43-51-61-51-151 0-151 104.5-259.5t273.5-108.5q151 0 235.5 82t84.5 213q0 170-68.5 289t-175.5 119q-61 0-98-43.5t-23-104.5q8-35 26.5-93.5t30-103 11.5-75.5q0-50-27-83t-77-33q-62 0-105 57t-43 142q0 73 25 122l-99 418q-17 70-13 177-206-91-333-281t-127-423q0-209 103-385.5t279.5-279.5 385.5-103 385.5 103 279.5 279.5 103 385.5z"/></svg>' );

				if ( get_theme_mod('yt') )
					$social_links[] = array( 'link' => get_theme_mod('yt'), 'name' => 'YouTube', 'icon' => '<svg style="height: 15px; width: 18px; " width="1792" height="1792" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path fill="#ffffff" d="M1280 896q0-37-30-54l-512-320q-31-20-65-2-33 18-33 56v640q0 38 33 56 16 8 31 8 20 0 34-10l512-320q30-17 30-54zm512 0q0 96-1 150t-8.5 136.5-22.5 147.5q-16 73-69 123t-124 58q-222 25-671 25t-671-25q-71-8-124.5-58t-69.5-123q-14-65-21.5-147.5t-8.5-136.5-1-150 1-150 8.5-136.5 22.5-147.5q16-73 69-123t124-58q222-25 671-25t671 25q71 8 124.5 58t69.5 123q14 65 21.5 147.5t8.5 136.5 1 150z"/></svg>' );

				if ( $logo )
					echo sprintf('<a href="%s" id="site-logo"><img src="%s" alt="%s"></a>', home_url(), $logo, get_bloginfo('title') ); 

				echo '<div id="header-links">';

				if ( $phone )
					echo sprintf('<a href="tel:%s" class="header--contact-item"><svg style="height: 25px; width: 25px; display: inline-block; vertical-align: middle; transform: translateY(-2px); margin-right: 3px;" width="1792" height="1792" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path fill="#ffffff" d="M1408 1193q0-11-2-16-3-8-38.5-29.5t-88.5-49.5l-53-29q-5-3-19-13t-25-15-21-5q-18 0-47 32.5t-57 65.5-44 33q-7 0-16.5-3.5t-15.5-6.5-17-9.5-14-8.5q-99-55-170.5-126.5t-126.5-170.5q-2-3-8.5-14t-9.5-17-6.5-15.5-3.5-16.5q0-13 20.5-33.5t45-38.5 45-39.5 20.5-36.5q0-10-5-21t-15-25-13-19q-3-6-15-28.5t-25-45.5-26.5-47.5-25-40.5-16.5-18-16-2q-48 0-101 22-46 21-80 94.5t-34 130.5q0 16 2.5 34t5 30.5 9 33 10 29.5 12.5 33 11 30q60 164 216.5 320.5t320.5 216.5q6 2 30 11t33 12.5 29.5 10 33 9 30.5 5 34 2.5q57 0 130.5-34t94.5-80q22-53 22-101zm256-777v960q0 119-84.5 203.5t-203.5 84.5h-960q-119 0-203.5-84.5t-84.5-203.5v-960q0-119 84.5-203.5t203.5-84.5h960q119 0 203.5 84.5t84.5 203.5z"/></svg><span>%s</span></a>', $phone, $phone);

				if ( $email )
					echo sprintf( '<a href="mailto:%s" class="header--contact-item"><svg style="height: 25px; width: 25px; display: inline-block; vertical-align: middle; transform: translateY(-2px); margin-right: 3px;" width="1792" height="1792" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1376 128q119 0 203.5 84.5t84.5 203.5v960q0 119-84.5 203.5t-203.5 84.5h-960q-119 0-203.5-84.5t-84.5-203.5v-960q0-119 84.5-203.5t203.5-84.5h960zm32 1056v-436q-31 35-64 55-34 22-132.5 85t-151.5 99q-98 69-164 69t-164-69q-46-32-141.5-92.5t-142.5-92.5q-12-8-33-27t-31-27v436q0 40 28 68t68 28h832q40 0 68-28t28-68zm0-573q0-41-27.5-70t-68.5-29h-832q-40 0-68 28t-28 68q0 37 30.5 76.5t67.5 64.5q47 32 137.5 89t129.5 83q3 2 17 11.5t21 14 21 13 23.5 13 21.5 9.5 22.5 7.5 20.5 2.5 20.5-2.5 22.5-7.5 21.5-9.5 23.5-13 21-13 21-14 17-11.5l267-174q35-23 66.5-62.5t31.5-73.5z"/></svg><span>Email Me</span></a>', antispambot($email) );

				if ( $login )
					echo sprintf( '<a href="%s" id="header--login">Sign In</a>', $login );	

				if ( $register )
					echo sprintf( '<a href="%s" id="header--login">Register</a>', $register );	

				echo '</div>';	
			?>
		</div>
	</div>

	<?php if ( has_nav_menu('primary') ): ?>

		<nav id="main-navigation" role="navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
			<div class="header-container">
				<?php 

					wp_nav_menu( 
						array( 
							'theme_location' => 'primary',
							'container' => ''
						) 
					); 

					echo '<ul id="header--socialmedia">';

					foreach ( $social_links as $link ) {
						echo '<li><a href="' . $link['link'] . '" target="_blank">' . $link['icon'] . '</a></li>';
					}

					echo '</ul>';

				?>
			</div>
		</nav>

		<button id="menu-toggle" aria-controls="primary-menu" aria-expanded="false">Menu <svg style="height: 15px; width: 15px; display: inline-block; vertical-align: middle; transform: translateY(-2px); margin-left: 3px;" width="1792" height="1792" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1664 1344v128q0 26-19 45t-45 19h-1408q-26 0-45-19t-19-45v-128q0-26 19-45t45-19h1408q26 0 45 19t19 45zm0-512v128q0 26-19 45t-45 19h-1408q-26 0-45-19t-19-45v-128q0-26 19-45t45-19h1408q26 0 45 19t19 45zm0-512v128q0 26-19 45t-45 19h-1408q-26 0-45-19t-19-45v-128q0-26 19-45t45-19h1408q26 0 45 19t19 45z"/></svg></button>

	<?php endif ?>

</header>
