<?php
/**
 * Partial: Custom Single
 * @package brandco
 */
?>
<main id="site-main" role="main">
	<article id="page-<?php the_ID(); ?>" <?php post_class(); ?>>
		<header class="page-header page-header-padding">
			<div class="main-container">
				<div class="column-full">
					<?php echo sprintf( '<h1 class="entry-title" itemprop="headline">%s</h1>', brandco\functions\headline() ); ?>
					<div class="post-meta">
						<!-- Date, category, author -->
					</div>
				</div>
			</div>
		</header>
		<section class="main-section page-section-padding">
			<div class="main-container">
				<div class="column-full"> 
					<div class="entry-content" itemprop="mainContentOfPage">
						<?php the_content(); ?>
						<?php
							wp_link_pages( array(
								'before' => '<div class="post-links">' . __( 'Pages:', 'brandco' ),
								'after'  => '</div>',
							) );
						?>
					</div>
				</div>
			</div>
		</section>
	</article>
</main>
