<?php
/**
 * Partial: Homepage
 * @package brandco
 */

	$HeaderImages_array = array();

	if ( get_theme_mod('imageheader') ) { $HeaderImages_array[] = get_theme_mod('imageheader'); }
	if ( get_theme_mod('imageheader2') ) { $HeaderImages_array[] = get_theme_mod('imageheader2'); }
	if ( get_theme_mod('imageheader3') ) { $HeaderImages_array[] = get_theme_mod('imageheader3'); }

?>
<main id="site-main" role="main">
	<article id="site-homepage" <?php post_class(); ?>>

		<section id="module--quicksearch" class="quicksearch--ToggleActive-L">
			<div class="main-container">

			<?php if( get_theme_mod( 'homequicksearchdisplay' ) === false) : ?>
				<div id="quicksearch--container">
					<h2 id="quicksearch--title">
						<?php
							if ( get_theme_mod('homequicksearchtitle') ) {
								echo get_theme_mod('homequicksearchtitle');
							} else {
								echo 'Search For Your <span>Dream Home</span>';
							}
						?>
					</h2>
					<div id="quicksearch--ToggleContainer">
						<div id="quicksearch--ToggleL" class="quicksearch--toggle"><span>Search Homes</span></div>
						<?php if ( get_option('wnt_gravity_form_2') ) : ?>
							<div id="quicksearch--ToggleR" class="quicksearch--toggle"><span>What Is My Home Worth?</span></div>
						<?php endif; ?>
					</div>
					<div class="quickSearch-body">
						<div class="quickSearch-body-searchBar">
							<?php $manual_shortcode = get_theme_mod( 'homeqsshortcode' ); ?>
							<?php if(get_theme_mod('homeqsshortcode')){
								echo do_shortcode($manual_shortcode);
							}
							elseif( get_theme_mod( 'smartsearch' ) == '1')
							{
								echo do_shortcode('[wnt_search view="basic" smartsearch="false" routing="auto" /]');
							}
							else {
								echo do_shortcode('[wnt_search view="basic" smartsearch="true" routing="auto" /]');
							}
							?>
							<?php
							// if( get_theme_mod( 'smartsearch' ) == '1')
							// {
							// 	echo do_shortcode('[wnt_search view="basic" smartsearch="false" routing="auto" /]');
							// }
							// else {
							// 	echo do_shortcode('[wnt_search view="basic" smartsearch="true" routing="auto" /]');
							// }
							?>
							<?php
								// if ( get_option('wnt__HomeQuickSearchCode') ) {
								// 	echo do_shortcode( get_option('wnt__HomeQuickSearchCode') );
								// } else {
								// 	echo do_shortcode('[wnt_search view="basic" smartsearch="true" routing="auto" /]');
								// }
							?>
						</div>
						<?php if ( get_option('wnt_gravity_form_2') ) : ?>
							<div id="quickSearch-body-homeValue" class="quickSearch-body-homeValue">
								<?php gravity_form(get_option('wnt_gravity_form_2'), false, false, false, '', true, 12); ?>
							</div>
						<?php endif; ?>
					</div>
				</div>

			<?php endif; ?>

			</div>

			<?php if ( $HeaderImages_array ) : ?>
				<div id="home-background-rotator" class="slider-init">
					<?php foreach ( $HeaderImages_array as $image ): ?>
						<div class="home-background-rotator-image" style="background-image: url(<?php echo $image; ?>); ">
							<!-- <img src="<?php echo $image; ?>" alt="<?php bloginfo('title'); ?>"> -->
						</div>
					<?php endforeach ?>
				</div>
				<div id="slider-arrows"></div>
			<?php endif; ?>

		</section>

		<section id="module--quicklinks" class="wntPrimaryColor--background">
			<div class="main-container">

				<div class="quicklink--container">

					<?php
						$wnt__FeaturedPages_array = array();

						$wnt__FeaturedPages_array[] = array(
							'title' => get_the_title( get_option('wnt__FeaturedPage01') ),
							'link' => get_permalink( get_option('wnt__FeaturedPage01') )
						);

						$wnt__FeaturedPages_array[] = array(
							'title' => get_the_title( get_option('wnt__FeaturedPage02') ),
							'link' => get_permalink( get_option('wnt__FeaturedPage02') )
						);

						$wnt__FeaturedPages_array[] = array(
							'title' => get_the_title( get_option('wnt__FeaturedPage03') ),
							'link' => get_permalink( get_option('wnt__FeaturedPage03') )
						);

						foreach ( $wnt__FeaturedPages_array as $page ) {
							echo '<a href="' . $page['link'] . '" class="quicklink--button wntPrimaryColor--button"><h3>' . $page['title'] . '</h3></a>';
						}
					?>

				</div>

			</div>
		</section>

		<?php if ( get_option('wnt_about__title') ) : ?>
			<section id="module--agentspotlight" class="homepage--section">
				<div class="main-container">
					<?php
						$agent_phone = get_option('fphoned');
						$agent_email = get_option('femail');
					?>

					<div class="module--left agent-image">
						<?php
							if ( get_option('wnt_about__image') ) {
								echo '<img src="' . get_option('wnt_about__image') . '" alt="">';
							}
						?>
					</div>

					<?php
						if ( $agent_phone || $agent_email ) { echo '<div class="agent-contact-buttons">'; }

						if ( $agent_phone ) {
							echo '<a href="tel:' . $agent_phone . '" class="agent-contact--tel"><i class="fa fa-phone"></i><span class="screen-reader-text"></span></a>';
						}

						if ( $agent_email ) {
							echo '<a href="mailto:' . antispambot($agent_email) . '" class="agent-contact--mail"><i class="fa fa-envelope"></i><span class="screen-reader-text"></span></a>';
						}

						if ( $agent_phone || $agent_email ) { echo '</div>'; }
					?>

					<div class="module--right">
						<h2 class="module--title">
							<span class="module--title-firstwordjs wntPrimaryColor--text"><?php echo get_option('wnt_about__title'); ?></span>
							<span class="module--subtitle"><?php echo get_option('wnt_about__subtitle'); ?></span>
						</h2>

						<div class="agent--bioexcerpt">
							<?php echo wpautop( get_option('wnt_about__description') ); ?>
						</div>
						<?php if ( get_option('wnt_about__link') ) : ?>
							<a href="<?php echo get_option('wnt_about__link'); ?>" class="module--viewmore">Learn More</a>
						<?php endif; ?>
					</div>
				</div>
			</section>
		<?php endif; ?>

		<?php if ( get_theme_mod('homefeatured') ) : ?>
			<section id="module--featuredlistings" class="homepage--section">
				<div class="main-container">

					<div class="module--header">
						<h2 class="module--title">
							<?php if ( get_option('homefeatured-title') ) : ?>
								<span class="module--title-firstwordjs"><?php echo get_option('homefeatured-title'); ?></span>
							<?php else : ?>
								<span class="module--title-firstword">Featured</span>
								<span class="module--title-secondword wntPrimaryColor--text">Listings</span>
							<?php endif; ?>
						</h2>
						<div class="module--undertitle">
							<a href="<?php echo get_option('homefeatured-readmore'); ?>" class="module--viewmore">View More</a>
						</div>
					</div>
					<div class="module--body">
						<?php echo do_shortcode( get_theme_mod('homefeatured') ); ?>
					</div>

				</div>
			</section>
		<?php endif; ?>

	</article>
</main>
