<?php
/**
 * Partial: Default Page
 * @package brandco
 */

?>

<main id="site-main" role="main">
	<article id="page-<?php the_ID(); ?>" <?php post_class(); ?>>
		<header class="page-header">
			<div class="main-container">
				<div class="page-header-container">
					<?php echo sprintf( '<h1 class="page-title entry-title module--title-firstwordjs" itemprop="headline">%s</h1>', brandco\functions\headline() ); ?>
				</div>
			</div>
		</header>
		<section id="page-main" class="main-section page-has-aside homepage--section">
			<div class="main-container">
				<div class="column-primary"> 
					<div class="entry-content" itemprop="mainContentOfPage">
						<?php the_content(); ?>
					</div>
				</div>
				<div class="column-aside">
					<?php dynamic_sidebar('sidebar-1'); ?>
				</div>
			</div>
		</section>
	</article>
</main>



