<div href="<?php echo get_permalink(); ?>" id="link-<?php the_ID(); ?>" <?php post_class( 'article-link' ); ?>>

	<?php if ( has_post_thumbnail() ) : ?>
		<div class="community-archive--image">
			<a href="<?php echo get_permalink(); ?>">
				<?php the_post_thumbnail('medium'); ?>
			</a>
		</div>
	<?php endif; ?>

	<div class="community-archive--title">
		<a href="<?php echo get_permalink(); ?>">
			<?php echo sprintf( '<h2 class="single-title" itemprop="headline">%s</h2>', brandco\functions\headline() ); ?>
		</a>
	</div>

</div>
