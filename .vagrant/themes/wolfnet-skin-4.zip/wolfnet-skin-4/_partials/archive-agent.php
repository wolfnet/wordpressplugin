<div href="<?php echo get_permalink(); ?>" id="link-<?php the_ID(); ?>" <?php post_class( 'article-link' ); ?>>

	<?php if ( has_post_thumbnail() ) : ?>
		<div class="agent-archive--image">
			<a href="<?php echo get_permalink(); ?>">
				<?php the_post_thumbnail('medium'); ?>
			</a>
		</div>
	<?php endif; ?>

	<div class="agent-archive--title">
		<a href="<?php echo get_permalink(); ?>">
			<?php echo sprintf( '<h2 class="single-title" itemprop="headline">%s</h2>', brandco\functions\headline() ); ?>
		</a>
	</div>

	<div class="agent-archive--details">
		<?php
			$agent_phone = get_post_meta( get_the_ID(), '_my_meta_value_key2', true );
			$agent_email = get_post_meta( get_the_ID(), '_my_meta_value_key3', true );
		
			if ( $agent_phone ) 
				echo '<a href="tel:' . $agent_phone . '" class="agent-contact--tel"><i class="fa fa-phone"></i> <span>' . $agent_phone . '</span></a>';

			if ( $agent_email ) 
				echo '<a href="mailto:' . antispambot($agent_email) . '" class="agent-contact--mail"><i class="fa fa-envelope"></i> <span>Email</span></a>';	

		?>
	</div>
</div>
