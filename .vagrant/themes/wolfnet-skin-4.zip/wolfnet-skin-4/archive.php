<?php
/**
 * Archive.php
 * @package brandco
 * Available:
 * brandco_has_archive_content(), brandco_archive_content()
 */
get_header(); ?>
	<main id="site-main" role="main">

		<header class="page-header">
			<div class="main-container">
				<div class="page-header-container">
					<?php
						$title = get_post_type_object( $wp_query->query['post_type'] )->labels->name;
						if ( is_post_type_archive() ) {
							echo sprintf( '<h1 class="page-title entry-title module--title-firstwordjs">%s</h1>', $title );
						} else {
							echo sprintf( '<h1 class="page-title entry-title module--title-firstwordjs">%s</h1>', bco_archive_title() );
						}
					?>
				</div>
			</div>
		</header>

		<section id="page-main" class="main-section page-has-aside homepage--section">
			<div class="main-container">
				<div class="column-primary article-list">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php
							if ( is_post_type_archive('agent') ) {
								get_template_part( '_partials/archive-agent' );
							}
							elseif ( is_post_type_archive('city') ) {
								get_template_part( '_partials/archive-community' );
							}
							else {
								get_template_part( '_partials/archive-default' );
							}
						?>
					<?php endwhile; ?>
					<?php brandco_archive_pages(); ?>
				</div>
				<div class="column-aside">
					<?php
						if ( is_post_type_archive('city') )
							dynamic_sidebar('sidebar-2');

						else if ( is_home() )
							dynamic_sidebar('blog');

						else
							dynamic_sidebar('sidebar-1');
					?>
				</div>
			</div>
		</section>

	</main>
<?php get_footer(); ?>
