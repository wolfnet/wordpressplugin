<?php  
 /**
 * @package brandco
 */?><!DOCTYPE html>
<html class="no-js" <?php language_attributes(); ?> <?php brandco_schema_tag(); ?>>
<?php get_template_part('_partials/site-head'); ?>
<body <?php body_class(); ?>>
	<a class="skip-link screen-reader-text" href="#site-main"><?php esc_html_e( 'Skip to content' ); ?></a>
	<div id="site-wrapper" role="document">
		<?php get_template_part('_partials/site-header'); ?>
	

