<?php 
/**
 * @package brandco
 */ 
get_header(); ?>
	<main id="site-main" role="main">

		<header class="page-header">
			<div class="main-container">
				<div class="page-header-container">
					<?php echo sprintf( '<h1 class="page-title entry-title module--title-firstwordjs">Search results for: <span>%s</span></h1>', get_search_query() ); ?>
				</div>
			</div>
		</header>

		<section id="page-main" class="main-section page-has-aside homepage--section">
			<div class="main-container">
				<div class="column-primary article-list"> 
					<?php while ( have_posts() ) : the_post(); ?>
						<?php get_template_part('_partials/archive-default'); ?>
					<?php endwhile; ?>
					<?php brandco_archive_pages(); ?>
				</div>
				<div class="column-aside">
					<?php dynamic_sidebar('sidebar-1'); ?>
				</div>
			</div>
		</section>

	</main>
<?php get_footer(); ?>
