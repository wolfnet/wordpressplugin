(function(e,t,n,r){function o(t,n){this.element=t;this.options=e.extend({},s,n);this._defaults=s;this._name=i;this.init()}var i="gravityPlaceholders",s={className:"showingPlaceholder"};o.prototype.init=function(){var t=this.options,r=e(this.element),i=r.attr("id"),s=e("label[for="+i+"]").hide(),o="placeholder"in n.createElement("input"),u=s.find("span").remove().end().text();s.next(".ginput_container").hasClass("ginput_complex")&&(u=r.next("label").text());r.closest("form").submit(function(){this.each(function(){var t=e(this);t.val()===u&&t.val("")})});r.val()===""&&(o?r.attr("placeholder",u):r.val(u).addClass(t.className));r.bind({focus:function(){r.val()===u&&r.val("").removeClass(t.className)},blur:function(){(r.val()===""||r.val()===u)&&!o&&r.val(u).addClass(t.className)}})};e.fn[i]=function(t){return this.each(function(){e.data(this,"plugin_"+i)||e.data(this,"plugin_"+i,new o(this,t))})}})(jQuery,window,document);



// Parallax plugin
if( ! (/Android|iPhone|iPad|iPod|BlackBerry/i).test(navigator.userAgent || navigator.vendor || window.opera) ){
	var s = skrollr.init({
		smoothScrolling: false,
		smoothScrollingDuration: 10,
		forceHeight: false,
		edgeStrategy: 'set',
		easing: {
			WTF: Math.random,
			inverted: function(p) {
				return 1-p;
			}
		}
	});
}

jQuery(function($){

	$('.wolfnet_widgetBaths option:first-of-type').text('Baths');
	$('.wolfnet_widgetBeds option:first-of-type').text('Beds');

	$('.sidebar-widget .wolfnet_quickSearch .wolfnet_widgetTitle').addClass('widget-title module--title-firstwordjs');
	$('.sidebar-widget .wolfnet_smartSearch .wolfnet_widgetTitle').addClass('widget-title module--title-firstwordjs');

	$('#module--quicksearch .wolfnet_widget').removeClass();
	$('#module--quicksearch button').html('SEARCH');

	$('#quicksearch--ToggleR').on('click', function(){
		if ( $('#module--quicksearch.quicksearch--ToggleActive-L').length ) {
			$('#module--quicksearch').removeClass('quicksearch--ToggleActive-L').addClass('quicksearch--ToggleActive-R');
		}
	});

	$('#quicksearch--ToggleL').on('click', function(){
		$('.quickSearch-body-homeValue .validation_message').remove();

		if ( $('#module--quicksearch.quicksearch--ToggleActive-R').length ) {
			$('#module--quicksearch').removeClass('quicksearch--ToggleActive-R').addClass('quicksearch--ToggleActive-L');
		}
	});

	$('.module--title-firstwordjs').each(function(){
		var me = $(this);
		me.html(me.html().replace(/^(\w+)/, '<span>$1</span>'));
	});

	// Non-clickable parent menu items
	$(document).ready(function() {
		$('.menu-item-has-children > a').attr('onClick', 'return false;');

		// $('.gfield select,.gfield input[type=text],.gfield input[type=email],.gfield input[type=tel],.gfield input[type=url],.gfield textarea').gravityPlaceholders();

		// $('.gfield select,.gfield input[type=text],.gfield input[type=email],.gfield input[type=tel],.gfield input[type=url]').parent().parent().addClass('gfield_input_field');

	});

	// Image lazyload
	$(document).ready(function() {
		$('.image-defer').unveil(200, function() {
			$(this).load(function() {
				this.style.opacity = 1;
			});
		});
		// $('.image-defer').lazyload({
		// 	effect : "fadeIn",
		// 	threshold: -200
		// });
	});

	// Slider - slick.js
	$(document).ready(function($) {
		$('.slider-init').slick({
			dots: false,
			autoplay: true,
			appendArrows: '#slider-arrows'
		});

		$('.gallery').slick({
			centerMode: true,
			centerPadding: '15px',
			lazyLoad: 'ondemand',
			slidesToShow: 3,
			responsive: [
				{
					breakpoint: 768,
					settings: {
						arrows: true,
						centerMode: true,
						centerPadding: '15px',
						slidesToShow: 3
					}
				},
				{
					breakpoint: 480,
					settings: {
						arrows: true,
						centerMode: true,
						centerPadding: '15px',
						slidesToShow: 1
					}
				}
			]
		});
	});

	// Select field holder
	$(document).ready(function(){
		$('select').wrap('<div class="select-holder"></div>');
		$('input[type="search"]').wrap('<div class="input-search-holder"></div>');
		$('input[type="submit"]').wrap('<div class="input-submit-wrapper"></div>');
		// $('input[type="submit"]').click(function(){
			// $(this).parent().addClass('bco-submit-animation');
		// });
	});

	// For loading animation
	$(document).ready(function(){
		setTimeout(function(){ $('html').addClass('after-load-1000'); }, 1000);
		setTimeout(function(){ $('html').addClass('after-load-1500'); }, 1500);
		setTimeout(function(){ $('html').addClass('after-load-2000'); }, 2000);
	});

	// Scroll header class
	$(document).ready(function(){
		$(window).scroll(function() {
			var scroll = $(window).scrollTop();
			if (scroll >= 100) {
				$('body').addClass('header-scrolled');
			} else {
				$('body').removeClass('header-scrolled');
			}
		});
	});

	// Mobile menu stuff
	$('#menu-toggle').click(function(){
		if ( ! $('html').hasClass('mobile-navigation-active') ) {
			$('html').addClass('mobile-navigation-active');
		} else {
			$('html').removeClass('mobile-navigation-active');
		}
	});

	$('#close-navigation-popout').click(function(){
		$('html').removeClass('mobile-navigation-active');
	});

	$(document).on('click', '#close-navigation', function(){
		$('html').removeClass('mobile-navigation-active');
	});

	$(document).ready(function() {
		$('#mobile-navigation .menu-item-has-children > a').append('<i class="fa fa-angle-down"></i>');
		// $('#mobile-navigation .menu > li:last-of-type').after('<li id="close-navigation" class="menu-item"><a href="#0">Close Menu <i class="fa fa-close"></i></a></li>');
	});

	$('#mobile-navigation .menu-item-has-children > a').click(function(){
		$(this).next().slideToggle( 300 );
	});

	// Fit vids
	$(document).ready(function() {
		$('body').fitVids();
	});

	$(document).ready(function(){
		$('*[class^="wp-image"]').parent().featherlight();
		$('.gallery a').featherlightGallery();
	});

	// Gravity forms field animation classes
	$(document).ready(function(){
		var gfields = $('li.gfield .ginput_container input, li.gfield .ginput_container textarea');
		gfields.focus(function(){
			$(this).parent().parent().addClass('field-active');
		});
		gfields.blur(function(){
			$(this).parent().parent().removeClass('field-active');
			if( $(this).val().length !== 0 ) {
				$(this).parent().parent().addClass('field-complete');
			} else {
				$(this).parent().parent().removeClass('field-complete');
			}
		});
	});

	// Smooth scroll on anchor links
	$(document).ready(function(){
		$('a[href*="#"]:not([href="#"])').click(function() {
			if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
				var target = $(this.hash);
				target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
				if (target.length) {
					$('html,body').animate({
						scrollTop: target.offset().top
					}, 1000);
					return false;
				}
			}
		});
	});

	// Sticky elements
	$(document).ready(function(){
		if ( $('.sticky-element').length ) {
			$('.sticky-element').each(function(){
				var sticky = new Waypoint.Sticky({
					element: $(this)
				});
			});
		}
	});

	// Inview
	// var wow = new WOW({
	// 	boxClass: 'element-inview',
	// });
	// wow.init();

});
